from selenium.common.exceptions import TimeoutException, ElementClickInterceptedException, StaleElementReferenceException
from selenium.webdriver import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains

import time, json, random, logging, re
from selenium.webdriver.support import expected_conditions as EC

logger = logging.getLogger(__name__)

def driver_get(driver, url: str):
    try:
        driver.get(url)
        wait_page_ready(driver)
        return True
    except Exception:
        return False


# 等待页面加载完成。
def wait_page_ready(driver, timeout_seconds: int = 30) -> bool:
    try:
        WebDriverWait(driver, timeout_seconds).until(
            lambda d: d.execute_script("return document.readyState") == "complete"
        )
        return True
    except Exception:
        # 刷新页面重试
        pass

# 等待页面重新加载完成。
def wait_reload_page_ready(driver, timeout_seconds: int = 10) -> bool:
    try:
        driver.refresh()
        WebDriverWait(driver, timeout_seconds).until(
            lambda d: d.execute_script("return document.readyState") == "complete"
        )
        return True
    except Exception:
        pass  # 忽略刷新异常
    return False

# 等待元素可点击。
def wait_element_clickable(driver, element, timeout_seconds: int = 10) -> bool:
    try:
        WebDriverWait(driver, timeout_seconds).until(
            lambda d: element.is_displayed() and element.is_enabled()
        )
        return True
    except Exception:
        return False

# 判断当前页面 URL 是否包含指定子串。
def url_contains(driver, part: str, ignore_scheme: bool = False) -> bool:
    try:
        # 如果 part 包含 http(s)://，去掉 scheme 和域名，只保留 path/query/fragment 部分
        if ignore_scheme and (part.startswith('http://') or part.startswith('https://')):
            # 提取 / 后面的部分
            match = re.match(r'https?://[^/]+(.*)', part, re.IGNORECASE)
            if match:
                part = match.group(1) or '/'

        current = getattr(driver, "current_url", "") or ""
        return part in current
    except Exception:
        return False


# 判断是否空白/初始页面。
def is_blank_page(driver) -> bool:
    try:
        url = (getattr(driver, "current_url", None) or "").strip().lower()
        if not url or url in ("about:blank", "data:", "chrome://new-tab-page/"):
            return True
        # 进一步通过 DOM 大小/内容判断是否基本空白
        try:
            body_child_count = driver.execute_script("return document.body ? document.body.childElementCount : 0")
            if body_child_count == 0:
                return True
        except Exception:
            pass
        return False
    except Exception:
        return True



# 检测 Selenium driver 会话是否存活。
def is_driver_alive(driver) -> bool:
    try:
        _ = getattr(driver, "current_url", None)
        driver.execute_script("return 1")
        return True
    except Exception:
        return False



"""尝试点击元素：模拟真人滚动至可见再点击，失败则使用 JS 点击。"""
import random
import time

def human_like_scroll_into_view(driver, element):
    """模拟真人滚动页面到元素"""
    try:
        rect = driver.execute_script("""
            const el = arguments[0];
            const r = el.getBoundingClientRect();
            return {top: r.top, bottom: r.bottom, left: r.left, right: r.right, height: r.height, width: r.width};
        """, element)
        if rect and 'top' in rect:
            viewport_height = driver.execute_script("return window.innerHeight;")
            scroll_y = driver.execute_script("return window.scrollY;")
            to_y = scroll_y + rect['top'] - (viewport_height // 4) + random.randint(-30, 30)
            to_y = max(0, int(to_y))
            # 分步滚动，模拟手动滑动滚轮
            cur_y = scroll_y
            steps = random.randint(3, 8)
            for i in range(steps):
                inter_y = cur_y + ((to_y - cur_y) * (i + 1)) // steps
                driver.execute_script("window.scrollTo(0, arguments[0]);", inter_y)
                time.sleep(random.uniform(0.03, 0.14))
    except Exception:
        try:
            driver.execute_script("arguments[0].scrollIntoView({block:'center',inline:'center'});", element)
            time.sleep(random.uniform(0.05, 0.12))
        except Exception:
            pass

def try_click_element(driver, element, wait_seconds: int = 5, custom_wait_condition=None) -> bool:
    """
    尝试点击元素：模拟真人滚动至可见再点击，失败则使用 JS 点击。
    :param driver: Selenium WebDriver 实例
    :param element: 待点击的 WebElement
    :param wait_seconds: 等待时间（秒）
    :param custom_wait_condition: 可选，自定义等待lambda(driver, element)->bool，返回True则认为可点击
    :return: True/False
    """
    try:
        try:
            driver.execute_script("arguments[0].scrollIntoView({block:'center',inline:'center'});", element)
            time.sleep(random.uniform(0.08, 0.26))  # 模拟停顿
        except Exception:
            pass

        try:
            if custom_wait_condition is not None:
                WebDriverWait(driver, wait_seconds, ignored_exceptions=(StaleElementReferenceException,)).until(
                    lambda d: (element.is_enabled()) and custom_wait_condition(d, element)
                )
            else:
                WebDriverWait(driver, wait_seconds, ignored_exceptions=(StaleElementReferenceException,)).until(
                    lambda d: element.is_enabled()
                )
        except TimeoutException:
            pass

        try:
            # 模拟人为短暂停顿
            time.sleep(random.uniform(0.03, 0.1))
            element.click()
            return True
        except ElementClickInterceptedException:
            try:
                # 再次尝试js滚动
                try:
                    driver.execute_script("arguments[0].scrollIntoView({block:'center',inline:'center'});", element)
                    time.sleep(random.uniform(0.03, 0.1))
                except Exception:
                    pass
                driver.execute_script("arguments[0].click();", element)
                return True
            except Exception:
                return False
        except Exception:
            return False
    except Exception:
        return False

"""使用 find_elements 并带超时等待，返回匹配到的元素列表；超时返回空列表。"""
def find_elements_with_timeout(driver, by, locator, timeout_seconds: float = 3):
    try:
        # 等待直到至少有一个元素出现
        elements = WebDriverWait(driver, timeout_seconds).until(
            EC.presence_of_all_elements_located((by, locator))
        )
        # presence_of_all_elements_located 保证返回 list
        return elements or None
    except TimeoutException:
        return None
    except Exception:
        return None
        
"""使用 find_elements 并带超时等待，返回匹配到的元素列表；超时返回空列表。"""
def find_element_unique(driver, by, locator, timeout_seconds: float = 2):
    try:
        elements = find_elements_with_timeout(driver, by, locator, timeout_seconds)
        if elements is None:
            return None
        # if len(elements) == 1:
        #     for elem in elements:
        #         try:
        #             if elem.is_displayed():
        #                 return elem
        #         except Exception:
        #             continue
        #     return None
        # else:
        #     return False

        if len(elements) > 0:
            if(len(elements) > 1):
                logger.info(f"[selenium_tools] 找到 {len(elements)} 个元素，返回第一个元素: locator: {locator}")
            return elements[0]
        else:
            return None
    except Exception:
        return False

"""在shadow DOM内查找指定selector的元素，支持超时重试。找不到返回None，出错也返回None。"""
def find_shadow_element_by_selector(driver, shadow_elem, selector, timeout_seconds: float = 3):
    """
    在shadow DOM内查找指定selector的元素，支持超时重试。找不到返回None，出错也返回None。
    """
    end_time = time.time() + timeout_seconds
    while True:
        try:
            elem = driver.execute_script(f"""
                let host = arguments[0];
                if (!host || !host.shadowRoot) return null;
                return host.shadowRoot.querySelector('{selector}');
            """, shadow_elem)
            if elem:
                return elem
        except Exception:
            # 可以选择记录日志
            pass
        if time.time() > end_time:
            break
        time.sleep(0.5)  # 每0.5秒重试
    return None


"""使用动作链聚焦输入框、清空内容并输入新值。成功返回 True，失败返回 False。"""
def set_input_value_with_actions(driver, element, new_value) -> bool:
    last_exception = None
    max_attempts = 1
    for attempt in range(max_attempts):
        try:
            # 等待元素可用并可交互
            WebDriverWait(driver, 0.5).until(EC.element_to_be_clickable(element))

            # 确认不是只读也不是禁用的
            is_enabled = element.is_enabled()
            readonly = element.get_attribute("readonly")
            disabled = element.get_attribute("disabled")
            if not is_enabled or readonly or disabled:
                return False

            actions = ActionChains(driver)
            # 点击获取焦点
            actions.move_to_element(element).click().perform()
            # 全选并删除
            actions.key_down(Keys.CONTROL).send_keys('a').key_up(Keys.CONTROL).send_keys(Keys.DELETE).perform()
            # 输入新值
            actions.send_keys(str(new_value)).perform()

            # 检查元素是否获得焦点且已赋值
            time.sleep(0.1)
            # 检查元素当前是否获得焦点
            active = driver.switch_to.active_element
            if active != element:
                # 当前输入框未获得焦点，视为没有设置成功，等待后重试
                time.sleep(0.5)
                continue
            else:
                break
        except Exception as e:
            last_exception = e
            time.sleep(0.2)
            continue  # 尝试下一次
    if not last_exception:
        return True

    # 回退方案：尝试使用元素自带方法
    logger.warning(f" 设置输入值失败: {last_exception}")
    try:
        try:
            element.clear()
        except Exception:
            pass
        element.send_keys(str(new_value))
        time.sleep(0.1)
        if element.get_attribute("value") == str(new_value):
            return True
    except Exception:
        pass
    # 最后回退：JS 直接设置 value（可能不触发输入事件，仅作为兜底）
    try:
        driver.execute_script("arguments[0].value = '';", element)
        driver.execute_script("arguments[0].value = arguments[1];", element, str(new_value))
        time.sleep(0.05)
        if element.get_attribute("value") == str(new_value):
            return True
        return False
    except Exception:
        return False



# 获取指定名称的 cookie 的值，如果没有找到返回 None
def get_cookie_value(driver, name):
    """
    获取指定名称的 cookie 的值，如果没有找到返回 None
    :param driver: Selenium WebDriver 实例
    :param name: cookie 名称
    :return: cookie 的值，或 None
    """
    try:
        cookie = driver.get_cookie(name)
        if cookie and 'value' in cookie:
            return cookie['value']
        return None
    except Exception:
        return None



def simulate_horizontal_swipe(driver, element, x_percent=1.0, steps=20, delay=0.02):
    """
    模拟在给定元素上进行横向滑动（拖动/滑块），x_percent 指滑动的比例（1.0 为从最左到最右, 0.5 为一半, -1.0 为从右到左）。
    不需要手动计算像素，函数会根据元素实际宽度自动滑动对应距离。
    :param driver: Selenium WebDriver 实例
    :param element: 目标 WebElement
    :param x_percent: 滑动距离占元素宽度的百分比，1.0为全部宽度，0.5为一半，-1.0为反方向
    :param steps: 步数，平滑度
    :param delay: 步间暂停
    :return: True/False
    """
    try:
        rect = driver.execute_script(
            "var r=arguments[0].getBoundingClientRect();return {x:r.left, y:r.top, w:r.width, h:r.height};",
            element
        )
        if not rect['w'] or rect['w'] < 10:
            return False
        # x_percent: 滑动占满宽度比例，x_percent=1.0 表示全部宽度
        x_offset = float(x_percent) * rect['w']
        offset_x = max(2, min(rect['w'] // 10, 16))
        per_step = x_offset / steps if steps > 0 else x_offset

        actions = ActionChains(driver)
        actions.move_to_element_with_offset(element, int(offset_x), int(rect['h'] / 2))
        actions.click_and_hold()

        for _ in range(steps):
            actions.move_by_offset(per_step, 0)
            actions.pause(delay)

        actions.release()
        actions.perform()
        return True
    except Exception as e:
        return True
    










# 只用js检测是否能连通互联网
def check_network_connection(driver):
    """仅使用JS（fetch方式）检测网络连通性，失败最多重试3次（不跳转页面）"""
    MAX_RETRIES = 3
    TEST_URL = "https://www.google.com/favicon.ico"  # 可换成任何被墙概率较低的小静态文件
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            # 为防止重复注入，判断 window._binance_network_check 标志，如果已存在直接用，否则注入
            script = f"""
            var callback = arguments[arguments.length - 1];
            if (window._binance_network_check) {{
                // 若已经有执行中的，直接走旧流程（但这种设计只允许单线程逻辑，无需并发防重，足够稳妥）
                var oldCheck = window._binance_network_check;
                if (typeof oldCheck === "function") {{
                    oldCheck(callback);
                }} else {{
                    // 如果已存在结果，直接回调 true
                    callback(true);
                }}
            }} else {{
                window._binance_network_check = function(cb) {{
                    fetch("{TEST_URL}", {{method: "HEAD", mode: "no-cors"}})
                    .then(function() {{
                        cb(true);
                    }})
                    .catch(function(e) {{
                        cb(false);
                    }});
                }};
                window._binance_network_check(callback);
            }}
            """
            network_ok = driver.execute_async_script(script)
            if network_ok:
                return True
            else:
                logger.info(f"[binance_alpha] JS检测互联网不可用（第{attempt}次）")
        except Exception as e:
            logger.error(f"[binance_alpha] JS检测网络异常（第{attempt}次）: {e}")
    logger.info(f"[binance_alpha] JS检测网络连续{MAX_RETRIES}次失败，判断为网络异常。")
    return False













# 用法举例（一般调用方应持有 _last_state 以便多次调用检测）:
# _my_is_loaded_state = {}
# def my_callback(driver): ...
# ... if is_just_loaded(driver, my_callback, _my_is_loaded_state): ...

"""
    判断浏览器是否刚刚经历了跳转、刷新等行为——即页面刚加载好（可结合回调或等待后变化实现更复杂逻辑）。
    driver,
    url_patterns: list[str]
        示例：
        - 字符串：简单包含
        - 正则：形如 /abc/i，拆成正则
        - 列表/元组：任意一个子串包含即可
            "/api/v3/userInfo"
            ["/api/v3/userInfo", "/api/v3/userInfo2"]
            ("/api/v3/userInfo", "/api/v3/userInfo2")
            {"/api/v3/userInfo", "/api/v3/userInfo2"}
"""
def inject_network_listener(
    driver,
    url_patterns
):
    """
    在页面中注入网络监听脚本。如果已注入则不再重复注入。
    同时将请求的参数存入input的params属性。
    """
    # 标准化 url_patterns 到 [{name, pattern}] 格式
    patterns = []
    if isinstance(url_patterns, dict):
        for k, v in url_patterns.items():
            patterns.append({"name": str(k), "pattern": v})
    elif isinstance(url_patterns, (list, tuple)):
        for p in url_patterns:
            if isinstance(p, (list, tuple)) and len(p) == 2:
                patterns.append({"name": str(p[0]), "pattern": p[1]})
            else:
                patterns.append({"name": str(p), "pattern": p})
    else:
        # 兼容字符串形式
        patterns.append({"name": str(url_patterns), "pattern": url_patterns})

    js_patterns = json.dumps(patterns, ensure_ascii=False)

    # 先判断是否已注入
    try:
        injected = driver.execute_script("return !!window._injectedNetworkListener;")
        if injected:
            return  # 已注入，无需再次注入
    except Exception:
        pass  # 异常时直接尝试注入

    def _do_inject(drv):
        js = f"""
        (function() {{
            if (window._injectedNetworkListener) return;
            window._injectedNetworkListener = true;
            var patternObjs = {js_patterns};

            // 返回匹配name,pattern的对象或null
            function matchNamedPattern(url) {{
                try {{
                    for (var i = 0; i < patternObjs.length; i++) {{
                        var pObj = patternObjs[i];
                        var pat = pObj.pattern;
                        if (typeof pat === "string" && pat.startsWith("/") && pat.endsWith("/") && pat.length > 2) {{
                            // 正则 /abc/i
                            var lastSlash = pat.lastIndexOf("/");
                            var regBody = pat.slice(1, lastSlash);
                            var regFlags = pat.slice(lastSlash + 1);
                            var reg = new RegExp(regBody, regFlags);
                            if (reg.test(url)) return pObj;
                        }} else if (typeof pat === "string") {{
                            if (url.includes(pat)) return pObj;
                        }}
                    }}
                    return null;
                }} catch (e) {{
                    for (var i = 0; i < patternObjs.length; i++) {{
                        var pat = patternObjs[i].pattern;
                        if ((url + "").includes(pat)) return patternObjs[i];
                    }}
                    return null;
                }}
            }}

            function ensureHiddenInput(name, value, params) {{
                if (!document.body) return;
                // id必须合法：用encodeURIComponent简易规避
                var safeId = encodeURIComponent(name);
                var input = document.getElementById(safeId);
                if (input) {{
                    input.value = value !== undefined ? value : "";
                    try {{
                        // params属性同步
                        if (typeof params !== "undefined") {{
                            input.setAttribute("params", params);
                        }}
                    }} catch (_e){{}}
                }} else {{
                    input = document.createElement('input');
                    input.type = 'hidden';
                    input.id = safeId;
                    input.value = value !== undefined ? value : "";
                    try {{
                        if (typeof params !== "undefined")
                            input.setAttribute("params", params);
                    }} catch (_e){{}}
                    document.body.appendChild(input);
                }}
            }}

            function handleNetworkResponse(url, responseText, params) {{
                try {{
                    var matched = matchNamedPattern(url);
                    if (matched) {{
                        ensureHiddenInput(matched.name, responseText, params);
                    }}
                }} catch(e) {{}}
            }}

            // Hook XHR
            var orig_open = XMLHttpRequest.prototype.open;
            var orig_send = XMLHttpRequest.prototype.send;
            XMLHttpRequest.prototype.open = function(method, url) {{
                this._url = url;
                this._method = method;
                this._params = undefined;
                this._requestHeaders = {{}};
                return orig_open.apply(this, arguments);
            }};
            XMLHttpRequest.prototype.setRequestHeader = function(header, value) {{
                this._requestHeaders = this._requestHeaders || {{}};
                this._requestHeaders[header] = value;
                // 调用原生方法
                return window.XMLHttpRequest.prototype.__proto__.setRequestHeader.apply(this, arguments);
            }};
            XMLHttpRequest.prototype.send = function(body) {{
                var xhr = this;
                xhr._params = body;
                var orig_onreadystatechange = xhr.onreadystatechange;
                xhr.onreadystatechange = function() {{
                    if (xhr.readyState === 4) {{
                        var _url = xhr._url || "";
                        var matched = matchNamedPattern(_url);
                        if (matched) {{
                            var paramsSummary = "";
                            try {{
                                var paramsObj = {{}};
                                if (xhr._method && (xhr._method + '').toUpperCase() === "GET") {{
                                    // 尝试从URL解析query参数
                                    if (_url.indexOf('?') > -1) {{
                                        paramsObj = _url.split('?')[1];
                                    }}
                                }} else if (typeof xhr._params === "string") {{
                                    paramsObj = xhr._params;
                                }} else if (xhr._params) {{
                                    paramsObj = JSON.stringify(xhr._params);
                                }}
                                paramsSummary = typeof paramsObj === "object" ? JSON.stringify(paramsObj) : (paramsObj + "");
                            }} catch(_e){{}}
                            handleNetworkResponse(_url, xhr.responseText, paramsSummary);
                        }}
                    }}
                    if (orig_onreadystatechange) return orig_onreadystatechange.apply(this, arguments);
                }};
                return orig_send.apply(this, arguments);
            }};

            // Hook fetch
            if (window.fetch) {{
                var orig_fetch = window.fetch;
                window.fetch = function() {{
                    var fetchArgs = arguments;
                    var fetchInput = fetchArgs[0];
                    var url = (typeof fetchInput === 'string') ? fetchInput 
                                : (fetchInput && fetchInput.url ? fetchInput.url : "");
                    var params = undefined;
                    try {{
                        if (fetchArgs[1]) {{
                            if (fetchArgs[1].body) {{
                                params = fetchArgs[1].body;
                            }} else if (fetchInput && fetchInput.body) {{
                                params = fetchInput.body;
                            }}
                        }}
                    }} catch(_e){{}}
                    return orig_fetch.apply(this, arguments).then(function(response) {{
                        try {{
                            var respClone = response.clone();
                            respClone.text().then(function(text) {{
                                var matched = matchNamedPattern(url);
                                if (matched) {{
                                    var paramSummary = "";
                                    try {{
                                        if (typeof params === "string")
                                            paramSummary = params;
                                        else if (params)
                                            paramSummary = JSON.stringify(params);
                                        else
                                            paramSummary = "";
                                    }} catch(_e2){{}}
                                    handleNetworkResponse(url, text, paramSummary);
                                }}
                            }});
                        }} catch(e) {{}}
                        return response;
                    }});
                }};
            }}
        }})();
        """.strip()
        drv.execute_script(js)

    _do_inject(driver)
