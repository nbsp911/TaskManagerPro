"""
注册码对话框
用于显示注册码、输入密匙并进行验证
"""
import sys
import json
import time
from pathlib import Path
from datetime import datetime

from PySide6.QtWidgets import (
    QDialog,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QTextEdit,
    QMessageBox,
    QWidget,
    QApplication,
    QToolTip,
)
from PySide6.QtCore import Qt
from PySide6.QtGui import QIcon

from registration_code import generate_registration_code
from license_key_generator import verify_license_key, DEFAULT_SECRET_KEY
from app_globals import get_now
import logging

logger = logging.getLogger()


class RegisterDialog(QDialog):
    """注册码对话框"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("软件注册")
        self.setModal(True)
        self.resize(600, 300)
        
        # 设置窗口图标
        try:
            icon_path = Path(__file__).resolve().parent / "images" / "icon.ico"
            if icon_path.exists():
                self.setWindowIcon(QIcon(str(icon_path)))
        except Exception:
            pass
        
        # 生成注册码
        self.registration_code = generate_registration_code()
        
        # 初始化UI
        self._setup_ui()
    
    def _setup_ui(self):
        """设置UI界面"""
        layout = QVBoxLayout(self)
        layout.setSpacing(15)
        layout.setContentsMargins(20, 20, 20, 20)
        
        # 注册码部分
        reg_code_layout = QHBoxLayout()
        reg_code_label = QLabel("注册码：")
        reg_code_label.setMinimumWidth(80)
        
        self.reg_code_edit = QLineEdit()
        self.reg_code_edit.setText(self.registration_code)
        self.reg_code_edit.setReadOnly(True)
        self.reg_code_edit.setStyleSheet(
            """
            QLineEdit {
                background-color: #f5f5f5;
                color: #000000;
                border: 1px solid #ccc;
                border-radius: 4px;
                padding: 6px;
                selection-background-color: #007bff;
                selection-color: white;
            }
            QLineEdit:focus {
                border: 1px solid #007bff;
            }
            """
        )
        
        self.copy_btn = QPushButton("复制")
        self.copy_btn.setFixedWidth(80)
        self.copy_btn.clicked.connect(self._on_copy_registration_code)
        self.copy_btn.setStyleSheet(
            """
            QPushButton {
                background-color: #007bff;
                color: white;
                border-radius: 4px;
                border: 1px solid #007bff;
                padding: 6px;
            }
            QPushButton:hover {
                background-color: #0056b3;
            }
            """
        )
        
        reg_code_layout.addWidget(reg_code_label)
        reg_code_layout.addWidget(self.reg_code_edit)
        reg_code_layout.addWidget(self.copy_btn)
        
        # 密匙部分
        license_layout = QVBoxLayout()
        license_label = QLabel("密匙：")
        license_label.setMinimumWidth(80)
        
        self.license_edit = QTextEdit()
        self.license_edit.setPlaceholderText("请输入许可证密匙")
        self.license_edit.setMaximumHeight(100)
        self.license_edit.setStyleSheet(
            """
            QTextEdit {
                border: 1px solid #ddd;
                border-radius: 4px;
                padding: 6px;
            }
            """
        )
        
        license_layout.addWidget(license_label)
        license_layout.addWidget(self.license_edit)
        
        # 注册按钮
        self.register_btn = QPushButton("注册")
        self.register_btn.setFixedHeight(40)
        self.register_btn.clicked.connect(self._on_register)
        self.register_btn.setStyleSheet(
            """
            QPushButton {
                background-color: #28a745;
                color: white;
                border-radius: 4px;
                border: 1px solid #28a745;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #218838;
            }
            QPushButton:disabled {
                background-color: #6c757d;
                border-color: #6c757d;
            }
            """
        )
        
        # 添加到主布局
        layout.addLayout(reg_code_layout)
        layout.addLayout(license_layout)
        layout.addWidget(self.register_btn)
        layout.addStretch()
    
    def _on_copy_registration_code(self):
        """复制注册码到剪贴板"""
        try:
            clipboard = QApplication.clipboard()
            clipboard.setText(self.registration_code)
            
            # 在按钮位置显示提示
            button_pos = self.copy_btn.mapToGlobal(self.copy_btn.rect().center())
            QToolTip.showText(button_pos, "注册码已复制到剪贴板", msecShowTime=2000)
        except Exception as e:
            logger.error(f"复制注册码失败: {e}")
            # 错误时仍使用消息框，因为需要用户知道
            QMessageBox.warning(self, "错误", f"复制失败: {str(e)}")
    
    def _on_register(self):
        """处理注册按钮点击"""
        license_key = self.license_edit.toPlainText()
        
        # 移除所有空白字符（包括空格、换行符、制表符等）
        import re
        license_key = re.sub(r'\s+', '', license_key).strip()
        
        # 检查密匙是否为空
        if not license_key:
            QMessageBox.warning(self, "输入错误", "请输入密匙")
            return
        
        # 检查密匙长度（Base64编码的加密字符串通常长度在44-200字符之间）
        if len(license_key) < 44 or len(license_key) > 500:
            QMessageBox.warning(
                self,
                "输入错误",
                f"密匙长度不正确！\n当前长度：{len(license_key)}，应介于44-500字符之间。\n请检查密匙是否完整。"
            )
            return
        
        # 检查密匙是否为有效的Base64格式
        import re
        if not re.match(r'^[A-Za-z0-9_-]+$', license_key):
            QMessageBox.warning(
                self,
                "输入错误",
                "密匙格式不正确！\n密匙应该只包含字母、数字、连字符和下划线（Base64格式）。"
            )
            return
        
        # 调试：记录输入的密匙和注册码（用于排查问题）
        logger.debug(f"验证密匙 - 注册码: {self.registration_code}, 密匙: {license_key[:16]}...")
        
        # 验证密匙（显式使用默认密钥，确保一致性）
        try:
            is_valid = verify_license_key(license_key, secret_key=DEFAULT_SECRET_KEY)
            
            # 如果验证失败，尝试使用parse_license_key获取详细错误信息
            if not is_valid:
                try:
                    from license_key_generator import parse_license_key
                    is_valid_detail, expiration_detail, message_detail = parse_license_key(
                        license_key, secret_key=DEFAULT_SECRET_KEY
                    )
                    logger.debug(f"详细验证信息 - 有效: {is_valid_detail}, 消息: {message_detail}")
                except Exception as e:
                    logger.debug(f"获取详细验证信息失败: {e}")
            
            if is_valid:
                # 保存密匙到文件
                if self._save_license_key(license_key):
                    QMessageBox.information(
                        self,
                        "注册成功",
                        "密匙验证成功，已保存！\n软件已成功注册。"
                    )
                    self.accept()
                else:
                    QMessageBox.warning(
                        self,
                        "保存失败",
                        "密匙验证成功，但保存失败。\n请检查文件权限。"
                    )
            else:
                QMessageBox.warning(
                    self,
                    "注册失败",
                    "密匙验证失败！\n请检查密匙是否正确或是否已过期。"
                )
        except Exception as e:
            logger.error(f"验证密匙时出错: {e}")
            QMessageBox.critical(
                self,
                "错误",
                f"验证密匙时发生错误：\n{str(e)}"
            )
    
    def _save_license_key(self, license_key: str) -> bool:
        """
        保存密匙到临时文件目录下的taskmanagerpro_locks目录
        
        Args:
            license_key: 许可证密匙
        
        Returns:
            True: 保存成功
            False: 保存失败
        """
        try:
            # 获取项目根目录
            current_file = Path(__file__).resolve()
            project_root = current_file.parent.parent  # 从resouces目录回到项目根目录
            
            # 创建taskmanagerpro_locks目录
            locks_dir = project_root / "tmp"
            locks_dir.mkdir(parents=True, exist_ok=True)
            
            # 保存密匙文件
            license_file = locks_dir / "license.json"
            
            license_data = {
                "registration_code": self.registration_code,
                "license_key": license_key,
                "saved_time": str(Path(__file__).resolve().stat().st_mtime)
            }
            
            with open(license_file, 'w', encoding='utf-8') as f:
                json.dump(license_data, f, ensure_ascii=False, indent=2)
            
            logger.info(f"密匙已保存到: {license_file}")
            return True
            
        except Exception as e:
            logger.error(f"保存密匙失败: {e}")
            return False
    
    def get_registration_code(self) -> str:
        """获取注册码"""
        return self.registration_code


if __name__ == "__main__":
    # 测试代码
    import sys
    from pathlib import Path
    
    # 确保 resouces 目录在 sys.path 中
    _current_dir = Path(__file__).resolve().parent
    _parent_dir = _current_dir.parent
    if str(_current_dir) not in sys.path:
        sys.path.insert(0, str(_current_dir))
    if str(_parent_dir) not in sys.path:
        sys.path.insert(0, str(_parent_dir))
    
    from PySide6.QtWidgets import QApplication
    
    app = QApplication(sys.argv)
    dialog = RegisterDialog()
    dialog.show()
    sys.exit(app.exec())


    # INSERT_YOUR_CODE
def check_registration(parent=None) -> bool:
    """
    检查是否已注册且未过期, 否则弹出注册对话框。
    Returns:
        bool: True-已注册且有效; False-未注册或已过期
    """
    

    try:
        # 锁文件目录和license文件
        project_root = Path(__file__).resolve().parent.parent
        license_file = project_root / "tmp" / "license.json"

        if not license_file.exists():
            QMessageBox.warning(None, "未注册", "您的软件尚未注册。请注册后使用。")
            dlg = RegisterDialog(parent=parent)
            dlg.exec()
            return False

        with open(license_file, "r", encoding="utf-8") as f:
            license_data = json.load(f)
        reg_code = license_data.get("registration_code", "")
        license_key = license_data.get("license_key", "")

        # 验证密钥有效性
        is_valid, expiration, message = None, None, ""
        try:
            from license_key_generator import parse_license_key
            is_valid, expiration, message = parse_license_key(license_key)
        except Exception as e:
            logger.error(f"验证密钥异常: {e}")
            is_valid, expiration, message = False, None, "密钥验证异常"

        now = get_now()
        if not is_valid or (expiration is not None and expiration < now):
            msg = "您的许可证已过期，请重新注册。" if expiration and expiration < now else "您的软件尚未注册或密钥无效，请注册后继续使用。"
            QMessageBox.warning(None, "注册无效", msg)
            dlg = RegisterDialog(parent=parent)
            dlg.exec()
            return False

        return True
    except Exception as e:
        logger.error(f"注册校验失败: {e}")
        QMessageBox.warning(None, "注册异常", "注册校验遇到异常，请重新注册。")
        dlg = RegisterDialog(parent=parent)
        dlg.exec()
        return False
