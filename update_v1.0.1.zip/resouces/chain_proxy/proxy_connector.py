"""
ProxyConnector - 代理连接器
封装不同代理协议（socks5/http/https）的连接逻辑
"""

import asyncio
import socket
import ssl
from typing import Optional, Tuple, Dict, Any
from dataclasses import dataclass
import logging

from data_type import ProxyConfig

logger = logging.getLogger()


class ProxyConnector:
    """代理连接器，封装不同代理协议的连接逻辑"""
    
    def __init__(self, proxy_config: ProxyConfig):
        self.config = proxy_config
        self._connection_pool = {}  # 连接池
        self._max_connections = 10  # 最大连接数
        
    async def connect(self, target_host: str, target_port: int) -> socket.socket:
        """
        建立到目标主机的连接
        
        Args:
            target_host: 目标主机
            target_port: 目标端口
            
        Returns:
            socket: 连接套接字
        """
        try:
            if self.config.type.lower() == 'socks5':
                return await self._connect_socks5(target_host, target_port)
            elif self.config.type.lower() in ['http', 'https']:
                return await self._connect_http(target_host, target_port)
            else:
                raise ValueError(f"不支持的代理类型: {self.config.type}")
        except Exception as e:
            logger.error(f"连接失败: {e}")
            raise
    
    async def create_connection(self, target_host: str, target_port: int) -> Tuple[socket.socket, socket.socket]:
        """
        创建连接对（客户端连接和上游连接）
        
        Args:
            target_host: 目标主机
            target_port: 目标端口
            
        Returns:
            Tuple[socket, socket]: (客户端连接, 上游连接)
        """
        upstream_socket = await self.connect(target_host, target_port)
        return upstream_socket, upstream_socket
    
    def get_proxy_info(self) -> ProxyConfig:
        """获取代理配置信息"""
        return self.config
    
    def is_available(self) -> bool:
        """检查代理是否可用"""
        return self.config.enabled and self.config.server and self.config.port > 0
    
    def get_requests_proxy(self) -> Dict[str, str]:
        """获取 requests 库格式的代理配置"""
        return self.config.requests_proxy
    
    async def _connect_socks5(self, target_host: str, target_port: int) -> socket.socket:
        """建立 SOCKS5 连接"""
        sock = None
        try:
            # 创建套接字
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(self.config.timeout)
            
            # 连接到 SOCKS5 代理服务器
            await asyncio.get_event_loop().run_in_executor(
                None, sock.connect, (self.config.server, self.config.port)
            )
            
            # SOCKS5 握手
            await self._socks5_handshake(sock, target_host, target_port)
            
            return sock
            
        except Exception as e:
            logger.error(f"SOCKS5 连接失败: {e}")
            if sock:
                try:
                    sock.close()
                except:
                    pass
            raise
    
    async def _socks5_handshake(self, sock: socket.socket, target_host: str, target_port: int):
        """SOCKS5 握手过程"""
        try:
            # 发送认证方法
            if self.config.username and self.config.password:
                # 用户名/密码认证
                auth_methods = b'\x05\x02\x00\x02'  # 版本5, 2种方法, 无认证, 用户名密码认证
            else:
                # 无认证
                auth_methods = b'\x05\x01\x00'  # 版本5, 1种方法, 无认证
            
            await asyncio.get_event_loop().run_in_executor(None, sock.send, auth_methods)
            
            # 接收服务器选择的认证方法
            response = await asyncio.get_event_loop().run_in_executor(None, sock.recv, 2)
            if len(response) != 2 or response[0] != 5:
                raise Exception("SOCKS5 握手失败: 无效的服务器响应")
            
            auth_method = response[1]
            
            # 处理认证
            if auth_method == 0:  # 无认证
                pass
            elif auth_method == 2:  # 用户名/密码认证
                if not self.config.username or not self.config.password:
                    raise Exception("SOCKS5 认证失败: 需要用户名和密码认证")
                
                # 发送用户名和密码
                username = self.config.username.encode('utf-8')
                password = self.config.password.encode('utf-8')
                auth_data = b'\x01' + bytes([len(username)]) + username + bytes([len(password)]) + password
                await asyncio.get_event_loop().run_in_executor(None, sock.send, auth_data)
                
                # 接收认证结果
                auth_response = await asyncio.get_event_loop().run_in_executor(None, sock.recv, 2)
                if len(auth_response) != 2 or auth_response[0] != 1:
                    raise Exception("SOCKS5 认证失败: 无效的认证响应")
                if auth_response[1] != 0:
                    raise Exception("SOCKS5 认证失败: 认证被拒绝")
            else:
                raise Exception(f"SOCKS5 认证失败: 不支持的认证方法 {auth_method}")
            
            # 发送连接请求
            connect_request = b'\x05\x01\x00'  # 版本5, 连接命令, 保留字段
            
            # 添加目标地址
            try:
                # 尝试解析为 IP 地址
                target_ip = socket.inet_aton(target_host)
                connect_request += b'\x01' + target_ip  # 地址类型: IPv4
            except socket.error:
                # 域名
                target_host_bytes = target_host.encode('utf-8')
                connect_request += b'\x03' + bytes([len(target_host_bytes)]) + target_host_bytes
            
            # 添加目标端口
            connect_request += target_port.to_bytes(2, 'big')
            
            await asyncio.get_event_loop().run_in_executor(None, sock.send, connect_request)
            
            # 接收连接响应
            connect_response = await asyncio.get_event_loop().run_in_executor(None, sock.recv, 10)
            if len(connect_response) < 2 or connect_response[0] != 5:
                raise Exception("SOCKS5 连接失败: 无效的连接响应")
            
            if connect_response[1] != 0:
                # 提供更详细的错误信息
                error_codes = {
                    1: "一般SOCKS服务器失败",
                    2: "现有规则不允许连接",
                    3: "网络不可达",
                    4: "主机不可达",
                    5: "连接被拒绝",
                    6: "TTL过期",
                    7: "不支持的命令",
                    8: "不支持的地址类型"
                }
                error_msg = error_codes.get(connect_response[1], f"未知错误代码 {connect_response[1]}")
                raise Exception(f"SOCKS5 连接失败: {error_msg} (错误代码: {connect_response[1]})")
                
        except Exception as e:
            logger.error(f"SOCKS5 握手失败: {e}")
            raise
    
    async def _connect_http(self, target_host: str, target_port: int) -> socket.socket:
        """建立 HTTP 代理连接"""
        try:
            # 创建套接字
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(self.config.timeout)
            
            # 连接到 HTTP 代理服务器
            await asyncio.get_event_loop().run_in_executor(
                None, sock.connect, (self.config.server, self.config.port)
            )
            
            # 如果是 HTTPS 代理，建立 TLS 连接
            if self.config.type.lower() == 'https':
                context = ssl.create_default_context()
                sock = context.wrap_socket(sock, server_hostname=self.config.server)
            
            # 发送 HTTP CONNECT 请求
            await self._send_http_connect_request(sock, target_host, target_port)
            
            return sock
            
        except Exception as e:
            logger.error(f"HTTP 代理连接失败: {e}")
            if 'sock' in locals():
                sock.close()
            raise
    
    async def _send_http_connect_request(self, sock: socket.socket, target_host: str, target_port: int):
        """发送 HTTP CONNECT 请求"""
        # 构建 CONNECT 请求
        target = f"{target_host}:{target_port}"
        request = f"CONNECT {target} HTTP/1.1\r\n"
        request += f"Host: {target}\r\n"
        
        # 添加代理认证
        if self.config.username and self.config.password:
            import base64
            auth_string = f"{self.config.username}:{self.config.password}"
            auth_bytes = auth_string.encode('utf-8')
            auth_b64 = base64.b64encode(auth_bytes).decode('utf-8')
            request += f"Proxy-Authorization: Basic {auth_b64}\r\n"
        
        request += "\r\n"
        
        # 发送请求
        await asyncio.get_event_loop().run_in_executor(
            None, sock.send, request.encode('utf-8')
        )
        
        # 接收响应
        response = await asyncio.get_event_loop().run_in_executor(None, sock.recv, 1024)
        response_str = response.decode('utf-8', errors='ignore')
        
        # 检查响应状态
        if not response_str.startswith('HTTP/1.1 200'):
            raise Exception(f"HTTP 代理连接失败: {response_str.split()[0] if response_str else 'Unknown error'}")
    
    async def test_connection(self, test_host: str = "www.google.com", test_port: int = 80) -> Dict[str, Any]:
        """
        测试代理连接
        
        Args:
            test_host: 测试主机
            test_port: 测试端口
            
        Returns:
            Dict: 测试结果
        """
        start_time = asyncio.get_event_loop().time()
        
        try:
            sock = await self.connect(test_host, test_port)
            end_time = asyncio.get_event_loop().time()
            
            # 关闭连接
            sock.close()
            
            return {
                "success": True,
                "response_time": end_time - start_time,
                "proxy_info": {
                    "type": self.config.type,
                    "server": self.config.server,
                    "port": self.config.port
                }
            }
            
        except Exception as e:
            end_time = asyncio.get_event_loop().time()
            return {
                "success": False,
                "error": str(e),
                "response_time": end_time - start_time,
                "proxy_info": {
                    "type": self.config.type,
                    "server": self.config.server,
                    "port": self.config.port
                }
            }
    
    def __str__(self) -> str:
        return f"ProxyConnector({self.config.type}://{self.config.server}:{self.config.port})"
    
    def __repr__(self) -> str:
        return self.__str__()
