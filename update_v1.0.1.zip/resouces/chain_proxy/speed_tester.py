"""
SpeedTester - 代理测速模块
支持异步测速和多线程测速
"""
import asyncio, time, logging, threading, statistics, requests, urllib3
from typing import Dict, List, Any, Optional
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from urllib.parse import urlparse
from enum import Enum
from data_type import ProxyConfig
from chain_proxy.proxy_connector import ProxyConnector

# 禁用SSL警告
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

logger = logging.getLogger(__name__)


class SpeedTestMode(Enum):
    """测速模式枚举"""
    LATENCY_PRIORITY = "latency_priority"    # 延迟优先
    BANDWIDTH_PRIORITY = "bandwidth_priority"  # 带宽优先
    BALANCED = "balanced"                    # 平衡模式
    CUSTOM = "custom"                        # 自定义权重


@dataclass
class SpeedTestResult:
    """测速结果"""
    proxy_id: str
    success: bool
    response_time: float  # 总响应时间
    error: Optional[str] = None
    timestamp: float = 0
    test_url: str = ""
    bytes_received: int = 0
    response_content: str = ""  # 网站返回的内容
    
    # 新增性能指标
    connection_time: float = 0.0  # 连接建立时间
    first_byte_time: float = 0.0  # 首字节时间 (TTFB)
    download_time: float = 0.0    # 下载时间
    bandwidth_bps: float = 0.0    # 带宽 (字节/秒)
    bandwidth_mbps: float = 0.0   # 带宽 (Mbps)
    latency_score: float = 0.0    # 延迟评分 (0-100)
    bandwidth_score: float = 0.0  # 带宽评分 (0-100)
    overall_score: float = 0.0    # 综合评分 (0-100)
    
    def __post_init__(self):
        if self.timestamp == 0:
            self.timestamp = time.time()
        
        # 计算性能指标
        if self.success and self.bytes_received > 0:
            self._calculate_metrics()
    
    def _calculate_metrics(self):
        """计算性能指标"""
        if self.download_time > 0:
            # 计算带宽 (字节/秒)
            self.bandwidth_bps = self.bytes_received / self.download_time
            # 转换为 Mbps
            self.bandwidth_mbps = (self.bandwidth_bps * 8) / (1024 * 1024)
        
        # 计算评分 (0-100分制)
        self._calculate_scores()
    
    def _calculate_scores(self, mode: SpeedTestMode = SpeedTestMode.BALANCED, 
                         latency_weight: float = 0.4, bandwidth_weight: float = 0.6):
        """计算各项评分"""
        # 延迟评分 (延迟越低分数越高)
        # 理想延迟: 50ms = 100分, 500ms = 50分, 1000ms = 0分
        if self.first_byte_time > 0:
            if self.first_byte_time <= 0.05:  # 50ms以内
                self.latency_score = 100
            elif self.first_byte_time <= 0.5:  # 500ms以内
                self.latency_score = max(0, 100 - (self.first_byte_time - 0.05) * 100 / 0.45)
            else:
                self.latency_score = max(0, 50 - (self.first_byte_time - 0.5) * 50 / 0.5)
        
        # 带宽评分 (带宽越高分数越高)
        # 理想带宽: 10Mbps = 100分, 1Mbps = 50分, 0.1Mbps = 0分
        if self.bandwidth_mbps > 0:
            if self.bandwidth_mbps >= 10:  # 10Mbps以上
                self.bandwidth_score = 100
            elif self.bandwidth_mbps >= 1:  # 1Mbps以上
                self.bandwidth_score = 50 + (self.bandwidth_mbps - 1) * 50 / 9
            else:
                self.bandwidth_score = max(0, self.bandwidth_mbps * 50 / 1)
        
        # 根据模式计算综合评分
        if mode == SpeedTestMode.LATENCY_PRIORITY:
            # 延迟优先: 延迟权重80%, 带宽权重20%
            self.overall_score = (self.latency_score * 0.8 + self.bandwidth_score * 0.2)
        elif mode == SpeedTestMode.BANDWIDTH_PRIORITY:
            # 带宽优先: 延迟权重20%, 带宽权重80%
            self.overall_score = (self.latency_score * 0.2 + self.bandwidth_score * 0.8)
        elif mode == SpeedTestMode.BALANCED:
            # 平衡模式: 延迟权重40%, 带宽权重60%
            self.overall_score = (self.latency_score * 0.4 + self.bandwidth_score * 0.6)
        elif mode == SpeedTestMode.CUSTOM:
            # 自定义权重
            total_weight = latency_weight + bandwidth_weight
            if total_weight > 0:
                self.overall_score = (self.latency_score * latency_weight + 
                                    self.bandwidth_score * bandwidth_weight) / total_weight
            else:
                self.overall_score = 0
    
    def get_json_data(self):
        """解析响应内容为JSON数据"""
        if not self.response_content:
            return None
        try:
            import json
            return json.loads(self.response_content)
        except:
            return None
    
    def get_ip_info(self):
        """获取IP信息（支持多种API格式）"""
        json_data = self.get_json_data()
        if json_data and isinstance(json_data, dict):
            # 处理不同的API格式
            if 'origin' in json_data:  # httpbin.org/ip 格式
                return {
                    'ip': json_data.get('origin', ''),
                    'source': 'httpbin.org'
                }
            elif 'ip' in json_data:  # ipinfo.io 或其他格式
                return {
                    'ip': json_data.get('ip', ''),
                    'hostname': json_data.get('hostname', ''),
                    'city': json_data.get('city', ''),
                    'region': json_data.get('region', ''),
                    'country': json_data.get('country', ''),
                    'org': json_data.get('org', ''),
                    'timezone': json_data.get('timezone', ''),
                    'source': 'ipinfo.io'
                }
        return None


class AsyncSpeedTester:
    """异步测速器"""
    
    def __init__(self, max_concurrent: int = 10):
        self.max_concurrent = max_concurrent
        self.semaphore = asyncio.Semaphore(max_concurrent)
    
    async def test_proxy(self, proxy_config: ProxyConfig, 
                        test_url: str = "https://httpbin.org/ip", 
                        timeout: int = 10) -> SpeedTestResult:
        """测试单个代理"""
        async with self.semaphore:
            start_time = time.time()
            
            try:
                # 创建代理连接器
                connector = ProxyConnector(proxy_config)
                
                # 解析测试URL
                parsed_url = urlparse(test_url)
                test_host = parsed_url.hostname
                test_port = parsed_url.port or (443 if parsed_url.scheme == 'https' else 80)
                
                # 执行测速
                result = await connector.test_connection(test_host, test_port)
                
                end_time = time.time()
                
                return SpeedTestResult(
                    proxy_id=proxy_config.id,
                    success=result.get("success", False),
                    response_time=end_time - start_time,
                    timestamp=time.time(),
                    test_url=test_url,
                    bytes_received=result.get("bytes_received", 0)
                )
                
            except Exception as e:
                end_time = time.time()
                return SpeedTestResult(
                    proxy_id=proxy_config.id,
                    success=False,
                    response_time=end_time - start_time,
                    error=str(e),
                    timestamp=time.time(),
                    test_url=test_url
                )
    
    async def test_proxies(self, proxy_configs: List[ProxyConfig], 
                          test_url: str = "https://httpbin.org/ip",
                          timeout: int = 10) -> List[SpeedTestResult]:
        """测试多个代理"""
        tasks = [
            self.test_proxy(proxy, test_url, timeout) 
            for proxy in proxy_configs
        ]
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # 处理异常结果
        processed_results = []
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                processed_results.append(SpeedTestResult(
                    proxy_id=proxy_configs[i].id,
                    success=False,
                    response_time=0,
                    error=str(result),
                    timestamp=time.time(),
                    test_url=test_url
                ))
            else:
                processed_results.append(result)
        
        return processed_results


class ThreadSpeedTester:
    """多线程测速器"""
    
    def __init__(self, max_workers: int = 5, verify_ssl: bool = None):
        self.max_workers = max_workers
        self.executor = ThreadPoolExecutor(max_workers=max_workers)
        self.verify_ssl = verify_ssl  # None=智能判断, True=总是验证, False=从不验证
        self._sessions = {}  # Session池，按代理ID缓存
        self._session_lock = threading.Lock()  # Session池锁
    
    def _get_session(self, proxy_config: ProxyConfig) -> requests.Session:
        """获取或创建Session"""
        with self._session_lock:
            if proxy_config.id not in self._sessions:
                session = requests.Session()
                
                # 设置代理
                proxies = proxy_config.requests_proxy
                session.proxies.update(proxies)
                
                # 设置适配器以优化连接池
                from requests.adapters import HTTPAdapter
                from urllib3.util.retry import Retry
                
                # 为SOCKS代理创建特殊的重试策略
                if proxy_config.type.lower() == 'socks5':
                    retry_strategy = Retry(
                        total=3,
                        backoff_factor=0.5,
                        status_forcelist=[429, 500, 502, 503, 504],
                        allowed_methods=["HEAD", "GET", "OPTIONS"]
                    )
                else:
                    retry_strategy = Retry(
                        total=2,
                        backoff_factor=0.3,
                        status_forcelist=[429, 500, 502, 503, 504]
                    )
                
                adapter = HTTPAdapter(
                    max_retries=retry_strategy,
                    pool_connections=5,
                    pool_maxsize=10,
                    pool_block=False
                )
                
                session.mount("http://", adapter)
                session.mount("https://", adapter)
                
                self._sessions[proxy_config.id] = session
                logger.debug(f"创建新Session: {proxy_config.id}")
            
            return self._sessions[proxy_config.id]
    
    def _warm_up_socks_connection(self, session: requests.Session, proxy_config: ProxyConfig) -> bool:
        """预热SOCKS连接"""
        if proxy_config.type.lower() != 'socks5':
            return True
            
        try:
            logger.debug(f"预热SOCKS连接: {proxy_config.id}")
            
            # 使用简单的HTTP请求来预热连接
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Connection': 'close'  # 强制关闭连接，避免复用
            }
            
            # 发送简单的HEAD请求预热
            response = session.head(
                'http://httpbin.org/status/200',
                timeout=5,
                headers=headers,
                allow_redirects=False
            )
            
            logger.debug(f"SOCKS预热成功: {proxy_config.id}, 状态码: {response.status_code}")
            return response.status_code in [200, 302, 301]
            
        except Exception as e:
            logger.warning(f"SOCKS预热失败: {proxy_config.id} - {e}")
            return False
    
    def test_proxy_sync(self, proxy_config: ProxyConfig, 
                       test_url: str = "https://httpbin.org/ip",
                       timeout: int = 10) -> SpeedTestResult:
        """同步测试单个代理 - 使用Session复用和连接预热"""
        start_time = time.time()
        
        try:
            # 获取或创建Session
            session = self._get_session(proxy_config)
            
            # 对于SOCKS代理，进行预热
            # if proxy_config.type.lower() == 'socks5':
            #     warm_up_success = self._warm_up_socks_connection(session, proxy_config)
            #     if not warm_up_success:
            #         logger.warning(f"SOCKS预热失败，但继续尝试: {proxy_config.id}")
            
            # 执行同步测速
            result = self._sync_test_connection_with_session(session, proxy_config, test_url, timeout)
            
            end_time = time.time()
            
            # 创建测速结果，包含详细的性能指标
            speed_result = SpeedTestResult(
                proxy_id=proxy_config.id,
                success=result.get("success", False),
                response_time=end_time - start_time,
                timestamp=time.time(),
                test_url=test_url,
                bytes_received=result.get("bytes_received", 0),
                connection_time=result.get("connection_time", 0.0),
                first_byte_time=result.get("first_byte_time", 0.0),
                download_time=result.get("download_time", 0.0),
                response_content=result.get("response_content", "")
            )
            
            # 手动触发指标计算（因为__post_init__可能不会在dataclass中正确调用）
            if speed_result.success and speed_result.bytes_received > 0:
                speed_result._calculate_metrics()
            
            return speed_result
            
        except Exception as e:
            end_time = time.time()
            return SpeedTestResult(
                proxy_id=proxy_config.id,
                success=False,
                response_time=end_time - start_time,
                error=str(e),
                timestamp=time.time(),
                test_url=test_url
            )
    
    def _sync_test_connection_with_session(self, session: requests.Session, 
                                         proxy_config: ProxyConfig,
                                         test_url: str, timeout: int) -> Dict[str, Any]:
        """使用Session进行同步测试连接 - 优化SOCKS代理支持"""
        max_retries = 3
        base_retry_delay = 0.5  # SOCKS代理需要更长的初始延迟
        
        for attempt in range(max_retries):
            try:
                # 计算重试延迟，SOCKS代理使用指数退避
                if proxy_config.type.lower() == 'socks5':
                    retry_delay = base_retry_delay * (2 ** attempt)
                else:
                    retry_delay = base_retry_delay + attempt * 0.5
                
                if attempt > 0:
                    logger.debug(f"重试第 {attempt + 1} 次，延迟 {retry_delay:.1f}s: {proxy_config.id}")
                    time.sleep(retry_delay)
                
                # 设置请求头
                headers = {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language': 'en-US,en;q=0.5',
                    'Accept-Encoding': 'gzip, deflate',
                    'Cache-Control': 'no-cache',
                    'Connection': 'keep-alive'
                }
                
                # SSL验证策略
                if self.verify_ssl is None:
                    verify_ssl = self._should_verify_ssl(test_url)
                else:
                    verify_ssl = self.verify_ssl
                
                # 记录开始时间
                start_time = time.time()
                
                # 发送请求，SOCKS代理使用更长的超时时间
                request_timeout = timeout + 5 if proxy_config.type.lower() == 'socks5' else timeout
                
                # 修复：在请求时传递代理参数，而不依赖session.proxies
                proxies = proxy_config.requests_proxy
                response = session.get(
                    test_url,
                    timeout=request_timeout,
                    stream=True,
                    headers=headers,
                    verify=verify_ssl,
                    allow_redirects=True,
                    proxies=proxies  # 关键修复：每次请求都传递代理参数
                )
                
                # 记录首字节时间
                first_byte_time = time.time()
                
                # 读取数据来测试连接和带宽
                bytes_received = 0
                download_start = first_byte_time
                chunk_count = 0
                max_chunks = 10  # 最多读取10个chunk来测试带宽
                response_content = ""
                
                # 检查Content-Type，如果是JSON API，完整读取响应
                content_type = response.headers.get('content-type', '').lower()
                is_json_api = 'application/json' in content_type or 'ipinfo.io' in test_url
                
                for chunk in response.iter_content(chunk_size=1024):
                    bytes_received += len(chunk)
                    chunk_count += 1
                    
                    # 保存响应内容
                    if is_json_api:
                        # 对于JSON API，完整读取响应内容
                        try:
                            response_content += chunk.decode('utf-8', errors='ignore')
                        except:
                            pass
                    else:
                        # 对于HTML页面，限制大小避免内存占用过多
                        if len(response_content) < 10000:  # 最多保存10KB的内容
                            try:
                                response_content += chunk.decode('utf-8', errors='ignore')
                            except:
                                pass
                    
                    # 限制读取量，避免测试时间过长
                    if not is_json_api and (bytes_received > 50 * 1024 or chunk_count >= max_chunks):  # 50KB或10个chunk
                        break
                
                # 记录下载结束时间
                download_end = time.time()
                
                # 计算各项时间指标
                connection_time = first_byte_time - start_time  # 连接建立时间
                first_byte_time_elapsed = first_byte_time - start_time  # 首字节时间
                download_time = download_end - download_start  # 实际下载时间
                
                logger.debug(f"测速成功: {proxy_config.id}, 状态码: {response.status_code}, 字节: {bytes_received}")
                
                return {
                    "success": response.status_code == 200,
                    "bytes_received": bytes_received,
                    "status_code": response.status_code,
                    "connection_time": connection_time,
                    "first_byte_time": first_byte_time_elapsed,
                    "download_time": download_time,
                    "response_content": response_content
                }
                
            except requests.exceptions.ProxyError as e:
                logger.warning(f"代理错误 (尝试 {attempt + 1}/{max_retries}): {proxy_config.id} - {e}")
                if attempt < max_retries - 1:
                    continue
                return {
                    "success": False,
                    "error": f"代理错误: {str(e)}",
                    "bytes_received": 0
                }
            except requests.exceptions.ConnectTimeout as e:
                logger.warning(f"连接超时 (尝试 {attempt + 1}/{max_retries}): {proxy_config.id} - {e}")
                if attempt < max_retries - 1:
                    continue
                return {
                    "success": False,
                    "error": f"连接超时: {str(e)}",
                    "bytes_received": 0
                }
            except requests.exceptions.ReadTimeout as e:
                logger.warning(f"读取超时 (尝试 {attempt + 1}/{max_retries}): {proxy_config.id} - {e}")
                if attempt < max_retries - 1:
                    continue
                return {
                    "success": False,
                    "error": f"读取超时: {str(e)}",
                    "bytes_received": 0
                }
            except requests.exceptions.ConnectionError as e:
                error_msg = str(e)
                logger.warning(f"连接错误 (尝试 {attempt + 1}/{max_retries}): {proxy_config.id} - {error_msg}")
                
                # 对SOCKS代理的特殊处理
                if proxy_config.type.lower() == 'socks5' and 'Connection closed unexpectedly' in error_msg:
                    if attempt < max_retries - 1:
                        logger.info(f"SOCKS连接异常关闭，将重试: {proxy_config.id}")
                        continue
                
                if attempt < max_retries - 1:
                    continue
                return {
                    "success": False,
                    "error": f"连接错误: {error_msg}",
                    "bytes_received": 0
                }
            except Exception as e:
                logger.warning(f"测速异常 (尝试 {attempt + 1}/{max_retries}): {proxy_config.id} - {e}")
                if attempt < max_retries - 1:
                    continue
                return {
                    "success": False,
                    "error": f"测速异常: {str(e)}",
                    "bytes_received": 0
                }
        
        # 如果所有重试都失败了
        return {
            "success": False,
            "error": f"经过 {max_retries} 次重试后仍然失败",
            "bytes_received": 0
        }
    
    def _sync_test_connection(self, connector: ProxyConnector, 
                             test_url: str, timeout: int) -> Dict[str, Any]:
        """同步测试连接 - 精确测量各项性能指标"""
        max_retries = 3
        retry_delay = 1.0
        
        for attempt in range(max_retries):
            try:
                # 解析测试URL
                parsed_url = urlparse(test_url)
                test_host = parsed_url.hostname
                test_port = parsed_url.port or (443 if parsed_url.scheme == 'https' else 80)
                
                # 设置代理
                proxies = connector.get_requests_proxy()
                
                # 设置请求头
                headers = {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language': 'en-US,en;q=0.5',
                    'Accept-Encoding': 'gzip, deflate',
                    'Connection': 'keep-alive'
                }
                
                # SSL验证策略
                if self.verify_ssl is None:
                    verify_ssl = self._should_verify_ssl(test_url)
                else:
                    verify_ssl = self.verify_ssl
                
                # 记录开始时间
                start_time = time.time()
                
                # 发送请求，增加重试机制  
                proxies = connector.get_requests_proxy()
                response = requests.get(
                    test_url,
                    proxies=proxies,
                    timeout=timeout,
                    stream=True,
                    headers=headers,
                    verify=verify_ssl
                )
                
                # 记录首字节时间
                first_byte_time = time.time()
                
                # 读取数据来测试连接和带宽
                bytes_received = 0
                download_start = first_byte_time
                chunk_count = 0
                max_chunks = 10  # 最多读取10个chunk来测试带宽
                response_content = ""
                
                # 检查Content-Type，如果是JSON API，完整读取响应
                content_type = response.headers.get('content-type', '').lower()
                is_json_api = 'application/json' in content_type or 'ipinfo.io' in test_url
                
                for chunk in response.iter_content(chunk_size=1024):
                    bytes_received += len(chunk)
                    chunk_count += 1
                    
                    # 保存响应内容
                    if is_json_api:
                        # 对于JSON API，完整读取响应内容
                        try:
                            response_content += chunk.decode('utf-8', errors='ignore')
                        except:
                            pass
                    else:
                        # 对于HTML页面，限制大小避免内存占用过多
                        if len(response_content) < 10000:  # 最多保存10KB的内容
                            try:
                                response_content += chunk.decode('utf-8', errors='ignore')
                            except:
                                pass
                    
                    # 限制读取量，避免测试时间过长
                    if not is_json_api and (bytes_received > 50 * 1024 or chunk_count >= max_chunks):  # 50KB或10个chunk
                        break
                
                # 记录下载结束时间
                download_end = time.time()
                
                # 计算各项时间指标
                connection_time = first_byte_time - start_time  # 连接建立时间
                first_byte_time_elapsed = first_byte_time - start_time  # 首字节时间
                download_time = download_end - download_start  # 实际下载时间
                
                return {
                    "success": response.status_code == 200,
                    "bytes_received": bytes_received,
                    "status_code": response.status_code,
                    "connection_time": connection_time,
                    "first_byte_time": first_byte_time_elapsed,
                    "download_time": download_time,
                    "response_content": response_content
                }
                
            except requests.exceptions.ProxyError as e:
                logger.warning(f"代理错误 (尝试 {attempt + 1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    time.sleep(retry_delay)
                    continue
                return {
                    "success": False,
                    "error": f"代理错误: {str(e)}",
                    "bytes_received": 0
                }
            except requests.exceptions.ConnectTimeout as e:
                logger.warning(f"连接超时 (尝试 {attempt + 1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    time.sleep(retry_delay)
                    continue
                return {
                    "success": False,
                    "error": f"连接超时: {str(e)}",
                    "bytes_received": 0
                }
            except requests.exceptions.ReadTimeout as e:
                logger.warning(f"读取超时 (尝试 {attempt + 1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    time.sleep(retry_delay)
                    continue
                return {
                    "success": False,
                    "error": f"读取超时: {str(e)}",
                    "bytes_received": 0
                }
            except requests.exceptions.ConnectionError as e:
                logger.warning(f"连接错误 (尝试 {attempt + 1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    time.sleep(retry_delay)
                    continue
                return {
                    "success": False,
                    "error": f"连接错误: {str(e)}",
                    "bytes_received": 0
                }
            except Exception as e:
                logger.warning(f"测速异常 (尝试 {attempt + 1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    time.sleep(retry_delay)
                    continue
                return {
                    "success": False,
                    "error": f"测速异常: {str(e)}",
                    "bytes_received": 0
                }
        
        # 如果所有重试都失败了
        return {
            "success": False,
            "error": f"经过 {max_retries} 次重试后仍然失败",
            "bytes_received": 0
        }
    
    def _should_verify_ssl(self, test_url: str) -> bool:
        """智能SSL验证策略"""
        parsed_url = urlparse(test_url)
        
        # 对于测速场景，通常使用可信的测试网站
        trusted_domains = [
            'ipinfo.io',
            'httpbin.org', 
            'www.google.com',
            'www.baidu.com',
            'api.ipify.org',
            'icanhazip.com'
        ]
        
        # 如果是可信域名，启用SSL验证
        if parsed_url.hostname in trusted_domains:
            return True
        
        # 对于其他域名，为了兼容性，禁用SSL验证
        return False
    
    def test_proxies_parallel(self, proxy_configs: List[ProxyConfig], 
                              test_url: str = "https://ipinfo.io/json",
                              timeout: int = 10) -> List[SpeedTestResult]:
        """并行测试多个代理"""
        futures = []
        
        # 提交所有测试任务
        for proxy_config in proxy_configs:
            future = self.executor.submit(
                self.test_proxy_sync, proxy_config, test_url, timeout
            )
            futures.append(future)
        
        # 收集结果
        results = []
        for future in as_completed(futures):
            try:
                result = future.result()
                results.append(result)
            except Exception as e:
                # 创建错误结果
                results.append(SpeedTestResult(
                    proxy_id="unknown",
                    success=False,
                    response_time=0,
                    error=str(e),
                    timestamp=time.time(),
                    test_url=test_url
                ))
        
        return results
    
    def clear_sessions(self):
        """清理所有Session"""
        with self._session_lock:
            for session in self._sessions.values():
                try:
                    session.close()
                except:
                    pass
            self._sessions.clear()
    
    def get_session_count(self) -> int:
        """获取Session数量"""
        with self._session_lock:
            return len(self._sessions)
    
    def __del__(self):
        """析构函数"""
        try:
            self.clear_sessions()
            self.executor.shutdown(wait=True)
        except:
            pass


class SpeedTestManager:
    """测速管理器 - 支持多种测速模式和科学评分"""
    
    def __init__(self, max_concurrent: int = 10, max_workers: int = 5, verify_ssl: bool = None,
                 default_mode: SpeedTestMode = SpeedTestMode.BALANCED):
        self.async_tester = AsyncSpeedTester(max_concurrent)
        self.thread_tester = ThreadSpeedTester(max_workers, verify_ssl)
        self.test_history: List[SpeedTestResult] = []
        self._lock = threading.Lock()
        self.verify_ssl = verify_ssl
        self.default_mode = default_mode
    
    async def test_proxy_async(self, proxy_config: ProxyConfig, 
                              test_url: str = "https://httpbin.org/ip",
                              timeout: int = 10) -> SpeedTestResult:
        """异步测试单个代理"""
        result = await self.async_tester.test_proxy(proxy_config, test_url, timeout)
        self._save_result(result)
        return result
    
    async def test_proxies_async(self, proxy_configs: List[ProxyConfig], 
                                test_url: str = "https://httpbin.org/ip",
                                timeout: int = 10) -> List[SpeedTestResult]:
        """异步测试多个代理"""
        results = await self.async_tester.test_proxies(proxy_configs, test_url, timeout)
        for result in results:
            self._save_result(result)
        return results
    
    def test_proxy_sync(self, proxy_config: ProxyConfig, 
                       test_url: str = "https://httpbin.org/ip",
                       timeout: int = 10,
                       mode: SpeedTestMode = None) -> SpeedTestResult:
        """同步测试单个代理"""
        if mode is None:
            mode = self.default_mode
            
        result = self.thread_tester.test_proxy_sync(proxy_config, test_url, timeout)
        
        # 重新计算评分（使用指定的模式）
        if result.success and result.bytes_received > 0:
            result._calculate_scores(mode)
        
        self._save_result(result)
        return result
    
    def test_proxies_parallel(self, proxy_configs: List[ProxyConfig], 
                             test_url: str = "https://httpbin.org/ip",
                             timeout: int = 10,
                             mode: SpeedTestMode = None) -> List[SpeedTestResult]:
        """并行测试多个代理"""
        if mode is None:
            mode = self.default_mode
            
        results = self.thread_tester.test_proxies_parallel(proxy_configs, test_url, timeout)
        
        # 重新计算评分（使用指定的模式）
        for result in results:
            if result.success and result.bytes_received > 0:
                result._calculate_scores(mode)
            self._save_result(result)
        
        return results
    
    def _save_result(self, result: SpeedTestResult):
        """保存测速结果"""
        with self._lock:
            self.test_history.append(result)
            # 只保留最近1000条记录
            if len(self.test_history) > 1000:
                self.test_history = self.test_history[-1000:]
    
    def get_test_history(self, proxy_id: Optional[str] = None) -> List[SpeedTestResult]:
        """获取测速历史"""
        with self._lock:
            if proxy_id:
                return [r for r in self.test_history if r.proxy_id == proxy_id]
            return self.test_history.copy()
    
    def get_best_proxies(self, limit: int = 5, 
                        sort_by: str = "overall_score",
                        mode: SpeedTestMode = None) -> List[SpeedTestResult]:
        """获取最佳代理
        
        Args:
            limit: 返回的代理数量
            sort_by: 排序方式 ("overall_score", "latency_score", "bandwidth_score", "response_time", "first_byte_time")
            mode: 测速模式，用于重新计算评分
        """
        with self._lock:
            successful_results = [r for r in self.test_history if r.success]
            
            # 如果指定了模式，重新计算评分
            if mode is not None:
                for result in successful_results:
                    if result.bytes_received > 0:
                        result._calculate_scores(mode)
            
            # 根据指定指标排序
            if sort_by == "overall_score":
                successful_results.sort(key=lambda x: x.overall_score, reverse=True)
            elif sort_by == "latency_score":
                successful_results.sort(key=lambda x: x.latency_score, reverse=True)
            elif sort_by == "bandwidth_score":
                successful_results.sort(key=lambda x: x.bandwidth_score, reverse=True)
            elif sort_by == "response_time":
                successful_results.sort(key=lambda x: x.response_time)
            elif sort_by == "first_byte_time":
                successful_results.sort(key=lambda x: x.first_byte_time)
            else:
                # 默认按综合评分排序
                successful_results.sort(key=lambda x: x.overall_score, reverse=True)
            
            return successful_results[:limit]
    
    def get_proxy_stats(self, proxy_id: str) -> Dict[str, Any]:
        """获取代理统计信息"""
        with self._lock:
            proxy_results = [r for r in self.test_history if r.proxy_id == proxy_id]
            
            if not proxy_results:
                return {
                    "total_tests": 0,
                    "success_rate": 0,
                    "avg_response_time": 0,
                    "min_response_time": 0,
                    "max_response_time": 0
                }
            
            successful_results = [r for r in proxy_results if r.success]
            response_times = [r.response_time for r in successful_results]
            
            return {
                "total_tests": len(proxy_results),
                "success_rate": len(successful_results) / len(proxy_results) * 100,
                "avg_response_time": statistics.mean(response_times) if response_times else 0,
                "min_response_time": min(response_times) if response_times else 0,
                "max_response_time": max(response_times) if response_times else 0,
                "last_test": max(proxy_results, key=lambda x: x.timestamp).timestamp
            }
    
    def clear_history(self):
        """清空测速历史"""
        with self._lock:
            self.test_history.clear()
    
    def clear_sessions(self):
        """清理所有Session"""
        self.thread_tester.clear_sessions()
    
    def get_session_count(self) -> int:
        """获取Session数量"""
        return self.thread_tester.get_session_count()
    
    def get_latency_optimized_proxies(self, limit: int = 5) -> List[SpeedTestResult]:
        """获取延迟优化的代理（适合实时应用）"""
        return self.get_best_proxies(limit, "latency_score", SpeedTestMode.LATENCY_PRIORITY)
    
    def get_bandwidth_optimized_proxies(self, limit: int = 5) -> List[SpeedTestResult]:
        """获取带宽优化的代理（适合大文件下载）"""
        return self.get_best_proxies(limit, "bandwidth_score", SpeedTestMode.BANDWIDTH_PRIORITY)
    
    def get_balanced_proxies(self, limit: int = 5) -> List[SpeedTestResult]:
        """获取平衡性能的代理（适合一般用途）"""
        return self.get_best_proxies(limit, "overall_score", SpeedTestMode.BALANCED)
    
    def get_custom_weighted_proxies(self, limit: int = 5, 
                                  latency_weight: float = 0.4, 
                                  bandwidth_weight: float = 0.6) -> List[SpeedTestResult]:
        """获取自定义权重的代理"""
        with self._lock:
            successful_results = [r for r in self.test_history if r.success]
            
            # 使用自定义权重重新计算评分
            for result in successful_results:
                if result.bytes_received > 0:
                    result._calculate_scores(SpeedTestMode.CUSTOM, latency_weight, bandwidth_weight)
            
            # 按综合评分排序
            successful_results.sort(key=lambda x: x.overall_score, reverse=True)
            return successful_results[:limit]
    
    def export_results(self, filename: str):
        """导出测速结果"""
        import json
        
        with self._lock:
            results_data = []
            for result in self.test_history:
                results_data.append({
                    "proxy_id": result.proxy_id,
                    "success": result.success,
                    "response_time": result.response_time,
                    "error": result.error,
                    "timestamp": result.timestamp,
                    "test_url": result.test_url,
                    "bytes_received": result.bytes_received,
                    "connection_time": result.connection_time,
                    "first_byte_time": result.first_byte_time,
                    "download_time": result.download_time,
                    "bandwidth_bps": result.bandwidth_bps,
                    "bandwidth_mbps": result.bandwidth_mbps,
                    "latency_score": result.latency_score,
                    "bandwidth_score": result.bandwidth_score,
                    "overall_score": result.overall_score
                })
            
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(results_data, f, indent=2, ensure_ascii=False)
    
    def __str__(self) -> str:
        return f"SpeedTestManager(history={len(self.test_history)})"
    
    def __repr__(self) -> str:
        return self.__str__()
