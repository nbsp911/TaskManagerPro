"""
UpstreamInstance - 上游实例
核心类，封装一个本地 HTTP 代理入口与其上游代理配置
"""

import asyncio
import threading
import time
import logging
from typing import Optional, Dict, Any

from data_type import ProxyConfig
from file_oper import FileOper
from chain_proxy.proxy_connector import ProxyConnector

logger = logging.getLogger()


class UpstreamInstance:
    """上游实例，每个实例只对应一个 ProxyConfig"""
    
    def __init__(self, proxy_id: str):
        self.proxy_id = proxy_id
        self.file_oper = FileOper()
        self.config: Optional[ProxyConfig] = None
        self.proxy_connector: Optional[ProxyConnector] = None
        self._running = False
        self._lock = threading.RLock()
        self._server = None
        self._loop = None
        self._thread = None
        
        # 统计信息
        self._stats = {
            "connections": 0,
            "bytes_sent": 0,
            "bytes_received": 0,
            "start_time": None,
            "last_activity": None,
            "total_connections": 0,
            "failed_connections": 0,
            "active_connections": 0
        }
        
        # 连接池
        self._connection_pool = []
        self._max_pool_size = 10
        
        # 从 FileOper 获取代理配置
        self._load_config()
    
    def _load_config(self):
        """从 FileOper 加载配置"""
        try:
            self.config = self.file_oper.get_proxy_config_by_id(self.proxy_id)
            if self.config:
                self.proxy_connector = ProxyConnector(self.config)
                logger.info(f"已加载代理配置: {self.proxy_id}")
            else:
                logger.error(f"未找到代理配置: {self.proxy_id}")
        except Exception as e:
            logger.error(f"加载配置失败: {e}")
    
    async def start(self) -> bool:
        """启动实例（在实例线程中运行）"""
        with self._lock:
            if self._running:
                logger.warning(f"实例 {self.proxy_id} 已在运行")
                return True
            
            if not self.config or not self.proxy_connector:
                logger.error(f"实例 {self.proxy_id} 配置无效")
                return False
            
            # 检查是否启用端口转发
            port_forward = getattr(self.config, 'port_forward', True)
            
            try:
                if port_forward:
                    # 启用端口转发，创建本地代理服务器
                    self._server = await asyncio.start_server(
                        self.handle_client_connection,
                        self.config.listen_host,
                        self.config.listen_port or 0  # 0 表示自动分配端口
                    )
                    
                    # 获取实际监听的端口
                    if not self.config.listen_port:
                        self.config.listen_port = self._server.sockets[0].getsockname()[1]
                        # 更新配置到 FileOper
                        self.file_oper.update_proxy_config(self.config)
                    
                    logger.info(f"实例 {self.proxy_id} 已启动，监听 {self.config.listen_host}:{self.config.listen_port}")
                else:
                    # 不启用端口转发，直接使用原始代理，不需要本地服务器
                    self._server = None
                    logger.info(f"实例 {self.proxy_id} 已启动，直连模式: {self.config.server}:{self.config.port}")
                
                self._running = True
                self._stats["start_time"] = time.time()
                return True
                
            except Exception as e:
                logger.error(f"启动实例失败: {e}")
                return False
    
    async def stop(self) -> bool:
        """停止实例（在实例线程中运行）"""
        with self._lock:
            if not self._running:
                logger.debug(f"实例 {self.proxy_id} 未运行")
                return True
            
            try:
                # 设置停止标志
                self._running = False
                
                # 关闭服务器
                if self._server:
                    try:
                        # 先关闭服务器
                        self._server.close()
                        
                        # 等待服务器关闭，但设置较短的超时
                        await asyncio.wait_for(self._server.wait_closed(), timeout=1.0)
                        logger.debug(f"服务器已关闭: {self.proxy_id}")
                        
                    except asyncio.TimeoutError:
                        logger.warning(f"服务器关闭超时，强制关闭: {self.proxy_id}")
                        # 强制关闭所有套接字
                        for sock in self._server.sockets:
                            try:
                                sock.close()
                            except:
                                pass
                    except Exception as e:
                        logger.debug(f"服务器关闭异常: {e}")
                    finally:
                        self._server = None
                
                # 取消所有未完成的任务
                try:
                    loop = asyncio.get_event_loop()
                    tasks = [task for task in asyncio.all_tasks(loop) if not task.done()]
                    if tasks:
                        logger.debug(f"取消 {len(tasks)} 个未完成的任务: {self.proxy_id}")
                        for task in tasks:
                            if not task.done():
                                task.cancel()
                        
                        # 等待任务取消完成，设置超时
                        try:
                            await asyncio.wait_for(
                                asyncio.gather(*tasks, return_exceptions=True),
                                timeout=2.0
                            )
                        except asyncio.TimeoutError:
                            logger.warning(f"任务取消超时: {self.proxy_id}")
                            
                except Exception as e:
                    logger.debug(f"取消任务异常: {e}")
                
                self._stats["last_activity"] = time.time()
                
                logger.info(f"实例 {self.proxy_id} 已停止")
                return True
                
            except Exception as e:
                logger.error(f"停止实例失败: {e}")
                return False
    
    def is_running(self) -> bool:
        """检查实例是否运行中"""
        with self._lock:
            return self._running
    
    def get_proxy_addr(self) -> str:
        """返回代理地址"""
        if self.config:
            # 根据端口转发设置决定返回的地址
            port_forward = getattr(self.config, 'port_forward', True)
            if port_forward:
                # 启用端口转发，返回本地监听地址
                return f"{self.config.listen_host}:{self.config.listen_port}"
            else:
                # 不启用端口转发，返回原始代理服务器地址
                return f"{self.config.server}:{self.config.port}"
        return ""
    
    def get_listen_port(self) -> int:
        """获取监听端口"""
        if self.config:
            return self.config.listen_port or 0
        return 0
    
    async def update_proxy(self) -> bool:
        """更新代理配置"""
        with self._lock:
            try:
                # 从 FileOper 获取最新配置
                proxy_config = self.file_oper.get_proxy_config_by_id(self.proxy_id)
                if not proxy_config:
                    logger.error(f"未找到代理配置: {self.proxy_id}")
                    return False
                
                # 更新配置
                self.config = proxy_config
                self.proxy_connector = ProxyConnector(proxy_config)
                
                logger.info(f"已更新代理配置: {self.proxy_id}")
                return True
                
            except Exception as e:
                logger.error(f"更新代理配置失败: {e}")
                return False
    
    def get_proxy(self) -> Optional[ProxyConfig]:
        """获取当前代理配置"""
        with self._lock:
            return self.config
    
    async def test_speed(self) -> Dict[str, Any]:
        """测试当前代理的速度"""
        if not self.proxy_connector:
            return {
                "success": False,
                "error": "代理连接器未初始化",
                "timestamp": time.time()
            }
        
        try:
            result = await self.proxy_connector.test_connection()
            return result
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "timestamp": time.time()
            }
    
    async def test_speed_async(self) -> Dict[str, Any]:
        """异步测速，不阻塞"""
        # 在后台线程中执行测速
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self._test_speed_sync)
    
    def _test_speed_sync(self) -> Dict[str, Any]:
        """同步测速方法"""
        if not self.proxy_connector:
            return {"success": False, "error": "No proxy configured"}
        
        try:
            start_time = time.time()
            # 这里可以实现同步测速逻辑
            # 暂时返回模拟结果
            end_time = time.time()
            
            return {
                "success": True,
                "response_time": end_time - start_time,
                "timestamp": time.time()
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "timestamp": time.time()
            }
    
    async def handle_client_connection(self, client_reader, client_writer):
        """处理客户端连接（协程）"""
        connection_id = f"{self.proxy_id}_{int(time.time() * 1000)}"
        upstream_reader = None
        upstream_writer = None
        
        try:
            # 检查实例是否仍在运行
            if not self._running:
                logger.debug(f"实例已停止，拒绝新连接: {connection_id}")
                await self._send_error_response(client_writer, "503 Service Unavailable")
                return
            
            with self._lock:
                self._stats["connections"] += 1
                self._stats["active_connections"] += 1
                self._stats["total_connections"] += 1
                self._stats["last_activity"] = time.time()
            
            logger.debug(f"处理客户端连接: {connection_id}")
            
            # 读取客户端请求
            request_data = await asyncio.wait_for(
                client_reader.read(4096), 
                timeout=self.config.timeout if self.config else 30
            )
            if not request_data:
                logger.debug(f"客户端连接已关闭: {connection_id}")
                return
            
            # 解析请求
            request_info = self._parse_request(request_data)
            if not request_info:
                logger.warning(f"无法解析请求: {connection_id}")
                await self._send_error_response(client_writer, "400 Bad Request")
                return
            
            # 检查连接数限制
            if self.config and self._stats["connections"] > self.config.max_connections:
                logger.warning(f"连接数超限: {connection_id}")
                await self._send_error_response(client_writer, "503 Service Unavailable")
                return
            
            # 连接到上游代理
            upstream_reader, upstream_writer = await self._connect_to_upstream(
                request_info["host"], request_info["port"]
            )
            
            # 检查返回值
            if upstream_reader is None or upstream_writer is None:
                logger.error(f"无法连接到上游代理: {connection_id}")
                with self._lock:
                    self._stats["failed_connections"] += 1
                await self._send_error_response(client_writer, "502 Bad Gateway")
                return
            
            logger.debug(f"上游代理连接成功: {connection_id}")
            
            # 对于 CONNECT 请求，发送成功响应
            if request_info["method"] == "CONNECT":
                await self._send_connect_success_response(client_writer)
                # CONNECT 请求不需要转发初始数据，直接开始双向转发
                await self._forward_connect_data(
                    client_reader, client_writer,
                    upstream_reader, upstream_writer,
                    connection_id
                )
            else:
                # 转发数据
                await self._forward_data(
                    client_reader, client_writer,
                    upstream_reader, upstream_writer,
                    connection_id, request_data
                )
            
        except asyncio.TimeoutError:
            logger.warning(f"连接超时: {connection_id}")
            await self._send_error_response(client_writer, "408 Request Timeout")
        except ConnectionResetError:
            logger.debug(f"连接被重置: {connection_id}")
        except Exception as e:
            logger.error(f"处理连接异常: {e}")
            try:
                await self._send_error_response(client_writer, "500 Internal Server Error")
            except:
                pass
        finally:
            # 清理资源
            try:
                if upstream_writer:
                    upstream_writer.close()
                    await upstream_writer.wait_closed()
            except:
                pass
            
            try:
                client_writer.close()
                await client_writer.wait_closed()
            except:
                pass
            
            with self._lock:
                self._stats["connections"] = max(0, self._stats["connections"] - 1)
                self._stats["active_connections"] = max(0, self._stats["active_connections"] - 1)
    
    def _parse_request(self, request_data: bytes) -> Optional[Dict[str, Any]]:
        """解析 HTTP 请求"""
        try:
            request_str = request_data.decode('utf-8', errors='ignore')
            lines = request_str.split('\r\n')
            
            if not lines:
                return None
            
            # 解析请求行
            request_line = lines[0]
            parts = request_line.split()
            if len(parts) < 3:
                return None
            
            method = parts[0]
            url = parts[1]
            version = parts[2]
            
            # 解析 Host 头
            host = None
            port = 80
            is_https = False
            
            for line in lines[1:]:
                line_lower = line.lower()
                if line_lower.startswith('host:'):
                    host_port = line[5:].strip()
                    if ':' in host_port:
                        host, port_str = host_port.split(':', 1)
                        port = int(port_str)
                    else:
                        host = host_port
                        # 根据协议设置默认端口
                        if method == "CONNECT":
                            port = 443  # HTTPS
                        else:
                            port = 80   # HTTP
                elif line_lower.startswith('x-forwarded-proto:'):
                    if 'https' in line_lower:
                        is_https = True
            
            if not host:
                return None
            
            # 处理 CONNECT 方法（用于 HTTPS 代理）
            if method == "CONNECT":
                # CONNECT 方法中，URL 就是 host:port
                if ':' in url:
                    host, port_str = url.split(':', 1)
                    port = int(port_str)
                else:
                    host = url
                    port = 443
            
            return {
                "method": method,
                "url": url,
                "version": version,
                "host": host,
                "port": port,
                "is_https": is_https,
                "raw_request": request_data
            }
            
        except Exception as e:
            logger.error(f"解析请求失败: {e}")
            return None
    
    async def _connect_to_upstream(self, target_host: str, target_port: int):
        """连接到上游代理"""
        try:
            # 检查实例是否仍在运行
            if not self._running:
                logger.debug(f"实例已停止，跳过连接: {self.proxy_id}")
                return None, None
                
            if not self.proxy_connector:
                logger.error(f"代理连接器未初始化: {self.proxy_id}")
                return None, None
            
            if not self.config:
                logger.error(f"代理配置未加载: {self.proxy_id}")
                return None, None
            
            logger.debug(f"连接到上游代理: {self.config.type}://{self.config.server}:{self.config.port}")
            
            # 使用 ProxyConnector 建立连接
            upstream_socket = await self.proxy_connector.connect(target_host, target_port)
            
            if not upstream_socket:
                logger.error(f"上游代理连接失败: {self.proxy_id}")
                return None, None
            
            # 创建读写流
            try:
                upstream_reader, upstream_writer = await asyncio.open_connection(
                    sock=upstream_socket
                )
                
                # 检查读写流是否有效
                if upstream_reader is None or upstream_writer is None:
                    logger.error(f"创建读写流失败: {self.proxy_id}")
                    return None, None
                
                logger.debug(f"上游代理连接成功: {self.proxy_id}")
                return upstream_reader, upstream_writer
                
            except Exception as e:
                logger.error(f"创建读写流异常: {self.proxy_id} - {e}")
                return None, None
            
        except Exception as e:
            logger.error(f"连接上游代理失败: {e}")
            import traceback
            traceback.print_exc()
            return None, None
        
        # 确保不会返回 None 值
        logger.error(f"连接上游代理失败: {self.proxy_id} - 未知错误")
        return None, None
    
    async def _send_connect_success_response(self, client_writer):
        """发送 CONNECT 成功响应"""
        try:
            response = "HTTP/1.1 200 Connection established\r\n\r\n"
            client_writer.write(response.encode('utf-8'))
            await client_writer.drain()
            logger.debug("CONNECT 成功响应已发送")
        except Exception as e:
            logger.debug(f"发送 CONNECT 成功响应失败: {e}")
    
    async def _send_error_response(self, client_writer, error_message: str):
        """发送错误响应"""
        try:
            response = f"HTTP/1.1 {error_message}\r\n"
            response += "Content-Type: text/plain\r\n"
            response += "Content-Length: 0\r\n"
            response += "Connection: close\r\n"
            response += "\r\n"
            
            client_writer.write(response.encode('utf-8'))
            await client_writer.drain()
        except Exception as e:
            logger.debug(f"发送错误响应失败: {e}")
    
    async def _forward_connect_data(self, client_reader, client_writer, 
                                  upstream_reader, upstream_writer, connection_id: str):
        """转发 CONNECT 请求的数据（隧道模式）"""
        try:
            # 检查参数有效性
            if not upstream_reader or not upstream_writer:
                logger.error(f"上游连接无效: {connection_id}")
                return
            
            if not client_reader or not client_writer:
                logger.error(f"客户端连接无效: {connection_id}")
                return
            
            logger.debug(f"开始 CONNECT 数据转发: {connection_id}")
            
            # 双向转发数据（隧道模式）
            async def forward_to_upstream():
                try:
                    while True:
                        data = await asyncio.wait_for(
                            client_reader.read(4096),
                            timeout=self.config.timeout if self.config else 30
                        )
                        if not data:
                            break
                        upstream_writer.write(data)
                        await upstream_writer.drain()
                        
                        with self._lock:
                            self._stats["bytes_sent"] += len(data)
                            self._stats["last_activity"] = time.time()
                except asyncio.TimeoutError:
                    logger.debug(f"上游转发超时: {connection_id}")
                except Exception as e:
                    logger.debug(f"上游转发异常: {e}")
            
            async def forward_to_client():
                try:
                    while True:
                        data = await asyncio.wait_for(
                            upstream_reader.read(4096),
                            timeout=self.config.timeout if self.config else 30
                        )
                        if not data:
                            break
                        client_writer.write(data)
                        await client_writer.drain()
                        
                        with self._lock:
                            self._stats["bytes_received"] += len(data)
                            self._stats["last_activity"] = time.time()
                except asyncio.TimeoutError:
                    logger.debug(f"客户端转发超时: {connection_id}")
                except Exception as e:
                    logger.debug(f"客户端转发异常: {e}")
            
            # 并发转发，使用超时控制
            try:
                await asyncio.wait_for(
                    asyncio.gather(
                        forward_to_upstream(),
                        forward_to_client(),
                        return_exceptions=True
                    ),
                    timeout=self.config.timeout if self.config else 30
                )
            except asyncio.TimeoutError:
                logger.debug(f"CONNECT 转发超时: {connection_id}")
            
        except Exception as e:
            logger.error(f"CONNECT 转发异常: {connection_id} - {e}")
        finally:
            # 清理资源
            try:
                if upstream_writer:
                    upstream_writer.close()
                    await upstream_writer.wait_closed()
            except:
                pass
            
            try:
                client_writer.close()
                await client_writer.wait_closed()
            except:
                pass

    async def _forward_data(self, client_reader, client_writer, 
                          upstream_reader, upstream_writer, connection_id: str, initial_data: bytes):
        """转发数据"""
        try:
            # 检查参数有效性
            if not upstream_reader or not upstream_writer:
                logger.error(f"上游连接无效: {connection_id}")
                return
            
            if not client_reader or not client_writer:
                logger.error(f"客户端连接无效: {connection_id}")
                return
            
            logger.debug(f"开始转发数据: {connection_id}")
            
            # 发送初始请求到上游
            try:
                upstream_writer.write(initial_data)
                await upstream_writer.drain()
                logger.debug(f"初始数据发送成功: {connection_id}")
                    
            except Exception as e:
                logger.error(f"发送初始数据失败: {connection_id} - {e}")
                import traceback
                traceback.print_exc()
                return
            
            # 双向转发数据
            async def forward_to_upstream():
                try:
                    while True:
                        data = await asyncio.wait_for(
                            client_reader.read(4096),
                            timeout=self.config.timeout if self.config else 30
                        )
                        if not data:
                            break
                        upstream_writer.write(data)
                        await upstream_writer.drain()
                        
                        with self._lock:
                            self._stats["bytes_sent"] += len(data)
                            self._stats["last_activity"] = time.time()
                except asyncio.TimeoutError:
                    logger.debug(f"上游转发超时: {connection_id}")
                except Exception as e:
                    logger.debug(f"上游转发异常: {e}")
            
            async def forward_to_client():
                try:
                    while True:
                        data = await asyncio.wait_for(
                            upstream_reader.read(4096),
                            timeout=self.config.timeout if self.config else 30
                        )
                        if not data:
                            break
                        await client_writer.write(data)
                        await client_writer.drain()
                        
                        with self._lock:
                            self._stats["bytes_received"] += len(data)
                            self._stats["last_activity"] = time.time()
                except asyncio.TimeoutError:
                    logger.debug(f"客户端转发超时: {connection_id}")
                except Exception as e:
                    logger.debug(f"客户端转发异常: {e}")
            
            # 并发转发，使用超时控制
            try:
                await asyncio.wait_for(
                    asyncio.gather(
                        forward_to_upstream(),
                        forward_to_client(),
                        return_exceptions=True
                    ),
                    timeout=self.config.timeout * 2 if self.config else 60
                )
            except asyncio.TimeoutError:
                logger.warning(f"转发超时: {connection_id}")
            
        except Exception as e:
            logger.error(f"转发数据失败: {e}")
        finally:
            try:
                upstream_writer.close()
                await upstream_writer.wait_closed()
            except:
                pass
    
    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        with self._lock:
            return self._stats.copy()
    
    def get_config(self) -> Dict[str, Any]:
        """获取配置信息"""
        if self.config:
            return self.config.to_dict()
        return {}
    
    def get_status(self) -> str:
        """获取状态"""
        if self._running:
            return "running"
        return "stopped"
    
    def get_thread_info(self) -> Dict[str, Any]:
        """获取线程信息"""
        if self._thread:
            return {
                "thread_id": self._thread.ident,
                "thread_name": self._thread.name,
                "is_alive": self._thread.is_alive()
            }
        return {}
    
    def __str__(self) -> str:
        return f"UpstreamInstance({self.proxy_id}, {self.get_status()})"
    
    def __repr__(self) -> str:
        return self.__str__()
