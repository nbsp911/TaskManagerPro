

from typing import Optional, Tuple
from pathlib import Path
from datetime import datetime
import json

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (
    QAbstractItemView,
    QComboBox,
    QDialog,
    QProgressDialog,
    QHBoxLayout,
    QHeaderView,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from group_manager import open_group_dialog
from config_dialog import ConfigDialog
from tools import *
from selenium_tools import *
from file_oper import FileOper
from slot_events import ConfigDataSignal, DriverManagerSignal, ScriptSignal, ProxyManagerSignal, LicenseSignal
from data_type import ConfigData, DriverSessionStatus, DRIVER_SESSION_STATUS_LABELS, DRIVER_SESSION_STATUS_COLORS, ProxyTestStatus, ProxyStatus
from driver_manager import DriverManager
from scripts.scripts_config import get_scripts_config, get_script_config_by_id
from registration_code import generate_registration_code
from license_key_generator import parse_license_key, DEFAULT_SECRET_KEY
from app_globals import get_now

import logging
logger = logging.getLogger()

# 任务表列索引常量
COL_NAME = 0
COL_SCRIPT = 1
COL_GROUP = 2
COL_PROXY = 3
COL_LATENCY = 4
COL_STATUS = 5
COL_PROCESS = 6
COL_INFO = 7
COL_OPS = 8

# 延迟超时阈值常量
LATENCY_TIMEOUT_THRESHOLD = 10000  # 延迟超时阈值(毫秒)


class TaskManagerTab(QWidget):
    """任务管理器"""
    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        # 日志使用事件总线发送，无需在此注册

        ConfigDataSignal.config_added.connect(self._on_config_added)
        ConfigDataSignal.config_updated.connect(self._on_config_updated)
        # ConfigDataSignal.config_deleted.connect(self._on_config_deleted)

        DriverManagerSignal.status_changed.connect(self._on_driver_status_changed)
        ScriptSignal.script_warning.connect(self._on_script_warning)
        ScriptSignal.score_changed.connect(self._on_score_changed)
        ProxyManagerSignal.proxy_latency_tested.connect(self._on_proxy_latency_tested)
        LicenseSignal.license_status_changed.connect(self._on_license_status_changed)

        self._stop_progress: dict[str, QProgressDialog] = {}

        self._setup_ui()

    
    """设置UI"""
    def _setup_ui(self) -> None:
        layout = QVBoxLayout(self)

        button_layout = QHBoxLayout()
        # 分组管理按钮（右对齐，位于“添加”前面）
        # 先放置左侧筛选控件，之后通过弹性伸展把以下按钮推到右侧
        # 名称搜索框（左侧）
        self.search_edit = QLineEdit()
        try:
            self.search_edit.setPlaceholderText("按名称搜索...")
            self.search_edit.setFixedWidth(220)
        except Exception:
            pass
        button_layout.addWidget(self.search_edit)
        # 脚本筛选下拉
        self.script_filter_combo = QComboBox()
        try:
            self.script_filter_combo.setFixedWidth(200)
        except Exception:
            pass
        self.script_filter_combo.addItem("全部脚本", None)
        try:
            scripts = get_scripts_config()
            for script in scripts:
                self.script_filter_combo.addItem(script.name, script.id)
        except Exception:
            pass
        button_layout.addWidget(self.script_filter_combo)
        # 状态筛选下拉
        self.status_filter_combo = QComboBox()
        try:
            self.status_filter_combo.setFixedWidth(160)
        except Exception:
            pass

        self.status_filter_combo.addItem("全部状态", None)

        # 读出 DriverSessionStatus 所有成员
        for status in DriverSessionStatus:
            code = status.value
            label = DRIVER_SESSION_STATUS_LABELS.get(code, code)
            self.status_filter_combo.addItem(label, code)

        button_layout.addWidget(self.status_filter_combo)
        
        # 分组筛选下拉
        self.group_filter_combo = QComboBox()
        try:
            self.group_filter_combo.setFixedWidth(180)
        except Exception:
            pass
        button_layout.addWidget(self.group_filter_combo)
        self._update_groups()

        # 右侧"添加"按钮与"分组"按钮
        button_layout.addStretch(1)
        # 注册状态按钮（在分组管理按钮前面）
        self.license_status_button = QPushButton("*未注册")
        try:
            self.license_status_button.setFixedWidth(140)
        except Exception:
            pass
        self.license_status_button.clicked.connect(self._on_license_status_clicked)
        self._update_license_status_button()  # 初始化状态
        button_layout.addWidget(self.license_status_button)
        
        self.group_button = QPushButton("分组管理")
        try:
            self.group_button.setFixedWidth(96)
        except Exception:
            pass
        self.group_button.clicked.connect(self._open_group_dialog)
        button_layout.addWidget(self.group_button)
        self.add_button = QPushButton("添加任务")
        try:
            self.add_button.setFixedWidth(96)
        except Exception:
            pass
        button_layout.addWidget(self.add_button)
        layout.addLayout(button_layout)

        self.table = QTableWidget(0, 9)
        self.table.setHorizontalHeaderLabels([
            "名称",
            "脚本",
            "分组",
            "代理",
            "延迟",
            "状态",
            "进程",
            "信息",
            "操作",
        ])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setSelectionMode(QTableWidget.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        # 默认不排序，点击列头后再启用
        self.table.setSortingEnabled(False)
        # 连接双击事件
        self.table.cellDoubleClicked.connect(self._on_cell_double_clicked)
        try:
            # 初始隐藏排序箭头，首次点击后再显示与排序
            self.table.horizontalHeader().setSortIndicatorShown(False)
            self.table.horizontalHeader().sectionClicked.connect(self._on_header_clicked)
        except Exception:
            pass
        # 操作列宽度更大：按内容自适应该列
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(COL_OPS, QHeaderView.ResizeToContents)
        # 名称列加宽
        try:
            header.setSectionResizeMode(COL_NAME, QHeaderView.Interactive)
            self.table.setColumnWidth(COL_NAME, 220)
        except Exception:
            pass
        try:
            self.table.setColumnWidth(COL_OPS, 320)
        except Exception:
            pass
        # 适度给"信息"列一个固定宽度，避免过窄，并设置为固定宽度模式支持换行
        try:
            header.setSectionResizeMode(COL_INFO, QHeaderView.Fixed)
            self.table.setColumnWidth(COL_INFO, 200)
            # 设置表格支持文本换行
            self.table.setWordWrap(True)
        except Exception:
            pass
        # 进程列设置固定宽度
        try:
            header.setSectionResizeMode(COL_PROCESS, QHeaderView.Interactive)
            self.table.setColumnWidth(COL_PROCESS, 100)
        except Exception:
            pass
        layout.addWidget(self.table)
        # 连接信号
        self.add_button.clicked.connect(self._show_add_dialog)
        self.search_edit.textChanged.connect(self._on_search_changed)
        self.script_filter_combo.currentIndexChanged.connect(self._on_filter_changed)
        self.status_filter_combo.currentIndexChanged.connect(self._on_filter_changed)
        self.group_filter_combo.currentIndexChanged.connect(self._on_filter_changed)
    
        self._load_configs_from_disk()
    
    """加载配置"""
    def _load_configs_from_disk(self) -> None:
        datas = FileOper.get_configs()
        for config in datas:
            self._insert_table_row(config)
        logger.info(f"已加载 {len(datas)} 个配置")

    """刷新分组筛选下拉"""
    def _update_groups(self):
        # 分组筛选下拉
        self.group_filter_combo.clear()
        self.group_filter_combo.addItem("全部分组", None)
        try:
            groups: set[str] = FileOper.get_groups()
            for g in sorted(groups):
                self.group_filter_combo.addItem(str(g), str(g))
        except Exception:
            pass
        
    """点击列头排序"""
    def _on_header_clicked(self, index: int) -> None:
        header = self.table.horizontalHeader()
        # 禁止"操作"列（索引8）排序
        if index == COL_OPS:
            if self.table.isSortingEnabled():
                self.table.setSortingEnabled(False)
            try:
                header.setSortIndicatorShown(False)
            except Exception:
                pass
            return
        # 其它列：首次点击开启排序并显示指示器
        if not self.table.isSortingEnabled():
            self.table.setSortingEnabled(True)
            try:
                header.setSortIndicatorShown(True)
            except Exception:
                pass
            # 第一次点击时默认升序
            try:
                self.table.sortItems(index, Qt.AscendingOrder)
                return
            except Exception:
                pass
        # 已开启排序的情况下，切换或重复点击按 Qt 默认行为处理
    
    """搜索框文本变化"""
    def _on_search_changed(self, text: str) -> None:
        self._apply_table_filters()
    
    """筛选下拉变化"""
    def _on_filter_changed(self, _index: int) -> None:
        self._apply_table_filters()
    
    """处理单元格双击事件"""
    def _on_cell_double_clicked(self, row: int, column: int) -> None:
        # 只处理"信息"列的双击事件
        if column == COL_INFO:
            info_item = self.table.item(row, COL_INFO)
            if info_item:
                # 清空信息单元格内容
                info_item.setText("-")
                info_item.setForeground(QColor())  # 恢复默认颜色
                info_item.setTextAlignment(Qt.AlignVCenter | Qt.AlignLeft)  # 恢复正确对齐
                logger.info(f"[调试] 已清空行 {row} 的信息内容")
    
    """应用表格过滤条件"""
    def _apply_table_filters(self) -> None:
        # 名称 + 脚本 + 分组 + 状态 四个条件组合过滤
        name_query = (self.search_edit.text() or "").strip().lower()
        script_id_filter = self.script_filter_combo.currentData()
        status_filter = self.status_filter_combo.currentData()
        group_filter = self.group_filter_combo.currentData() if hasattr(self, 'group_filter_combo') else None
        for row in range(self.table.rowCount()):
            # 名称匹配
            name_item = self.table.item(row, COL_NAME)
            name_text = (name_item.text() if name_item else "").lower()
            match_name = (not name_query) or (name_query in name_text)
            # 脚本匹配（第2列存有 script_id 在 UserRole）
            script_item = self.table.item(row, COL_SCRIPT)
            row_script_id = script_item.data(Qt.UserRole) if script_item else None
            match_script = (script_id_filter is None) or (row_script_id == script_id_filter)
            # 状态匹配（第6列中文显示；需映射回 code）
            status_item = self.table.item(row, COL_STATUS)
            display_status = status_item.text() if status_item else ""
            # 反查 code
            row_status_code = None
            try:
                inv = {v: k for k, v in DRIVER_SESSION_STATUS_LABELS.items()}
                row_status_code = inv.get(display_status, None)
            except Exception:
                row_status_code = None
            match_status = (status_filter is None) or (row_status_code == status_filter)
            # 分组匹配（第3列显示分组文本）
            group_item = self.table.item(row, COL_GROUP)
            row_group = group_item.text() if group_item else None
            match_group = (group_filter is None) or (row_group == group_filter)
            self.table.setRowHidden(row, not (match_name and match_script and match_group and match_status))

    # ---------- 公共交互 ----------
    def stop(self) -> None:
        DriverManager.stop_all()

    # ---------- 业务逻辑 ----------
    """显示添加配置对话框"""
    def _show_add_dialog(self):
        dialog = ConfigDialog(
            parent=self
        )
        dialog.exec()

    """显示编辑配置对话框"""
    def _edit_row_config(self, config_id: str) -> None:
        current_config = FileOper.get_config_by_id(config_id)
        if current_config is None:
            return
        dialog = ConfigDialog(
            parent=self,
            config=current_config,
            allow_browser_selection=False,
            allow_script_selection=False
        )
        dialog.exec()


    """显示删除配置对话框"""
    def _remove_row_config(self, config_id: str) -> None:
        driver_session = DriverManager.get_session(config_id)
        # 先判断该任务是否正在运行，若是则不给予删除
        if driver_session is not None:
            QMessageBox.warning(
                self,
                "无法删除",
                f"任务 “{driver_session.config_data.name}” 当前正在运行，请先停止后再删除。",
                QMessageBox.Ok
            )
            return

        config = FileOper.get_config_by_id(config_id)
        reply = QMessageBox.question(
            self,
            "确认删除",
            f"确定删除任务 “{config.name}” 吗？",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if reply != QMessageBox.Yes:
            return
        # 执行删除
        FileOper.delete_config(config_id)

        # 从表格中移除对应行
        if config is not None:
            for row in range(self.table.rowCount()):
                item = self.table.item(row, COL_NAME)
                if item and item.data(Qt.UserRole) == config_id:
                    self.table.removeRow(row)
                    break
            logger.info(f" 已删除配置 {config.name}")


    """事件：添加配置"""
    def _on_config_added(self, config: ConfigData):
        self._insert_table_row(config)
        logger.info(f" 已添加配置 {config.name}")

    """事件：更新配置"""
    def _on_config_updated(self, config: ConfigData):
        row = self._find_config_row(config.id)
        if row is not None:
            self._update_table_row(row, config)
            logger.info(f" 更新配置成功: {config.id}")
        else:
            logger.error(f" 更新配置失败: {config.id}")

    """查找配置行"""
    def _find_config_row(self, config_id: str) -> Optional[int]:
        for row in range(self.table.rowCount()):
            item = self.table.item(row, COL_NAME)
            if item and item.data(Qt.UserRole) == config_id:
                return row
        return None



    """插入表格行"""
    def _insert_table_row(self, config: ConfigData) -> None:
        # 插入期间临时关闭排序，避免第一列写入触发排序导致后续列错位
        sorting_was_on = self.table.isSortingEnabled()
        if sorting_was_on:
            self.table.setSortingEnabled(False)
        row = self.table.rowCount()
        self.table.insertRow(row)

        name_item = QTableWidgetItem(config.name)
        name_item.setData(Qt.UserRole, config.id)
        name_item.setTextAlignment(Qt.AlignVCenter | Qt.AlignLeft)
        self.table.setItem(row, COL_NAME, name_item)
        # 已移除“浏览器”列
        script_text = get_script_config_by_id(config.script_id).name
        script_item = QTableWidgetItem(script_text)
        script_item.setData(Qt.UserRole, config.script_id)
        script_item.setTextAlignment(Qt.AlignCenter)
        self.table.setItem(row, COL_SCRIPT, script_item)

        # 分组列
        group_text = str(getattr(config, "group", "") or "-")
        group_item = QTableWidgetItem(group_text)
        group_item.setTextAlignment(Qt.AlignCenter)
        self.table.setItem(row, COL_GROUP, group_item)

        proxy_name = "-"
        if config.proxy_id:
            proxy = FileOper.get_proxy_config_by_id(config.proxy_id)
            if proxy:
                proxy_name = proxy.name
        proxy_item = QTableWidgetItem(proxy_name)
        proxy_item.setTextAlignment(Qt.AlignCenter)
        self.table.setItem(row, COL_PROXY, proxy_item)
        
        # 延迟列初始显示为 "-"
        latency_item = QTableWidgetItem("-")
        latency_item.setTextAlignment(Qt.AlignCenter)
        self.table.setItem(row, COL_LATENCY, latency_item)
        status_item = QTableWidgetItem("待启动")
        status_item.setTextAlignment(Qt.AlignCenter)
        status_item.setForeground(DRIVER_SESSION_STATUS_COLORS.get(DriverSessionStatus.IDLE))
        self.table.setItem(row, COL_STATUS, status_item)

        # 进程列：显示进程ID或状态
        process_item = QTableWidgetItem("-")
        process_item.setTextAlignment(Qt.AlignCenter)
        self.table.setItem(row, COL_PROCESS, process_item)

        # 信息列：显示今日 total_score/total_amount，支持换行
        info_item = QTableWidgetItem("-")
        info_item.setTextAlignment(Qt.AlignVCenter | Qt.AlignLeft)  # 垂直居中，水平左对齐，便于多行文本显示
        self.table.setItem(row, COL_INFO, info_item)
        self._update_process_column(row, config.id)



        ops_widget = QWidget()
        ops_layout = QHBoxLayout(ops_widget)
        ops_layout.setContentsMargins(0, 0, 0, 0)
        ops_layout.setSpacing(10)
        ops_layout.setAlignment(Qt.AlignCenter)


        action_button = QPushButton("启动")
        action_button.setFixedSize(64, 26)
        action_button.setCursor(Qt.PointingHandCursor)
        self._style_action_start(action_button)
        action_button.setProperty("running", False)
        action_button.setProperty("role", "action")
        action_button.clicked.connect(lambda _, cfg_id=config.id, btn=action_button: self._toggle_session(config.id, btn))

        # 行内“修改/删除”按钮
        edit_button = QPushButton("修改")
        edit_button.setFixedSize(64, 26)
        edit_button.setCursor(Qt.PointingHandCursor)
        self._style_button(edit_button, "#007bff", "#0069d9")
        edit_button.clicked.connect(lambda _, cfg_id=config.id: self._edit_row_config(cfg_id))

        remove_button = QPushButton("删除")
        remove_button.setFixedSize(64, 26)
        remove_button.setCursor(Qt.PointingHandCursor)
        self._style_button(remove_button, "#6c757d", "#5a6268")
        remove_button.clicked.connect(lambda _, cfg_id=config.id: self._remove_row_config(cfg_id))

        # 顺序：删除、修改、启动
        ops_layout.addWidget(remove_button)
        ops_layout.addWidget(edit_button)
        ops_layout.addWidget(action_button)
        self.table.setCellWidget(row, COL_OPS, ops_widget)


    """更新表格行"""
    def _update_table_row(self, row: int, config: ConfigData) -> None:
        # 更新期间临时关闭排序，避免在写入过程中因排序改变行号
        sorting_was_on = self.table.isSortingEnabled()
        if sorting_was_on:
            self.table.setSortingEnabled(False)
        name_item = self.table.item(row, COL_NAME)
        if name_item:
            name_item.setText(config.name)
            name_item.setData(Qt.UserRole, config.id)
        # 已移除“浏览器”列
        script_text = get_script_config_by_id(config.script_id).name
        script_item = QTableWidgetItem(script_text)
        script_item.setData(Qt.UserRole, config.script_id)
        script_item.setTextAlignment(Qt.AlignCenter)
        self.table.setItem(row, COL_SCRIPT, script_item)

        # 分组
        group_text = str(getattr(config, "group", "") or "-")
        group_item = QTableWidgetItem(group_text)
        group_item.setTextAlignment(Qt.AlignCenter)
        self.table.setItem(row, COL_GROUP, group_item)

        proxy_name = "-"
        if config.proxy_id:
            proxy = FileOper.get_proxy_config_by_id(config.proxy_id)
            if proxy:
                proxy_name = proxy.name
        proxy_item = QTableWidgetItem(proxy_name)
        proxy_item.setTextAlignment(Qt.AlignCenter)
        self.table.setItem(row, COL_PROXY, proxy_item)
        
        # 延迟列保持原值或设为 "-"
        latency_item = self.table.item(row, COL_LATENCY)
        if latency_item is None:
            latency_item = QTableWidgetItem("-")
            latency_item.setTextAlignment(Qt.AlignCenter)
            self.table.setItem(row, COL_LATENCY, latency_item)
        # 保持原有状态文本不变，若不存在则初始化为"待启动"
        status_item = self.table.item(row, COL_STATUS)
        if status_item is None:
            status_item = QTableWidgetItem("待启动")
            status_item.setTextAlignment(Qt.AlignCenter)
            status_item.setForeground(DRIVER_SESSION_STATUS_COLORS.get(DriverSessionStatus.IDLE))
            self.table.setItem(row, COL_STATUS, status_item)

        # 进程列：如不存在则补空
        process_item = self.table.item(row, COL_PROCESS)
        if process_item is None:
            process_item = QTableWidgetItem("-")
            process_item.setTextAlignment(Qt.AlignCenter)
            self.table.setItem(row, COL_PROCESS, process_item)

        # 信息列：如不存在则补空，支持换行
        info_item = self.table.item(row, COL_INFO)
        if info_item is None:
            info_item = QTableWidgetItem("")
            info_item.setTextAlignment(Qt.AlignVCenter | Qt.AlignLeft)  # 垂直居中，水平左对齐，便于多行文本显示
            self.table.setItem(row, COL_INFO, info_item)
        
        self._update_process_column(row, config.id)

        # 同步按钮"启动/停止"状态（仅依赖 PID）
        action_widget = self.table.cellWidget(row, COL_OPS)
        if sorting_was_on:
            self.table.setSortingEnabled(True)


    """更新进程列"""
    def _update_process_column(self, row: int, config_id: str) -> None:
        process_item = self.table.item(row, COL_PROCESS)
        if process_item:
            config = FileOper.get_config_by_id(config_id)
            if config is None:
                return

            if config.script_id == "binance_alpha":
                data = FileOper.get_trade_data_by_id(config_id)
                score = int(data["total_score"])
                total_points_stop = int(config.extra_args.get("total_points_stop", 0))
                process_item.setText(f"{score}/{total_points_stop}")



    # 事件：驱动会话状态变化
    def _on_driver_status_changed(self, config_id: str, prev_status: DriverSessionStatus, new_status: DriverSessionStatus) -> None:
        row = self._find_config_row(config_id)
        if row is None:
            return
        status_item = self.table.item(row, COL_STATUS)
        if status_item:
            status_item.setText(DRIVER_SESSION_STATUS_LABELS.get(new_status))
            status_item.setForeground(DRIVER_SESSION_STATUS_COLORS.get(new_status))
        
        # 不能通过 item 获取“操作”列，因为它是 cellWidget 而不是 QTableWidgetItem
        ops_widget = self.table.cellWidget(row, COL_OPS)
        if ops_widget:
            action_button = self._find_action_button(ops_widget)
            if action_button:
                action_button.setEnabled(True)
                if(new_status == DriverSessionStatus.RUNNING):
                    self._apply_action_button_state(action_button, True)
                elif(new_status in (DriverSessionStatus.IDLE, DriverSessionStatus.STOPPED)):
                    self._apply_action_button_state(action_button, False)
                elif(new_status == DriverSessionStatus.STOPPING):
                    self._apply_action_button_state(action_button, False)
                    action_button.setEnabled(False)

    # 事件：脚本警告
    def _on_script_warning(self, config_id: str, desc: str) -> None:
        row = self._find_config_row(config_id)
        if row is None:
            return
        status_item = self.table.item(row, COL_INFO)
        if status_item:
            status_item.setText(desc)
            status_item.setForeground(QColor("#dc3545"))
            status_item.setTextAlignment(Qt.AlignVCenter | Qt.AlignLeft)  # 确保警告信息也使用正确对齐

    # 事件：积分变化
    def _on_score_changed(self, config_id: str, score: int, total_points_stop: int) -> None:
        row = self._find_config_row(config_id)
        if row is None:
            return
        process_item = self.table.item(row, COL_PROCESS)
        if process_item:
            process_item.setText(f"{score}/{total_points_stop}")

    # 事件：代理延迟测速
    def _on_proxy_latency_tested(self, proxy_id: str, latency: float, status: ProxyStatus, test_status: ProxyTestStatus, response_content: str) -> None:
        """处理代理延迟测速事件"""
        # 将-1.0转换为None，表示失败
        latency_value = None if latency == -1.0 else latency
        
        try:
            # 查找使用该代理的所有配置
            for row in range(self.table.rowCount()):
                config_item = self.table.item(row, COL_NAME)
                if not config_item:
                    continue
                    
                config_id = config_item.data(Qt.UserRole)
                config = FileOper.get_config_by_id(config_id)
                
                # 检查该配置是否使用此代理
                if config and config.proxy_id == proxy_id:
                    # 根据测试状态设置延迟显示
                    if test_status == ProxyTestStatus.TESTING:
                        # 测速中状态
                        latency_text = "测速中.."
                        latency_color = QColor("#fd7e14")  # 橙色
                    elif test_status == ProxyTestStatus.TIMEOUT:
                        # 超时状态
                        latency_text = "超时"
                        latency_color = QColor("#dc3545")  # 红色
                    elif test_status == ProxyTestStatus.FAILED:
                        # 失败状态
                        latency_text = "测速失败"
                        latency_color = QColor("#dc3545")  # 红色
                    elif test_status == ProxyTestStatus.TESTED and latency_value is not None:
                        # 成功状态
                        latency_text = format_latency_text(latency_value)
                        latency_color = qcolor_for_latency(latency_value)
                    else:
                        # 默认失败状态
                        latency_text = "测速失败"
                        latency_color = QColor("#dc3545")  # 红色
                    
                    # 更新延迟显示
                    latency_item = QTableWidgetItem(latency_text)
                    latency_item.setForeground(latency_color)
                    latency_item.setTextAlignment(Qt.AlignCenter)
                    self.table.setItem(row, COL_LATENCY, latency_item)
                    
                    # 记录日志（只在非TESTING状态时记录，避免日志过多）
                    if test_status != ProxyTestStatus.TESTING:
                        proxy_name = "-"
                        if config.proxy_id:
                            proxy = FileOper.get_proxy_config_by_id(config.proxy_id)
                            proxy_name = proxy.name if proxy else config.proxy_id
                        
                        if test_status == ProxyTestStatus.TIMEOUT:
                            logger.warning(f" 节点 {proxy_name} 连接超时")
                        elif test_status == ProxyTestStatus.FAILED:
                            logger.warning(f" 节点 {proxy_name} 测速失败")
                        elif test_status == ProxyTestStatus.TESTED and latency_value is not None:
                            if latency_value >= LATENCY_TIMEOUT_THRESHOLD:
                                logger.warning(f" 节点 {proxy_name} 连接超时")
                            else:
                                logger.info(f" 节点 {proxy_name} 延迟 {latency_value:.0f} ms")
                        else:
                            logger.warning(f" 节点 {proxy_name} 测速失败或连接超时")
                        
        except Exception as e:
            logger.error(f" 处理代理延迟测速事件失败: {e}")
    

    """应用按钮状态"""
    def _apply_action_button_state(self, button: QPushButton, is_running: bool) -> None:
        if is_running:
            button.setText("停止")
            button.setProperty("running", True)
            self._style_action_stop(button)
        else:
            button.setText("启动")
            button.setProperty("running", False)
            self._style_action_start(button)

    """打开分组对话框"""
    def _open_group_dialog(self) -> None:
        # 使用独立模块提供的对话框
        def _update_groups_backcall(groups):
            self._update_groups()
        open_group_dialog(self, callback=_update_groups_backcall)

    """检查许可证状态"""
    def _check_license_status(self) -> Tuple[str, int]:
        """
        检查许可证状态
        
        Returns:
            (状态文本, 剩余天数)
            状态: "未注册", "已注册", "已过期"
            剩余天数: 未注册返回-1, 已过期返回-1, 已注册返回剩余天数
        """
        try:
            # 获取项目根目录
            current_file = Path(__file__).resolve()
            project_root = current_file.parent.parent
            license_file = project_root / "tmp" / "license.json"
            
            if not license_file.exists():
                return "未注册", -1
            
            # 读取许可证文件
            with open(license_file, 'r', encoding='utf-8') as f:
                license_data = json.load(f)
            
            license_key = license_data.get("license_key", "")
            
            if not license_key:
                return "未注册", -1
            
            # 解析许可证（parse_license_key 内部会验证注册码和时间）
            is_valid, expiration, message = parse_license_key(
                license_key, secret_key=DEFAULT_SECRET_KEY
            )
            
            if not is_valid:
                # 根据消息判断是注册码不匹配还是已过期
                if "注册码不匹配" in message:
                    return "未注册", -1
                elif "已过期" in message or expiration is None:
                    return "已过期", -1
                else:
                    # 其他解密失败的情况视为未注册
                    return "未注册", -1
            
            # 许可证有效，计算剩余天数
            if expiration is None:
                return "未注册", -1
            
            now = get_now()
            remaining = expiration - now
            days_left = remaining.days
            
            if days_left < 0:
                return "已过期", -1
            
            return "已注册", days_left
            
        except Exception as e:
            logger.error(f"检查许可证状态失败: {e}")
            return "未注册", -1
    
    """更新注册状态按钮"""
    def _update_license_status_button(self, status: str = None, days_left: int = None) -> None:
        """更新注册状态按钮的文本和颜色"""
        # 如果未提供状态参数，则主动检查
        if status is None or days_left is None:
            status, days_left = self._check_license_status()
        
        if status == "未注册":
            text = "*未注册"
            color = "#6c757d"  # 灰色
            hover_color = "#5a6268"
        elif status == "已过期":
            text = "已过期"
            color = "#dc3545"  # 红色
            hover_color = "#c82333"
        else:  # 已注册
            text = f"已注册({days_left}天过期)"
            if days_left <= 7:
                color = "#fd7e14"  # 橙色（即将过期）
                hover_color = "#e8680e"
            else:
                color = "#28a745"  # 绿色（正常）
                hover_color = "#218838"
        
        try:
            self.license_status_button.setText(text)
            self._style_button(self.license_status_button, color, hover_color)
        except Exception:
            pass
    
    """注册状态按钮点击事件"""
    def _on_license_status_clicked(self) -> None:
        """点击注册状态按钮时打开注册对话框"""
        from register_dialog import RegisterDialog
        dialog = RegisterDialog(parent=self)
        dialog.exec()  # 打开对话框
        # 对话框关闭后更新按钮状态（无论是否注册成功，以防手动修改了许可证文件）
        self._update_license_status_button()

    """许可证状态变化事件"""
    def _on_license_status_changed(self, status: str, days_left: int) -> None:
        """处理许可证状态变化事件"""
        self._update_license_status_button(status, days_left)

    """启动/停止任务"""
    def _toggle_session(self, config_id: str, button: QPushButton) -> None:
        config = FileOper.get_config_by_id(config_id)
        
        if not config:
            return
        if button.property("running") is True:
            DriverManager.stop(config_id=config_id)
        else:
            DriverManager.start(config_id=config_id)

    # ---------- 按钮样式工具 ----------
    def _style_button(self, button: QPushButton, base_color: str, hover_color: str) -> None:
        # Qt 样式支持 :hover；简化为背景变色与禁用态区分
        style = f"""
            QPushButton {{
            background-color: {base_color};
            color: white;
            border-radius: 4px;
            border: 1px solid rgba(0,0,0,0.1);
            }}
            QPushButton:hover:!disabled {{
            background-color: {hover_color};
            }}
            QPushButton:disabled {{
            background-color: #9aa0a6;
            color: #f1f3f4;
            border: 1px solid rgba(0,0,0,0.05);
            }}
        """
        button.setStyleSheet(style)

    """应用启动按钮样式"""
    def _style_action_start(self, button: QPushButton) -> None:
        # 绿色：启动
        self._style_button(button, "#28a745", "#218838")

    """应用停止按钮样式"""
    def _style_action_stop(self, button: QPushButton) -> None:
        # 红色：停止
        self._style_button(button, "#dc3545", "#c82333")


    """查找操作按钮"""
    def _find_action_button(self, widget: QWidget) -> Optional[QPushButton]:
        for btn in widget.findChildren(QPushButton):
            if btn.property("role") == "action":
                return btn
        return None



    