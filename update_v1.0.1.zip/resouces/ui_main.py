

import sys, time
from pathlib import Path

# 确保 resouces 目录在 sys.path 中，以支持相对导入
_current_dir = Path(__file__).resolve().parent
_parent_dir = _current_dir.parent
if str(_current_dir) not in sys.path:
    sys.path.insert(0, str(_current_dir))
if str(_parent_dir) not in sys.path:
    sys.path.insert(0, str(_parent_dir))

from PySide6.QtWidgets import (
    QApplication,
    QLabel,
    QMainWindow,
    QTabWidget,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)
from PySide6.QtWidgets import QApplication
from PySide6.QtGui import QIcon
from proxy_tab import ProxyManagerTab
from task_tab import TaskManagerTab
from binance_alpha_tab import BinanceAlphaSettingsTab
from email_tab import EmailManagerTab
from single_instance import check_single_instance
from driver_manager import DriverManager
from chain_proxy.chain_proxy_manager import init_chain_proxy_manager, get_chain_proxy_manager

from colored_logger import setup_simple_colored_logging
setup_simple_colored_logging()

import logging
logger = logging.getLogger()


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("TaskManagerPro")
        self.resize(1404, 720)

        # 设置窗口图标
        try:
            icon_path = Path(__file__).resolve().parent / "images" / "icon.ico"
            if icon_path.exists():
                self.setWindowIcon(QIcon(str(icon_path)))
        except Exception:
            pass

        # 初始化链式代理管理器
        init_chain_proxy_manager()

        self._setup_ui()
        self.kill_all_browers()

    def _setup_ui(self) -> None:
        central_widget = QWidget(self)
        self.setCentralWidget(central_widget)

        main_layout = QVBoxLayout(central_widget)

        self.tab_widget = QTabWidget()
        main_layout.addWidget(self.tab_widget)

        # 任务管理页迁移至 TaskManagerTab（此时 log 可用）
        self.task_tab = TaskManagerTab()
        self.tab_widget.addTab(self.task_tab, "任务管理1")

        # 代理管理页迁移至 ProxyManagerTab
        self.proxy_tab = ProxyManagerTab()
        self.tab_widget.addTab(self.proxy_tab, "代理管理1")

        # 邮件管理页
        self.email_tab = EmailManagerTab()
        self.tab_widget.addTab(self.email_tab, "邮件管理1")

        # Binance Alpha 设置页（插入于"代理管理"与"日志"之间）
        self.binance_alpha_tab = BinanceAlphaSettingsTab()
        self.tab_widget.addTab(self.binance_alpha_tab, "Binance Alpha 设置")


        # 相关信号均由 ProxyManagerTab 负责绑定

    # 任务与代理的具体逻辑已迁移至各自 Tab

    def closeEvent(self, event):
        DriverManager.stop_all()
        get_chain_proxy_manager().stop_all()
        # 阻止窗口关闭期间的用户操作
        self.setEnabled(False)
        while True:
            QApplication.processEvents()
            if DriverManager.active_count() <= 0 and get_chain_proxy_manager().get_running_instances_count() <= 0:
                break
            time.sleep(0.1)

    def kill_all_browers(self):
        """
        关闭由 Selenium 启动的所有浏览器和驱动进程，包括 chromedriver、geckodriver、msedgedriver 等。
        方法：优先判断父进程 name/命令行是否包含 python/selenium 相关标识。
        注意：该方法无法做到 100% 精确，但能较大程度避开非 selenium 进程。
        """
        try:
            import sys
            import os

            try:
                import psutil
            except ImportError:
                logger.error(" 需要安装 psutil (`pip install psutil`) 才能智能判断是否为 selenium 启动的进程。")
                return

            browser_process_names = [
                "chrome",
                "chromedriver",
                "firefox",
                "geckodriver",
                "msedge",
                "msedgedriver",
            ]

            killed = 0
            total_candidates = 0

            # 检查父进程名/命令行是否有 python/selenium
            def is_selenium_parent(proc):
                try:
                    par = proc.parent()
                    if not par:
                        return False
                    par_name = par.name().lower()
                    par_cmdline = " ".join(par.cmdline()).lower() if par.cmdline() else ""
                    if "python" in par_name or "python" in par_cmdline:
                        return True
                    if "selenium" in par_cmdline:
                        return True
                except Exception:
                    return False
                return False

            for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
                try:
                    name = (proc.info.get('name') or "").lower()

                    # 支持 kill *_driver 进程（如 chromedriver、geckodriver等）以及常见 browser 进程
                    plain_set = set(browser_process_names)
                    exe_set = set(f"{b}.exe" for b in browser_process_names)
                    if name not in plain_set and name not in exe_set:
                        continue

                    total_candidates += 1

                    # chromedriver/geckodriver 等驱动进程，直接 kill（因为通常就是本项目用于 selenium，用错杀但无大影响）
                    # 若未来此逻辑有副作用，可以再精细化区分
                    if any(driver in name for driver in ["chromedriver", "geckodriver", "msedgedriver"]):
                        try:
                            proc.kill()
                            killed += 1
                            logger.info(f" 已结束驱动进程: {name}(pid={proc.pid})")
                        except Exception as e:
                            logger.error(f" 结束驱动进程 {name}(pid={proc.pid}) 失败: {e}")
                        continue

                    # 其它进程（浏览器）仍判断父进程
                    if is_selenium_parent(proc):
                        try:
                            proc.kill()
                            killed += 1
                            logger.info(f" 已结束由 selenium 启动的进程: {name}(pid={proc.pid})")
                        except Exception as e:
                            logger.error(f" 结束进程 {name}(pid={proc.pid}) 失败: {e}")
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
                except Exception as e:
                    logger.error(f" 检查进程时异常: {e}")

            logger.info(f"kill_all_browers: 共检测到 {total_candidates} 个浏览器/驱动进程，已尝试关闭 {killed} 个。")
        except Exception as e:
            logger.error(f"kill_all_browers 时异常: {e}")


def cleanup_on_startup():
    try:
        #清理锁文件
        base_path = Path(__file__).resolve().parent
        tmp_dir = base_path / "tmp"
        trades_dir = tmp_dir / "trades"

        # 收集所有以 .lock 结尾的文件（包括 tmp 和 tmp/trades 目录）
        lock_files = []
        if tmp_dir.exists():
            lock_files.extend(tmp_dir.glob("*.lock"))
        if trades_dir.exists():
            lock_files.extend(trades_dir.glob("*.lock"))

        # 删除这些 .lock 文件
        for lock_file in lock_files:
            try:
                lock_file.unlink()
            except Exception:
                pass
    except Exception:
        pass

def check_for_updates(silent=False):
    """
    检查是否有可用的软件更新，并弹窗提示用户。

    :param silent: 如果为 True，完全静默检查并自动更新（不弹出任何消息框），否则弹窗交互
    如有新版本，弹出消息框，询问是否下载和安装更新。silent=True 时则自动下载并仅打印日志。
    """
    try:
        from hot_update import HotUpdateManager
        from PySide6.QtWidgets import QMessageBox, QApplication
        from PySide6.QtCore import QTimer
        import threading

        def check():
            # 这里的 update_url 应改为实际的线上更新信息地址
            update_url = "https://your-update-server.example.com/update_info.json"
            update_manager = HotUpdateManager(update_url)
            has_update, update_info, error_msg = update_manager.check_update()
            if error_msg:
                # 可打印日志或调试信息，但通常不提示用户
                print(f"检查更新时出错: {error_msg}")
                return

            if has_update and update_info:
                version = update_info.version
                desc = update_info.description or update_info.release_notes or ""
                def handle_update_interactive():
                    msg = f"发现新版本: {version}\n\n{desc}\n\n是否现在更新？"
                    reply = QMessageBox.question(None, "发现新版本", msg,
                                                QMessageBox.Yes | QMessageBox.No)
                    if reply == QMessageBox.Yes:
                        ok = False
                        msg2 = "即将开始自动更新...\n请耐心等待。"
                        try:
                            ok, err2, updated_files = update_manager.perform_update()
                        except Exception as e:
                            err2 = str(e)
                            ok = False
                        if ok:
                            QMessageBox.information(None, "更新成功", "已成功完成更新，请重启应用。")
                        else:
                            QMessageBox.critical(None, "更新失败", f"更新过程中发生错误: {err2}")

                def handle_update_silent():
                    # 静默自动更新
                    print(f"[自动更新] 检查到新版本 {version}，正在静默下载和更新...")
                    try:
                        ok, err2, updated_files = update_manager.perform_update()
                        if ok:
                            print("[自动更新] 已自动完成更新，建议重启应用。")
                        else:
                            print(f"[自动更新] 更新失败，原因: {err2}")
                    except Exception as e:
                        print(f"[自动更新] 自动更新出错: {e}")

                if not silent:
                    # 用 QTimer 进主线程弹窗
                    app = QApplication.instance()
                    if app is not None:
                        QTimer.singleShot(0, handle_update_interactive)
                    else:
                        handle_update_interactive()
                else:
                    handle_update_silent()
            else:
                if not silent:
                    print("当前已是最新版本，无需更新。")

        # 用线程避免主界面卡死
        threading.Thread(target=check, daemon=True).start()

    except Exception as e:
        print(f"检查更新时发生异常: {e}")



def main():
    # 检查单实例运行
    if not check_single_instance("TaskManagerPro"):
        sys.exit(1)
    
    # 创建单实例检查器并获取锁
    from single_instance import SingleInstanceChecker
    instance_checker = SingleInstanceChecker("TaskManagerPro")
    if instance_checker.is_running():
        logger.error(" TaskManagerPro 已在运行中！")
        
        # 在Windows下显示消息框
        try:
            import tkinter as tk
            from tkinter import messagebox
            
            root = tk.Tk()
            root.withdraw()  # 隐藏主窗口
            
            message = "TaskManagerPro 已在运行中！\n\n请关闭现有实例后再启动新实例。"
            
            messagebox.showwarning("程序已在运行", message)
            root.destroy()
        except ImportError:
            pass  # 如果没有tkinter，就只打印信息
        
        sys.exit(1)
    
    check_for_updates()

    # 清理锁文件等垃圾文件
    try:
        cleanup_on_startup()
    except Exception:
        pass

    app = QApplication(sys.argv)
    # 设置应用图标（影响任务栏/默认窗口图标）
    try:
        icon_path = Path(__file__).resolve().parent / "images" / "icon.png"
        if icon_path.exists():
            app.setWindowIcon(QIcon(str(icon_path)))
    except Exception:
        pass
    window = MainWindow()
    window.show()
    try:
        logger.info(f"[启动] UI 已启动，解释器: {sys.executable}")       
    except Exception:
        try:
            logger.info(f"[启动] UI 已启动，解释器: {sys.executable}")
        except Exception:
            pass
    sys.exit(app.exec())


if __name__ == "__main__":
    main()


