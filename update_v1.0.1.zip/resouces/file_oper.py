

import json, os, time, dataclasses, logging
from pathlib import Path
from datetime import datetime
from datetime import timedelta
import traceback
from data_type import ConfigData, ProxyConfig, EmailJsonConfig
from app_globals import get_now

logger = logging.getLogger()

configs_file_path: str = "tmp/configs.json"
proxies_config_file_path = "tmp/proxies.json"
groups_config_file_path = "tmp/groups.json"
read_sys_config_file_path = "tmp/sys_config.json"
email_config_file_path = "tmp/email_config.json"
trade_datas_file_path = "tmp/trades/{config_id}.json"

class FileOper:
    # ========================== 获取配置 ==========================
    @staticmethod
    def get_config_by_id(config_id: str) -> ConfigData | dict | None:
        return next((c for c in FileOper.get_configs() if c.id == config_id), None)

    @staticmethod
    def delete_config(config_id: str) -> bool:
        configs = FileOper.get_configs()
        for idx, c in enumerate(configs):
            if c.id == config_id:
                del configs[idx]
                # 删除配置成功后，清理相关的缓存目录和交易文件
                FileOper.cleanup_config_files(config_id)
                return FileOper.write_configs(configs)
        logger.warning(f" 配置不存在: {config_id}")
        return False

    @staticmethod
    def update_config(config: ConfigData) -> bool:
        configs = FileOper.get_configs()
        for idx, c in enumerate(configs):
            if c.id == config.id:
                configs[idx] = config
                return FileOper.write_configs(configs)
        logger.warning(f" 配置不存在: {config.id}")
        return False

    @staticmethod
    def add_config(config: ConfigData) -> bool:
        configs = FileOper.get_configs()
        configs.append(config)
        return FileOper.write_configs(configs)

    @staticmethod
    def get_configs() -> list[ConfigData]:
        configs = FileOper.read_json_file(configs_file_path)
        if not configs:
            return []
        return [ConfigData(**c) for c in configs]

    @staticmethod
    def write_configs(configs: list[ConfigData]) -> bool:
        return FileOper.write_json_with_lock(configs_file_path, configs)


    # ========================== 邮件配置 ==========================
    @staticmethod
    def get_email_config() -> list[EmailJsonConfig]:
        config = FileOper.read_json_file(email_config_file_path)
        if not config:
            return {}
        return [EmailJsonConfig(**c) for c in config]
    
    @staticmethod
    def write_email_config(config: list[EmailJsonConfig]) -> bool:
        return FileOper.write_json_with_lock(email_config_file_path, config)

    @staticmethod
    def add_email_config(email_cfg: EmailJsonConfig) -> bool:
        configs = FileOper.get_email_config()
        configs.append(email_cfg)
        return FileOper.write_email_config(configs)

    @staticmethod
    def update_email_config(email_cfg: EmailJsonConfig) -> bool:
        configs = FileOper.get_email_config()
        for idx, cfg in enumerate(configs):
            if cfg.email == email_cfg.email:
                configs[idx] = email_cfg
                return FileOper.write_email_config(configs)
        logger.warning(f" 邮箱配置不存在: {email_cfg.email}")
        return False

    @staticmethod
    def delete_email_config(email: str) -> bool:
        configs = FileOper.get_email_config()
        for idx, cfg in enumerate(configs):
            if cfg.email == email:
                del configs[idx]
                return FileOper.write_email_config(configs)
        logger.warning(f" 邮箱配置不存在: {email}")
        return False

    # INSERT_YOUR_CODE

    @staticmethod
    def get_enabled_accounts() -> list[EmailJsonConfig]:
        """获取启用的邮箱账户列表"""
        configs = FileOper.get_email_config()
        # configs如果不是list，直接返回空list
        if not isinstance(configs, list):
            return []
        return [cfg for cfg in configs if getattr(cfg, "enabled", True)]

    @staticmethod
    def update_account_stats(email: str, success: bool = True) -> bool:
        """
        更新账户统计信息
        成功则自增send_count，失败则自增error_count，并更新last_used
        注意：last_used存为ISO格式字符串，避免datetime对象直接写入JSON
        """
        configs = FileOper.get_email_config()
        updated = False
        for cfg in configs:
            if cfg.email == email:
                if success:
                    cfg.send_count = getattr(cfg, "send_count", 0) + 1
                else:
                    cfg.error_count = getattr(cfg, "error_count", 0) + 1
                cfg.last_used = get_now().isoformat()  # 用字符串保存（UTC+8时区）
                updated = True
                break
        if updated:
            return FileOper.write_email_config(configs)
        else:
            logger.warning(f" 邮箱配置不存在: {email}")
            return False


    # INSERT_YOUR_CODE

    # ========================== 代理配置 ==========================
    @staticmethod
    def get_proxy_config_by_id(proxy_id: str) -> ProxyConfig | None:
        proxies = FileOper.get_proxys()
        for p in proxies:
            if p.id == proxy_id:
                return p
        logger.warning(f" 代理不存在: {proxy_id}")
        return None

    
    @staticmethod
    def add_proxy_config(proxy: ProxyConfig) -> bool:
        proxies = FileOper.get_proxys()
        proxies.append(proxy)
        return FileOper.write_proxies(proxies)

    @staticmethod
    def delete_proxy_config(proxy_id: str) -> bool:
        proxies = FileOper.get_proxys()
        for idx, p in enumerate(proxies):
            if p.id == proxy_id:
                del proxies[idx]
                return FileOper.write_proxies(proxies)
        logger.warning(f" 代理不存在: {proxy_id}")
        return False

    @staticmethod
    def update_proxy_config(proxy: ProxyConfig) -> bool:
        proxies = FileOper.get_proxys()
        for idx, p in enumerate(proxies):
            if p.id == proxy.id:
                proxies[idx] = proxy
                return FileOper.write_proxies(proxies)
        logger.warning(f" 代理不存在: {proxy.id}")
        return False

    @staticmethod
    def get_proxys() -> list[ProxyConfig]:
        proxies = FileOper.read_json_file(proxies_config_file_path)
        if not proxies:
            return []
        return [ProxyConfig(**p) for p in proxies]

    @staticmethod
    def write_proxies(proxies: list[ProxyConfig]) -> bool:
        return FileOper.write_json_with_lock(proxies_config_file_path, proxies)



    # ========================== 获取交易数据 ==========================
    @staticmethod
    def get_trade_data_by_id(config_id):
        datas = FileOper.read_trade_datas(config_id)
        if datas is None:
            return {"total_score": 0, "total_amount": 0}

        now = get_now()  # 使用 UTC+8 时区
        if now.hour < 14:
            target_date = now - timedelta(days=1)
        else:
            target_date = now
        today = target_date.strftime("%Y-%m-%d")
        data = datas.get(today, {"total_score": 0, "total_amount": 0, "last_order_id": 0}) 
        return data

    @staticmethod
    def update_trade_data_by_id(config_id: str, total_score: int = 0, total_amount: float = 0, last_order_id: int = 0) -> bool:
        datas = FileOper.read_trade_datas(config_id)
        if datas is None:
            return False

        now = get_now()  # 使用 UTC+8 时区
        if now.hour < 14:
            target_date = now - timedelta(days=1)
        else:
            target_date = now
        today = target_date.strftime("%Y-%m-%d")
        data = datas.get(today, {"total_score": 0, "total_amount": 0, "last_order_id": 0}) 
        data["total_score"] = total_score
        data["total_amount"] = total_amount
        data["last_order_id"] = last_order_id
        datas[today] = data
        return FileOper.write_trade_datas(config_id, datas)

    @staticmethod
    def read_trade_datas(config_id: str) -> dict | None:
        data = FileOper.read_json_file(trade_datas_file_path.format(config_id=config_id))
        if data is None:
            return {}
        return data
    
    @staticmethod
    def write_trade_datas(config_id: str, datas: dict) -> bool:
        return FileOper.write_json_with_lock(trade_datas_file_path.format(config_id=config_id), datas) or False



    # ========================== 获取分组配置 ==========================
    @staticmethod
    def get_groups() -> list[str]:
        groups = FileOper.read_json_file(groups_config_file_path)
        if not groups:
            return []
        return groups
    
    @staticmethod
    def write_groups(groups: list[str]) -> bool:
        return FileOper.write_json_with_lock(groups_config_file_path, groups)


    
    @staticmethod
    def get_sys_config() -> dict:
        config = FileOper.read_json_file(read_sys_config_file_path)
        if not config:
            return {}
        return config
    
    @staticmethod
    def write_sys_config(config: dict) -> bool:
        sys_config = FileOper.get_sys_config()
        sys_config.update(config)
        return FileOper.write_json_with_lock(read_sys_config_file_path, sys_config)





    """读取 JSON 文件，失败返回 None。"""
    @staticmethod
    def read_json_file(path: str | Path):
        """
        路径不存在时会自动创建对应目录，文件不存在时也会自动创建一个空的JSON文件。
        返回值：
          - 若文件存在且可正确读取，返回解析后的内容
          - 若文件不存在，则自动创建空JSON后返回{}
          - 出错时返回{}
        """
        try:
            p = Path(path)
            if not p.exists():
                # 不存在则递归创建父目录并写入空JSON文件
                try:
                    p.parent.mkdir(parents=True, exist_ok=True)
                    with p.open("w", encoding="utf-8") as f:
                        f.write("")
                except Exception as e:
                    logger.warning(f" 创建目录或文件失败: {e}")
                return None
            with p.open("r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            logger.warning(f" 读取 {path} 文件失败: {e}")
            return None

    """带锁原子写入 JSON，支持多进程/多线程并发。成功返回 True，失败返回 False。"""
    @staticmethod
    def write_json_with_lock(target_path: str | Path, data, timeout_seconds: float = 5.0, stale_seconds: float = 30.0) -> bool:
        target = Path(target_path)
        try:
            target.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass

        lock_path = target.with_suffix(target.suffix + ".lock")
        start_time = time.time()

        # 获取锁：通过原子创建 .lock 文件实现互斥；支持清理过期锁
        acquired = False
        while time.time() - start_time <= timeout_seconds:
            try:
                fd = os.open(str(lock_path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                with os.fdopen(fd, "w", encoding="utf-8") as lf:
                    lf.write(f"pid={os.getpid()} time={int(time.time())}\n")
                acquired = True
                break
            except FileExistsError:
                try:
                    # 过期锁清理
                    if lock_path.exists() and (time.time() - lock_path.stat().st_mtime) > stale_seconds:
                        os.unlink(str(lock_path))
                except Exception:
                    pass
                time.sleep(0.1)
            except Exception:
                time.sleep(0.1)

        if not acquired:
            return False

        temp_path = target.parent / ("." + target.name + f".{os.getpid()}.{int(time.time())}.tmp")
        try:
            # 写入临时文件
            def default_serializer(obj):
                try:
                    # 优先用 dataclasses.asdict 处理 ConfigData 及其它 dataclasses 对象
                    if dataclasses.is_dataclass(obj):
                        return dataclasses.asdict(obj)
                except Exception:
                    pass
                # 不行就报错
                raise TypeError(f"Object of type {type(obj).__name__} is not JSON serializable")
            with open(temp_path, "w", encoding="utf-8") as f:
                try:
                    json.dump(data, f, ensure_ascii=False, indent=2, default=default_serializer)
                except TypeError as e:
                    logger.error(f" 写入 JSON 数据失败，可能包含无法序列化的对象:{target_path} 错误: {e} traceback: {traceback.format_exc()}")
                    raise
                f.flush()
                os.fsync(f.fileno()) if hasattr(os, "fsync") else None

            # 原子替换到目标文件
            os.replace(str(temp_path), str(target))
            return True
        except Exception:
            try:
                if temp_path.exists():
                    temp_path.unlink()
            except Exception:
                pass
            return False
        finally:
            try:
                if lock_path.exists():
                    os.unlink(str(lock_path))
            except Exception:
                pass

    """删除指定 JSON 文件对应的 .lock 锁文件。
    默认仅在锁文件“过期”时删除（基于 mtime 与 stale_seconds），若 force=True 则无条件删除。
    返回 True 表示最终不存在锁（删除成功或本就不存在），False 表示仍然存在或出错。"""
    @staticmethod
    def clear_json_lock(target_path: str | Path, *, force: bool = False, stale_seconds: float = 30.0) -> bool:
        try:
            target = Path(target_path)
            lock_path = target.with_suffix(target.suffix + ".lock")
            if not lock_path.exists():
                return True
            if force:
                os.unlink(str(lock_path))
                return True
            # 非强制：仅删除过期锁，避免误删其他进程正在使用的锁
            try:
                if (time.time() - lock_path.stat().st_mtime) > stale_seconds:
                    os.unlink(str(lock_path))
                    return True
                return False
            except Exception:
                return False
        except Exception:
            return False


    """批量清理多个 JSON 文件的锁文件。返回成功清理数量。"""
    @staticmethod
    def cleanup_stale_json_locks(paths: list[str | Path], stale_seconds: float = 30.0) -> int:
        cleaned = 0
        for p in paths:
            if FileOper.clear_json_lock(p, force=False, stale_seconds=stale_seconds):
                cleaned += 1
        return cleaned

    """清理指定配置ID相关的缓存目录和交易文件"""
    @staticmethod
    def cleanup_config_files(config_id: str) -> bool:
        """
        删除指定配置ID相关的所有文件：
        1. 缓存目录：tmp/cache/{browser_name}/{config_id}/
        2. 交易文件：tmp/trades/{config_id}.json
        """
        try:
            base_path = Path.cwd() / "tmp"
            cleaned_count = 0
            
            # 删除缓存目录
            cache_root = base_path / "cache"
            if cache_root.exists():
                # 遍历所有浏览器类型的目录
                for browser_dir in cache_root.iterdir():
                    if browser_dir.is_dir():
                        config_cache_dir = browser_dir / config_id
                        if config_cache_dir.exists():
                            try:
                                import shutil
                                shutil.rmtree(str(config_cache_dir))
                                cleaned_count += 1
                                logger.info(f" 已删除缓存目录: {config_cache_dir}")
                            except Exception as e:
                                logger.warning(f" 删除缓存目录失败: {config_cache_dir}, 错误: {e}")
            
            # 删除交易文件
            trades_dir = base_path / "trades"
            if trades_dir.exists():
                trade_file = trades_dir / f"{config_id}.json"
                if trade_file.exists():
                    try:
                        trade_file.unlink()
                        cleaned_count += 1
                        logger.info(f" 已删除交易文件: {trade_file}")
                    except Exception as e:
                        logger.warning(f" 删除交易文件失败: {trade_file}, 错误: {e}")
            
            # 删除交易文件的锁文件
            if trades_dir.exists():
                trade_lock_file = trades_dir / f"{config_id}.json.lock"
                if trade_lock_file.exists():
                    try:
                        trade_lock_file.unlink()
                        logger.info(f" 已删除交易锁文件: {trade_lock_file}")
                    except Exception as e:
                        logger.warning(f" 删除交易锁文件失败: {trade_lock_file}, 错误: {e}")
            
            if cleaned_count > 0:
                logger.info(f" 已清理配置 {config_id} 的相关文件")
            return True
            
        except Exception as e:
            logger.error(f" 清理配置文件时发生异常: {e}")
            return False