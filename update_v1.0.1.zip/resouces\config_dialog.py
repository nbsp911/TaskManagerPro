

from typing import Optional
from data_type import ProxyConfig
from PySide6.QtWidgets import (
    QDialog,
    QComboBox,
    QDialogButtonBox,
    QFormLayout,
    QLineEdit,
    QVBoxLayout,
    QWidget,
    QLabel,
    QPushButton,
    QMessageBox,
    QCompleter,
)
from PySide6.QtCore import Signal, Qt
from tools import *
import re, uuid
from data_type import ConfigData
from file_oper import FileOper
from slot_events import ConfigDataSignal
from qr_code_dialog import QrCodeDialog
from datas import get_countries, get_random_user_anget
from scripts.scripts_config import get_scripts_config, get_script_config_by_id

import logging
logger = logging.getLogger()

class ConfigDialog(QDialog):
    # 动态按钮点击事件：参数为字段 key
    dynamic_button_clicked = Signal(str)
    def __init__(
        self,
        *,
        parent: QWidget | None = None,
        config: ConfigData | None = None,
        allow_browser_selection: bool = True,
        allow_script_selection: bool = True
    ):
        super().__init__(parent)
        self.config = config
        available_groups = FileOper.get_groups()
        scripts = get_scripts_config()

        self.setWindowTitle("配置详情")
        self.setModal(True)
        self.resize(800, 450)

        self.name_edit = QLineEdit()
        self.browser_combo = QComboBox()
        self.browser_combo.addItems(detect_browsers())
        self.headless_check = QPushButton("无头模式")
        self.headless_check.setCheckable(True)
        self.script_combo = QComboBox()
        self._script_lookup: dict[str, dict[str, str]] = {}
        self._locked_script_id: Optional[str] = None
        self._locked_browser: Optional[str] = None
        self._allow_browser_selection = allow_browser_selection
        self._allow_script_selection = allow_script_selection
        self.proxy_combo = QComboBox()
        self.proxy_combo.addItem("(不使用代理)", None)
        self._proxy_lookup: dict[str, ProxyConfig] = {}
        
        # 国家选择下拉框
        self.country_combo = QComboBox()
        self.country_combo.setEditable(True)
        self.country_combo.setInsertPolicy(QComboBox.NoInsert)
        countries = get_countries()
        country_names = [country["show_name"] for country in countries]
        self.country_combo.addItems(country_names)
        
        # 添加搜索功能
        completer = QCompleter(country_names)
        completer.setCaseSensitivity(Qt.CaseInsensitive)
        completer.setFilterMode(Qt.MatchContains)
        self.country_combo.setCompleter(completer)

        proxies = FileOper.get_proxys()
        for proxy in proxies:
            self.proxy_combo.addItem(proxy.name, proxy.id)
            self._proxy_lookup[proxy.id] = proxy

        # 分组下拉
        self.group_combo = QComboBox()
        self.group_combo.addItem("(无分组)", None)
        if available_groups:
            for g in sorted(available_groups):
                self.group_combo.addItem(str(g), str(g))

        for script in scripts:
            self.script_combo.addItem(script.name, script.id)
            self._script_lookup[script.id] = script

        form_layout = QFormLayout()
        form_layout.addRow("名称", self.name_edit)
        form_layout.addRow("浏览器", self.browser_combo)
        form_layout.addRow("脚本", self.script_combo)
        form_layout.addRow("代理", self.proxy_combo)
        form_layout.addRow("分组", self.group_combo)
        form_layout.addRow("国家", self.country_combo)
        form_layout.addRow("选项", self.headless_check)

        # 动态字段区域（随脚本切换）
        # 仅存储可输入控件（非按钮），用于后续读取与保存
        self._dynamic_defaults: dict[str, object] = {}
        self._dynamic_fields: dict[str, QLineEdit] = {}
        # 保存字段 schema，便于后续校验/默认值应用
        self._dynamic_schema: dict[str, dict] = {}
        self._dynamic_form = QFormLayout()
        self._dynamic_form.setContentsMargins(0, 0, 0, 0)
        try:
            self._dynamic_form.setHorizontalSpacing(12)
            self._dynamic_form.setVerticalSpacing(8)
        except Exception:
            pass
        self._dynamic_host = QWidget()
        try:
            self._dynamic_host.setContentsMargins(0, 0, 0, 0)
        except Exception:
            pass
        self._dynamic_host.setLayout(self._dynamic_form)

        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)

        layout = QVBoxLayout(self)
        layout.addLayout(form_layout)
        # 扩展属性标题（样式化）
        self._dynamic_title = QLabel("扩展属性")
        self._dynamic_title.setStyleSheet(
            "margin-top: 8px; margin-bottom: 6px; font-weight: 600; color: #E8EAED; font-size: 14px;"
        )
        layout.addWidget(self._dynamic_title)
        # 直接将动态字段放在标题下方
        layout.addWidget(self._dynamic_host)
        layout.addWidget(button_box)

        if config is not None:
            self.name_edit.setText(config.name)
            if config.browser:
                self.browser_combo.setCurrentText(config.browser)
                if not allow_browser_selection:
                    self._locked_browser = config.browser
            if config.script_id and config.script_id in self._script_lookup:
                index = self.script_combo.findData(config.script_id)
                if index >= 0:
                    self.script_combo.setCurrentIndex(index)
                    if not allow_script_selection:
                        self._locked_script_id = config.script_id
            if config.proxy_id:
                idx = self.proxy_combo.findData(config.proxy_id)
                if idx >= 0:
                    self.proxy_combo.setCurrentIndex(idx)
            self.headless_check.setChecked(config.headless)
            # 预设分组
            if getattr(config, "group", None):
                gi = self.group_combo.findData(config.group)
                if gi >= 0:
                    self.group_combo.setCurrentIndex(gi)
            # 预设国家（不可修改）
            if getattr(config, "country_index", None) is not None:
                country_idx = config.country_index
                if 0 <= country_idx < len(country_names):
                    self.country_combo.setCurrentIndex(country_idx)
                self.country_combo.setEnabled(False)

        # 初始化/刷新动态字段（编辑态优先用已有 extra_args 值）
        init_script_id = self._locked_script_id or self.script_combo.currentData()
        init_values = getattr(config, "extra_args", None) if config is not None else None
        self._rebuild_dynamic_fields(init_script_id, init_values)

        # 脚本切换时重建动态字段
        self.script_combo.currentIndexChanged.connect(self._on_script_changed)

        if not allow_browser_selection:
            self.browser_combo.setEnabled(False)
        if not allow_script_selection:
            self.script_combo.setEnabled(False)

    def get_data(self) -> dict[str, object]:
        # 采集动态字段值，保持与默认类型尽量一致（数字尝试转换）
        extra_args: dict[str, object] = {}
        for key, widget in self._dynamic_fields.items():
            raw = widget.text()
            default_value = self._dynamic_defaults.get(key)
            value: object = raw
            try:
                if isinstance(default_value, bool):
                    value = str(raw).strip().lower() in ("1", "true", "yes", "on")
                elif isinstance(default_value, int) and raw.strip() != "":
                    value = int(float(raw))
                elif isinstance(default_value, float) and raw.strip() != "":
                    value = float(raw)
                else:
                    value = raw
            except Exception:
                value = raw
            extra_args[key] = value

        # 排除 type=button 字段：_dynamic_fields 本身已不包含按钮，但为稳妥按 schema 过滤一次
        try:
            keys_to_remove = []
            for key, schema in self._dynamic_schema.items():
                if (schema.get("type") or "").strip().lower() == "button":
                    keys_to_remove.append(key)
            for k in keys_to_remove:
                if k in extra_args:
                    extra_args.pop(k, None)
        except Exception:
            pass

        return {
            "name": self.name_edit.text().strip() or "未命名配置",
            "browser": self._locked_browser or self.browser_combo.currentText(),
            "proxy_id": self.proxy_combo.currentData(),
            "headless": self.headless_check.isChecked(),
            "script_id": self._locked_script_id or self.script_combo.currentData(),
            "extra_args": extra_args,
            "group": self.group_combo.currentData(),
            "country_index": self.country_combo.currentIndex(),
        }

    # ---------- 动态字段逻辑 ----------
    def _on_script_changed(self, _index: int) -> None:
        if not self._allow_script_selection and self._locked_script_id:
            return
        script_id = self.script_combo.currentData()
        self._rebuild_dynamic_fields(script_id, None)

    def _rebuild_dynamic_fields(self, script_id: Optional[str], preset_values: Optional[dict] = None) -> None:
        # 清空原有控件
        try:
            while self._dynamic_form.count():
                item = self._dynamic_form.takeAt(0)
                w = item.widget()
                if w is not None:
                    w.deleteLater()
        except Exception:
            pass
        self._dynamic_defaults.clear()
        self._dynamic_fields.clear()
        self._dynamic_schema.clear()

        if not script_id:
            return
        script = self._script_lookup.get(script_id) or {}
        dynamic_def = script.dynamic_property or {}
        if not isinstance(dynamic_def, dict):
            return

        # 渲染：根据 type 渲染文本框或按钮；标题优先使用 show_name
        for key, schema in dynamic_def.items():
            if not isinstance(schema, dict):
                continue
            self._dynamic_schema[key] = schema
            field_type = (schema.get("type") or "text").strip().lower()
            show_title = schema.get("show_name") or key
            desc_text = schema.get("desc") or None

            # 预设值（仅输入型适用）与默认值 def_val
            preset_val = None
            if preset_values and isinstance(preset_values, dict):
                preset_val = preset_values.get(key)
            default_val = schema.get("def_val", None)
            # 记录到 defaults 用于类型转换
            self._dynamic_defaults[key] = default_val

            if field_type == "button":
                # 按钮类型：渲染按钮，不纳入 _dynamic_fields（保存时自动排除）
                btn = QPushButton(str(show_title))
                btn.setMaximumWidth(int(self.width() * 0.33))
                try:
                    btn.setCursor(Qt.PointingHandCursor)
                except Exception:
                    pass
                # 提高按钮高度
                try:
                    btn.setFixedHeight(30)
                except Exception:
                    pass
                # 按钮绿色样式
                try:
                    btn.setStyleSheet(
                        """
                        QPushButton {
                            background-color: #28a745;
                            color: white;
                            border-radius: 4px;
                            border: 1px solid rgba(0,0,0,0.1);
                        }
                        QPushButton:hover:!disabled {
                            background-color: #218838;
                        }
                        QPushButton:disabled {
                            background-color: #9aa0a6;
                            color: #f1f3f4;
                            border: 1px solid rgba(0,0,0,0.05);
                        }
                        """
                    )
                except Exception:
                    pass
                btn.clicked.connect(lambda _=False, k=key: self._on_dynamic_button_clicked(k))

                # 容器：按钮（以及可能的描述标签，后续待办中完善）
                container = QWidget()
                vbox = QVBoxLayout(container)
                try:
                    vbox.setContentsMargins(0, 0, 0, 0)
                    vbox.setSpacing(4)
                except Exception:
                    pass
                vbox.addWidget(btn)
                # 描述文本
                if isinstance(desc_text, str) and desc_text.strip():
                    desc_label = QLabel(str(desc_text))
                    try:
                        desc_label.setWordWrap(True)
                    except Exception:
                        pass
                    desc_label.setStyleSheet("color: #dc3545; font-size: 12px;")
                    vbox.addWidget(desc_label)
                self._dynamic_form.addRow("", container)
            else:
                # 文本输入
                edit = QLineEdit()
                # 初始值：优先预设值，其次 def_val
                if preset_val is not None:
                    try:
                        edit.setText(str(preset_val))
                    except Exception:
                        pass
                elif default_val is not None:
                    try:
                        edit.setText(str(default_val))
                    except Exception:
                        pass
                self._dynamic_fields[key] = edit
                # 使用 show_name 作为标题，同时在下方添加描述
                if isinstance(desc_text, str) and desc_text.strip():
                    container = QWidget()
                    vbox = QVBoxLayout(container)
                    try:
                        vbox.setContentsMargins(0, 0, 0, 0)
                        vbox.setSpacing(4)
                    except Exception:
                        pass
                    vbox.addWidget(edit)
                    desc_label = QLabel(str(desc_text))
                    try:
                        desc_label.setWordWrap(True)
                    except Exception:
                        pass
                    desc_label.setStyleSheet("color: #dc3545; font-size: 12px;")
                    vbox.addWidget(desc_label)
                    self._dynamic_form.addRow(str(show_title), container)
                else:
                    self._dynamic_form.addRow(str(show_title), edit)

    # 表单提交前校验：基于 regex
    def accept(self) -> None:
        # 名称必填校验
        try:
            if not (self.name_edit.text() or "").strip():
                QMessageBox.warning(self, "无效输入", "名称不能为空")
                return
        except Exception:
            pass
        try:
            for key, widget in self._dynamic_fields.items():
                schema = self._dynamic_schema.get(key) or {}
                pattern = schema.get("regex")
                if not pattern:
                    continue
                text = widget.text() or ""
                try:
                    if not re.fullmatch(pattern, text):
                        title = schema.get("show_name") or key
                        QMessageBox.warning(self, "无效输入", f"字段“{title}”的值不符合要求。")
                        return
                except re.error:
                    # 正则本身错误时，放行但提示
                    logger.warning(f" 正则无效：{pattern}，字段 {key}")
        except Exception:
            pass

        if self.config is None:
            self.add_config(self.get_data())
        else:
            self.update_config(self.get_data())

        return super().accept()

    # 外部可设置/读取动态字段值
    def set_dynamic_value(self, key: str, value: object) -> None:
        w = self._dynamic_fields.get(key)
        if w is not None:
            try:
                w.setText("" if value is None else str(value))
            except Exception:
                pass

    def get_dynamic_value(self, key: str) -> Optional[str]:
        w = self._dynamic_fields.get(key)
        if w is None:
            return None
        try:
            return w.text()
        except Exception:
            return None

    def get_dynamic_schema(self) -> dict:
        return dict(self._dynamic_schema)


    """添加配置"""
    def add_config(self, data: dict[str, object]):
        config_id = str(uuid.uuid4())
        proxy_id = data.get("proxy_id") or None

        config = ConfigData(
            id=config_id,
            name=str(data["name"]),
            script_id=str(data["script_id"]) or None,
            script_path=get_script_config_by_id(data.get("script_id")).path,
            browser=str(data["browser"]),
            headless=bool(data["headless"]),
            proxy_id=proxy_id,
        )
        # 动态字段保存到 extra_args
        if isinstance(data.get("extra_args"), dict):
            config.extra_args = data["extra_args"]  # type: ignore[assignment]
        # 分组
        cfg_group = data.get("group")
        config.group = cfg_group if cfg_group else None
        # 国家索引
        config.country_index = data.get("country_index")
        # 随机User-Agent（仅在添加时生成）
        config.user_agent = get_random_user_anget()

        FileOper.add_config(config)
        ConfigDataSignal.config_added.emit(config)

    """更新配置"""
    def update_config(self, data: dict[str, object]):
        config = FileOper.get_config_by_id(self.config.id)
        if not config:
            return
        config.name = str(data["name"])
        config.script_id = str(data["script_id"]) or None
        config.script_path = get_script_config_by_id(data.get("script_id")).path
        config.browser = str(data["browser"])
        config.headless = bool(data["headless"])
        config.proxy_id = data.get("proxy_id") or None
        config.extra_args = data.get("extra_args") or {}
        config.group = data.get("group") or None
        FileOper.update_config(config)
        ConfigDataSignal.config_updated.emit(config)


    """动态按钮点击事件"""
    def _on_dynamic_button_clicked(self, key: str) -> None:
        # 根据常见键名处理：qr_code_btn / find_name_btn
        try:
            if key == "qr_code_btn":
                q = QrCodeDialog(self)
                if q.exec() == QDialog.Accepted:
                    secret = q.get_secret() or ""
                    if secret:
                        self.set_dynamic_value("authenticator", secret)
                return

        except Exception:
            pass