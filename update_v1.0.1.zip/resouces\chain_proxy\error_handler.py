"""
ErrorHandler - 错误处理和异常管理机制
"""

import logging
import traceback
import threading
import time
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, field
from enum import Enum
import json
import os
from pathlib import Path

logger = logging.getLogger()


class ErrorLevel(Enum):
    """错误级别"""
    DEBUG = "debug"
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


class ErrorCategory(Enum):
    """错误分类"""
    NETWORK = "network"
    CONFIG = "config"
    THREAD = "thread"
    PROXY = "proxy"
    PORT = "port"
    SYSTEM = "system"
    UNKNOWN = "unknown"


@dataclass
class ErrorRecord:
    """错误记录"""
    id: str
    timestamp: float
    level: ErrorLevel
    category: ErrorCategory
    message: str
    exception: Optional[str] = None
    traceback: Optional[str] = None
    context: Dict[str, Any] = field(default_factory=dict)
    resolved: bool = False
    resolved_time: Optional[float] = None
    
    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "timestamp": self.timestamp,
            "level": self.level.value,
            "category": self.category.value,
            "message": self.message,
            "exception": self.exception,
            "traceback": self.traceback,
            "context": self.context,
            "resolved": self.resolved,
            "resolved_time": self.resolved_time
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> "ErrorRecord":
        return cls(
            id=data["id"],
            timestamp=data["timestamp"],
            level=ErrorLevel(data["level"]),
            category=ErrorCategory(data["category"]),
            message=data["message"],
            exception=data.get("exception"),
            traceback=data.get("traceback"),
            context=data.get("context", {}),
            resolved=data.get("resolved", False),
            resolved_time=data.get("resolved_time")
        )


class ErrorHandler:
    """错误处理器"""
    
    def __init__(self, max_records: int = 1000, persistence_file: str = "tmp/error_log.json"):
        self.max_records = max_records
        self.persistence_file = persistence_file
        self.error_records: List[ErrorRecord] = []
        self._lock = threading.RLock()
        self._error_counters: Dict[str, int] = {}  # category -> count
        self._recent_errors: Dict[str, float] = {}  # error_key -> timestamp
        
        # 错误处理回调
        self.error_callbacks: Dict[ErrorLevel, List[Callable]] = {
            level: [] for level in ErrorLevel
        }
        
        # 加载持久化数据
        self._load_errors()
    
    def _load_errors(self):
        """加载错误记录"""
        try:
            if os.path.exists(self.persistence_file):
                with open(self.persistence_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                
                for error_data in data:
                    error = ErrorRecord.from_dict(error_data)
                    self.error_records.append(error)
                    
                    # 更新计数器
                    category_key = error.category.value
                    self._error_counters[category_key] = self._error_counters.get(category_key, 0) + 1
                
                logger.info(f"已加载 {len(self.error_records)} 条错误记录")
        except Exception as e:
            logger.error(f"加载错误记录失败: {e}")
    
    def _save_errors(self):
        """保存错误记录"""
        try:
            # 确保目录存在
            os.makedirs(os.path.dirname(self.persistence_file), exist_ok=True)
            
            with self._lock:
                data = [error.to_dict() for error in self.error_records]
            
            with open(self.persistence_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
                
        except Exception as e:
            logger.error(f"保存错误记录失败: {e}")
    
    def _generate_error_id(self) -> str:
        """生成错误ID"""
        import uuid
        return str(uuid.uuid4())[:8]
    
    def _get_error_key(self, message: str, category: ErrorCategory) -> str:
        """获取错误键（用于去重）"""
        return f"{category.value}:{hash(message)}"
    
    def log_error(self, 
                  message: str,
                  level: ErrorLevel = ErrorLevel.ERROR,
                  category: ErrorCategory = ErrorCategory.UNKNOWN,
                  exception: Optional[Exception] = None,
                  context: Optional[Dict[str, Any]] = None,
                  deduplicate: bool = True) -> str:
        """记录错误"""
        error_id = self._generate_error_id()
        timestamp = time.time()
        
        # 检查是否去重
        if deduplicate:
            error_key = self._get_error_key(message, category)
            if error_key in self._recent_errors:
                # 如果最近5分钟内记录过相同错误，跳过
                if timestamp - self._recent_errors[error_key] < 300:
                    return error_id
        
        # 创建错误记录
        error_record = ErrorRecord(
            id=error_id,
            timestamp=timestamp,
            level=level,
            category=category,
            message=message,
            exception=str(exception) if exception else None,
            traceback=traceback.format_exc() if exception else None,
            context=context or {}
        )
        
        with self._lock:
            # 添加到记录列表
            self.error_records.append(error_record)
            
            # 更新计数器
            category_key = category.value
            self._error_counters[category_key] = self._error_counters.get(category_key, 0) + 1
            
            # 更新最近错误
            if deduplicate:
                self._recent_errors[error_key] = timestamp
            
            # 限制记录数量
            if len(self.error_records) > self.max_records:
                self.error_records = self.error_records[-self.max_records:]
        
        # 保存到文件
        self._save_errors()
        
        # 调用错误回调
        self._trigger_callbacks(error_record)
        
        # 记录到日志
        log_message = f"[{category.value}] {message}"
        if exception:
            log_message += f" - {exception}"
        
        if level == ErrorLevel.CRITICAL:
            logger.critical(log_message)
        elif level == ErrorLevel.ERROR:
            logger.error(log_message)
        elif level == ErrorLevel.WARNING:
            logger.warning(log_message)
        elif level == ErrorLevel.INFO:
            logger.info(log_message)
        else:
            logger.debug(log_message)
        
        return error_id
    
    def _trigger_callbacks(self, error_record: ErrorRecord):
        """触发错误回调"""
        try:
            callbacks = self.error_callbacks.get(error_record.level, [])
            for callback in callbacks:
                try:
                    callback(error_record)
                except Exception as e:
                    logger.error(f"错误回调执行失败: {e}")
        except Exception as e:
            logger.error(f"触发错误回调失败: {e}")
    
    def add_error_callback(self, level: ErrorLevel, callback: Callable[[ErrorRecord], None]):
        """添加错误回调"""
        if callback not in self.error_callbacks[level]:
            self.error_callbacks[level].append(callback)
    
    def remove_error_callback(self, level: ErrorLevel, callback: Callable[[ErrorRecord], None]):
        """移除错误回调"""
        if callback in self.error_callbacks[level]:
            self.error_callbacks[level].remove(callback)
    
    def get_errors(self, 
                   level: Optional[ErrorLevel] = None,
                   category: Optional[ErrorCategory] = None,
                   resolved: Optional[bool] = None,
                   limit: Optional[int] = None) -> List[ErrorRecord]:
        """获取错误记录"""
        with self._lock:
            errors = self.error_records.copy()
        
        # 过滤
        if level:
            errors = [e for e in errors if e.level == level]
        if category:
            errors = [e for e in errors if e.category == category]
        if resolved is not None:
            errors = [e for e in errors if e.resolved == resolved]
        
        # 按时间排序（最新的在前）
        errors.sort(key=lambda x: x.timestamp, reverse=True)
        
        # 限制数量
        if limit:
            errors = errors[:limit]
        
        return errors
    
    def get_error_stats(self) -> Dict[str, Any]:
        """获取错误统计"""
        with self._lock:
            total_errors = len(self.error_records)
            unresolved_errors = sum(1 for e in self.error_records if not e.resolved)
            
            # 按级别统计
            level_stats = {}
            for level in ErrorLevel:
                level_stats[level.value] = sum(1 for e in self.error_records if e.level == level)
            
            # 按分类统计
            category_stats = {}
            for category in ErrorCategory:
                category_stats[category.value] = sum(1 for e in self.error_records if e.category == category)
            
            # 最近错误
            recent_errors = [e for e in self.error_records if time.time() - e.timestamp < 3600]  # 最近1小时
            
            return {
                "total_errors": total_errors,
                "unresolved_errors": unresolved_errors,
                "resolved_errors": total_errors - unresolved_errors,
                "level_stats": level_stats,
                "category_stats": category_stats,
                "recent_errors": len(recent_errors),
                "error_counters": self._error_counters.copy()
            }
    
    def resolve_error(self, error_id: str) -> bool:
        """标记错误为已解决"""
        with self._lock:
            for error in self.error_records:
                if error.id == error_id:
                    error.resolved = True
                    error.resolved_time = time.time()
                    self._save_errors()
                    return True
        return False
    
    def resolve_errors_by_category(self, category: ErrorCategory) -> int:
        """按分类标记错误为已解决"""
        resolved_count = 0
        with self._lock:
            for error in self.error_records:
                if error.category == category and not error.resolved:
                    error.resolved = True
                    error.resolved_time = time.time()
                    resolved_count += 1
            if resolved_count > 0:
                self._save_errors()
        return resolved_count
    
    def clear_errors(self, older_than_hours: Optional[int] = None):
        """清理错误记录"""
        with self._lock:
            if older_than_hours:
                cutoff_time = time.time() - (older_than_hours * 3600)
                self.error_records = [e for e in self.error_records if e.timestamp > cutoff_time]
            else:
                self.error_records.clear()
            
            # 重置计数器
            self._error_counters.clear()
            self._recent_errors.clear()
            
            self._save_errors()
    
    def export_errors(self, filename: str, 
                      level: Optional[ErrorLevel] = None,
                      category: Optional[ErrorCategory] = None):
        """导出错误记录"""
        errors = self.get_errors(level, category)
        data = [error.to_dict() for error in errors]
        
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    
    def get_error_trend(self, hours: int = 24) -> Dict[str, int]:
        """获取错误趋势"""
        cutoff_time = time.time() - (hours * 3600)
        recent_errors = [e for e in self.error_records if e.timestamp > cutoff_time]
        
        # 按小时分组
        trend = {}
        for error in recent_errors:
            hour_key = int(error.timestamp // 3600) * 3600
            trend[hour_key] = trend.get(hour_key, 0) + 1
        
        return trend
    
    def __str__(self) -> str:
        stats = self.get_error_stats()
        return f"ErrorHandler(total={stats['total_errors']}, unresolved={stats['unresolved_errors']})"
    
    def __repr__(self) -> str:
        return self.__str__()


class ChainProxyError(Exception):
    """Chain-Proxy 基础异常类"""
    pass


class ProxyConnectionError(ChainProxyError):
    """代理连接错误"""
    pass


class PortAllocationError(ChainProxyError):
    """端口分配错误"""
    pass


class ConfigurationError(ChainProxyError):
    """配置错误"""
    pass


class ThreadError(ChainProxyError):
    """线程错误"""
    pass
