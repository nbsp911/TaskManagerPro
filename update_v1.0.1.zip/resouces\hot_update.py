"""
热更新功能模块

功能：
1. 从远程地址读取更新信息（包含版本号、是否强制重启、更新的文件地址）
2. 比较版本号判断是否有更新
3. 下载更新的文件
4. 处理强制重启逻辑
"""

import json
import logging
import os
import shutil
import zipfile
from pathlib import Path
from typing import Optional, Dict, List, Tuple
import requests
from requests.exceptions import RequestException, Timeout, ConnectionError

# 尝试导入FileOper用于保存版本号
try:
    from file_oper import FileOper
except ImportError:
    FileOper = None

logger = logging.getLogger()

# 当前版本号（可以从配置文件中读取或硬编码）
CURRENT_VERSION = "1.0.0"


class HotUpdateInfo:
    """更新信息数据类"""
    
    def __init__(self, data: Dict):
        """
        初始化更新信息
        
        Args:
            data: 更新信息字典，包含以下字段：
                - version: 版本号字符串，如 "1.0.1"
                - force_restart: 是否强制重启，布尔值
                - update_files: 更新的文件列表，每个元素包含：
                    - url: 文件下载地址
                    - path: 本地保存路径（相对或绝对路径）
                    - md5: 文件MD5值（可选，用于校验）
        """
        self.version = data.get("version", "")
        self.force_restart = data.get("force_restart", False)
        self.update_files = data.get("update_files", [])
        self.description = data.get("description", "")  # 更新描述（可选）
        self.release_notes = data.get("release_notes", "")  # 发布说明（可选）
        
    def to_dict(self) -> Dict:
        """转换为字典"""
        return {
            "version": self.version,
            "force_restart": self.force_restart,
            "update_files": self.update_files,
            "description": self.description,
            "release_notes": self.release_notes,
        }


class HotUpdateManager:
    """热更新管理器"""
    
    def __init__(self, update_url: str, current_version: str = CURRENT_VERSION, 
                 timeout: int = 10, proxy: Optional[Dict[str, str]] = None,
                 project_root: Optional[str] = None):
        """
        初始化热更新管理器
        
        Args:
            update_url: 更新信息地址（JSON格式）
            current_version: 当前版本号
            timeout: 请求超时时间（秒）
            proxy: 代理配置，格式如 {"http": "http://proxy:port", "https": "https://proxy:port"}
            project_root: 项目根目录，如果为None则自动检测
        """
        self.update_url = update_url
        self.current_version = current_version
        self.timeout = timeout
        self.proxy = proxy
        self.update_info: Optional[HotUpdateInfo] = None
        
        # 确定项目根目录
        if project_root:
            self.project_root = Path(project_root).resolve()
        else:
            # 自动检测：从当前文件位置向上找到包含resouces目录的目录
            current_file = Path(__file__).resolve()
            self.project_root = current_file.parent.parent  # 从resouces目录回到项目根目录
        
        logger.info(f"项目根目录: {self.project_root}")
        
        # 如果提供了版本号，则使用；否则尝试从配置文件读取
        if current_version == CURRENT_VERSION:
            # 尝试从配置文件读取保存的版本号
            saved_version = self._get_saved_version_safe()
            if saved_version:
                self.current_version = saved_version
                logger.info(f"从配置文件读取版本号: {self.current_version}")
            else:
                self.current_version = current_version
                logger.info(f"使用默认版本号: {self.current_version}")
        else:
            self.current_version = current_version
        
    def check_update(self) -> Tuple[bool, Optional[HotUpdateInfo], Optional[str]]:
        """
        检查是否有更新
        
        Returns:
            (has_update, update_info, error_message)
            - has_update: 是否有更新
            - update_info: 更新信息对象，如果没有更新或出错则为None
            - error_message: 错误消息，如果没有错误则为None
        """
        try:
            logger.info(f"正在检查更新，当前版本: {self.current_version}")
            logger.info(f"更新信息地址: {self.update_url}")
            
            # 发送请求获取更新信息
            response = requests.get(
                self.update_url,
                timeout=self.timeout,
                proxies=self.proxy if self.proxy else None
            )
            response.raise_for_status()
            
            # 解析JSON响应
            data = response.json()
            self.update_info = HotUpdateInfo(data)
            
            # 比较版本号
            has_update = self._compare_version(self.current_version, self.update_info.version)
            
            if has_update:
                logger.info(f"发现新版本: {self.update_info.version}")
                return True, self.update_info, None
            else:
                logger.info(f"当前已是最新版本: {self.current_version}")
                return False, None, None
                
        except Timeout:
            error_msg = f"请求超时（{self.timeout}秒）"
            logger.error(error_msg)
            return False, None, error_msg
        except ConnectionError as e:
            error_msg = f"连接失败: {str(e)}"
            logger.error(error_msg)
            return False, None, error_msg
        except RequestException as e:
            error_msg = f"请求失败: {str(e)}"
            logger.error(error_msg)
            return False, None, error_msg
        except json.JSONDecodeError as e:
            error_msg = f"JSON解析失败: {str(e)}"
            logger.error(error_msg)
            return False, None, error_msg
        except Exception as e:
            error_msg = f"检查更新时发生未知错误: {str(e)}"
            logger.error(error_msg, exc_info=True)
            return False, None, error_msg
    
    def _compare_version(self, current: str, latest: str) -> bool:
        """
        比较版本号，判断是否有更新
        
        支持格式：1.0.0, 1.0.1, 2.0.0-beta 等
        
        Args:
            current: 当前版本号
            latest: 最新版本号
            
        Returns:
            True表示有新版本，False表示无更新
        """
        try:
            # 尝试使用packaging库（如果可用）
            try:
                from packaging import version as pkg_version
                current_ver = pkg_version.parse(current)
                latest_ver = pkg_version.parse(latest)
                return latest_ver > current_ver
            except ImportError:
                # 如果没有packaging库，使用简单的版本比较
                return self._simple_version_compare(current, latest)
        except Exception as e:
            logger.warning(f"版本号比较失败: {e}, 使用字符串比较")
            # 回退到字符串比较
            return latest > current
    
    def _simple_version_compare(self, current: str, latest: str) -> bool:
        """
        简单的版本号比较（不依赖外部库）
        
        将版本号按点号分割，逐段比较数字部分
        
        Args:
            current: 当前版本号
            latest: 最新版本号
            
        Returns:
            True表示有新版本
        """
        try:
            # 移除可能的 "v" 前缀和后缀标识符（如 -beta, -alpha）
            current = current.lstrip('vV').split('-')[0].split('+')[0]
            latest = latest.lstrip('vV').split('-')[0].split('+')[0]
            
            current_parts = [int(x) for x in current.split('.')]
            latest_parts = [int(x) for x in latest.split('.')]
            
            # 补齐长度
            max_len = max(len(current_parts), len(latest_parts))
            current_parts.extend([0] * (max_len - len(current_parts)))
            latest_parts.extend([0] * (max_len - len(latest_parts)))
            
            # 逐段比较
            for c, l in zip(current_parts, latest_parts):
                if l > c:
                    return True
                elif l < c:
                    return False
            
            return False  # 版本号相同
        except Exception:
            # 如果解析失败，使用字符串比较
            return latest > current
    
    def download_file(self, url: str, local_path: str, md5: Optional[str] = None) -> Tuple[bool, Optional[str]]:
        """
        下载文件
        
        Args:
            url: 文件下载地址
            local_path: 本地保存路径（相对项目根目录或绝对路径）
            md5: 文件MD5值（可选，用于校验）
            
        Returns:
            (success, error_message)
            - success: 下载是否成功
            - error_message: 错误消息，如果成功则为None
        """
        try:
            logger.info(f"开始下载文件: {url}")
            
            # 处理路径：如果是相对路径，则基于项目根目录
            if not Path(local_path).is_absolute():
                local_file = self.project_root / local_path
            else:
                local_file = Path(local_path)
            
            local_path = str(local_file)
            logger.info(f"保存路径: {local_path}")
            
            # 创建目录
            local_file.parent.mkdir(parents=True, exist_ok=True)
            
            # 下载文件
            response = requests.get(
                url,
                timeout=self.timeout * 3,  # 下载超时时间更长
                proxies=self.proxy if self.proxy else None,
                stream=True
            )
            response.raise_for_status()
            
            # 保存文件
            with open(local_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)
            
            # MD5校验（如果提供了）
            if md5:
                import hashlib
                with open(local_path, 'rb') as f:
                    file_md5 = hashlib.md5(f.read()).hexdigest()
                if file_md5.lower() != md5.lower():
                    error_msg = f"MD5校验失败: 期望 {md5}, 实际 {file_md5}"
                    logger.error(error_msg)
                    # 删除不正确的文件
                    if os.path.exists(local_path):
                        os.remove(local_path)
                    return False, error_msg
                logger.info(f"MD5校验通过: {file_md5}")
            
            logger.info(f"文件下载成功: {local_path}")
            return True, None
            
        except Exception as e:
            error_msg = f"下载文件失败: {str(e)}"
            logger.error(error_msg, exc_info=True)
            return False, error_msg
    
    def extract_zip(self, zip_path: str, extract_to: Optional[str] = None, 
                   backup_dir: Optional[str] = None) -> Tuple[bool, Optional[str], List[str]]:
        """
        解压ZIP包并更新文件
        
        Args:
            zip_path: ZIP文件路径
            extract_to: 解压目标目录（相对项目根目录），如果为None则解压到项目根目录
            backup_dir: 备份目录，如果为None则不备份
            
        Returns:
            (success, error_message, updated_files)
            - success: 解压是否成功
            - error_message: 错误消息，如果成功则为None
            - updated_files: 更新的文件列表（相对项目根目录）
        """
        try:
            logger.info(f"开始解压ZIP文件: {zip_path}")
            
            # 确定解压目标目录
            if extract_to:
                if not Path(extract_to).is_absolute():
                    extract_path = self.project_root / extract_to
                else:
                    extract_path = Path(extract_to)
            else:
                extract_path = self.project_root
            
            extract_path = extract_path.resolve()
            logger.info(f"解压目标目录: {extract_path}")
            
            # 准备备份目录
            if backup_dir:
                backup_path = Path(backup_dir)
                backup_path.mkdir(parents=True, exist_ok=True)
                logger.info(f"备份目录: {backup_path}")
            
            updated_files = []
            
            # 打开ZIP文件
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                # 获取ZIP内所有文件列表
                zip_file_list = zip_ref.namelist()
                logger.info(f"ZIP内包含 {len(zip_file_list)} 个文件/目录")
                
                # 遍历ZIP内的每个文件
                for zip_file_name in zip_file_list:
                    # 跳过目录
                    if zip_file_name.endswith('/'):
                        continue
                    
                    # 确定目标文件路径（相对项目根目录）
                    target_file = extract_path / zip_file_name
                    
                    # 确保目标目录存在
                    target_file.parent.mkdir(parents=True, exist_ok=True)
                    
                    # 备份原文件（如果存在）
                    if backup_dir and target_file.exists():
                        # 计算相对路径用于备份
                        try:
                            rel_path = target_file.relative_to(self.project_root)
                            backup_file = backup_path / rel_path
                            backup_file.parent.mkdir(parents=True, exist_ok=True)
                            shutil.copy2(target_file, backup_file)
                            logger.info(f"已备份文件: {target_file} -> {backup_file}")
                        except Exception as e:
                            logger.warning(f"备份文件失败 {target_file}: {e}")
                    
                    # 提取文件
                    try:
                        # 读取ZIP内文件内容
                        with zip_ref.open(zip_file_name) as source:
                            # 写入目标文件
                            with open(target_file, 'wb') as target:
                                target.write(source.read())
                        
                        # 记录更新的文件（相对项目根目录）
                        try:
                            rel_path = target_file.relative_to(self.project_root)
                            updated_files.append(str(rel_path).replace('\\', '/'))
                            logger.info(f"已更新文件: {rel_path}")
                        except ValueError:
                            # 如果文件不在项目根目录下，使用绝对路径
                            updated_files.append(str(target_file))
                            logger.info(f"已更新文件: {target_file}")
                    
                    except Exception as e:
                        logger.error(f"解压文件失败 {zip_file_name}: {e}")
                        # 继续处理其他文件，不中断整个流程
            
            # 注意：ZIP文件的删除由调用方（apply_update）处理，这里不删除
            # 这样可以允许调用方在删除前做其他操作（如校验等）
            
            logger.info(f"ZIP解压完成，共更新 {len(updated_files)} 个文件")
            return True, None, updated_files
            
        except zipfile.BadZipFile:
            error_msg = "ZIP文件格式错误或已损坏"
            logger.error(error_msg)
            return False, error_msg, []
        except Exception as e:
            error_msg = f"解压ZIP文件失败: {str(e)}"
            logger.error(error_msg, exc_info=True)
            return False, error_msg, []
    
    def apply_update(self, backup_dir: Optional[str] = None) -> Tuple[bool, Optional[str], List[str]]:
        """
        应用更新
        
        支持两种更新方式：
        1. 单个文件列表：逐个下载并更新文件
        2. ZIP包：下载ZIP文件，自动解压并更新ZIP内所有文件
        
        Args:
            backup_dir: 备份目录（相对项目根目录），如果为None则不备份
            
        Returns:
            (success, error_message, updated_files)
            - success: 更新是否成功
            - error_message: 错误消息，如果成功则为None
            - updated_files: 更新的文件列表（相对项目根目录）
        """
        if not self.update_info:
            return False, "没有更新信息", []
        
        updated_files = []
        failed_files = []
        
        try:
            # 处理备份目录路径
            if backup_dir:
                if not Path(backup_dir).is_absolute():
                    backup_path = self.project_root / backup_dir
                else:
                    backup_path = Path(backup_dir)
                backup_path.mkdir(parents=True, exist_ok=True)
                logger.info(f"备份目录: {backup_path}")
                backup_dir_str = str(backup_path)
            else:
                backup_dir_str = None
            
            # 下载并更新每个文件
            for file_info in self.update_info.update_files:
                file_url = file_info.get("url")
                file_path = file_info.get("path")
                file_md5 = file_info.get("md5")
                file_type = file_info.get("type", "").lower()  # 文件类型：zip或其他
                extract_to = file_info.get("extract_to")  # ZIP解压目标目录
                
                if not file_url or not file_path:
                    logger.warning(f"文件信息不完整: {file_info}")
                    failed_files.append(str(file_info))
                    continue
                
                # 处理ZIP包类型
                if file_type == "zip" or file_path.lower().endswith('.zip'):
                    # 下载ZIP文件到临时目录
                    temp_zip_path = self.project_root / "tmp" / f"update_{file_path.split('/')[-1]}"
                    temp_zip_path.parent.mkdir(parents=True, exist_ok=True)
                    temp_zip_str = str(temp_zip_path)
                    
                    # 下载ZIP文件
                    success, error_msg = self.download_file(file_url, temp_zip_str, file_md5)
                    if not success:
                        failed_files.append(file_path)
                        logger.error(f"下载ZIP文件失败: {file_path}, 错误: {error_msg}")
                        continue
                    
                    # 解压ZIP文件
                    zip_success, zip_error, zip_updated_files = self.extract_zip(
                        temp_zip_str, 
                        extract_to=extract_to,
                        backup_dir=backup_dir_str
                    )
                    
                    if zip_success:
                        updated_files.extend(zip_updated_files)
                        logger.info(f"ZIP包解压成功，更新了 {len(zip_updated_files)} 个文件")
                        
                        # 解压成功后，删除下载的ZIP文件
                        if os.path.exists(temp_zip_str):
                            try:
                                os.remove(temp_zip_str)
                                logger.info(f"已删除更新包: {temp_zip_str}")
                            except Exception as e:
                                logger.warning(f"删除更新包失败: {temp_zip_str}, 错误: {e}")
                    else:
                        failed_files.append(file_path)
                        logger.error(f"解压ZIP文件失败: {file_path}, 错误: {zip_error}")
                        
                        # 解压失败时也尝试删除ZIP文件，避免占用空间
                        if os.path.exists(temp_zip_str):
                            try:
                                os.remove(temp_zip_str)
                                logger.info(f"已清理失败的更新包: {temp_zip_str}")
                            except Exception:
                                pass
                
                else:
                    # 处理单个文件
                    # 确定文件路径
                    if not Path(file_path).is_absolute():
                        full_file_path = self.project_root / file_path
                    else:
                        full_file_path = Path(file_path)
                    
                    # 备份原文件
                    if backup_dir_str and full_file_path.exists():
                        try:
                            rel_path = full_file_path.relative_to(self.project_root)
                            backup_file = Path(backup_dir_str) / rel_path
                            backup_file.parent.mkdir(parents=True, exist_ok=True)
                            shutil.copy2(full_file_path, backup_file)
                            logger.info(f"已备份文件: {file_path} -> {backup_file}")
                        except Exception as e:
                            logger.warning(f"备份文件失败 {file_path}: {e}")
                    
                    # 下载文件
                    success, error_msg = self.download_file(file_url, file_path, file_md5)
                    if success:
                        updated_files.append(file_path)
                    else:
                        failed_files.append(file_path)
                        logger.error(f"更新文件失败: {file_path}, 错误: {error_msg}")
            
            # 检查是否有失败的文件
            if failed_files:
                error_msg = f"部分文件更新失败: {failed_files}"
                logger.error(error_msg)
                return False, error_msg, updated_files
            
            logger.info(f"更新完成，共更新 {len(updated_files)} 个文件")
            
            # 更新成功后，保存新版本号
            if self.update_info and self.update_info.version:
                self._save_version(self.update_info.version)
            
            return True, None, updated_files
            
        except Exception as e:
            error_msg = f"应用更新时发生错误: {str(e)}"
            logger.error(error_msg, exc_info=True)
            return False, error_msg, updated_files
    
    def _save_version(self, version: str) -> bool:
        """
        保存版本号到配置文件
        
        Args:
            version: 版本号字符串
            
        Returns:
            True表示保存成功，False表示保存失败
        """
        try:
            # 尝试使用FileOper保存到sys_config.json
            if FileOper:
                try:
                    FileOper.write_sys_config({"app_version": version})
                    logger.info(f"版本号已保存到配置文件: {version}")
                    return True
                except Exception as e:
                    logger.warning(f"使用FileOper保存版本号失败: {e}")
            
            # 回退方案：直接保存到version.json文件
            version_file = self.project_root / "tmp" / "version.json"
            try:
                version_file.parent.mkdir(parents=True, exist_ok=True)
                version_data = {"version": version}
                with open(version_file, 'w', encoding='utf-8') as f:
                    json.dump(version_data, f, indent=2, ensure_ascii=False)
                logger.info(f"版本号已保存到版本文件: {version_file} -> {version}")
                return True
            except Exception as e:
                logger.warning(f"保存版本号到文件失败: {e}")
                return False
                
        except Exception as e:
            logger.warning(f"保存版本号失败: {e}")
            return False
    
    def _get_saved_version_safe(self) -> Optional[str]:
        """
        从配置文件读取保存的版本号（内部方法，在初始化时调用）
        
        Returns:
            版本号字符串，如果未找到则返回None
        """
        try:
            # 优先从sys_config.json读取
            if FileOper:
                try:
                    sys_config = FileOper.get_sys_config()
                    if sys_config and isinstance(sys_config, dict):
                        version = sys_config.get("app_version")
                        if version:
                            return version
                except Exception:
                    pass
            
            # 回退方案：从version.json读取
            version_file = self.project_root / "tmp" / "version.json"
            if version_file.exists():
                try:
                    with open(version_file, 'r', encoding='utf-8') as f:
                        version_data = json.load(f)
                        version = version_data.get("version")
                        if version:
                            return version
                except Exception:
                    pass
            
            return None
        except Exception:
            return None
    
    def get_saved_version(self) -> Optional[str]:
        """
        从配置文件读取保存的版本号
        
        Returns:
            版本号字符串，如果未找到则返回None
        """
        try:
            # 优先从sys_config.json读取
            if FileOper:
                try:
                    sys_config = FileOper.get_sys_config()
                    if sys_config and isinstance(sys_config, dict):
                        version = sys_config.get("app_version")
                        if version:
                            logger.info(f"从系统配置读取版本号: {version}")
                            return version
                except Exception as e:
                    logger.debug(f"从系统配置读取版本号失败: {e}")
            
            # 回退方案：从version.json读取
            version_file = self.project_root / "tmp" / "version.json"
            if version_file.exists():
                try:
                    with open(version_file, 'r', encoding='utf-8') as f:
                        version_data = json.load(f)
                        version = version_data.get("version")
                        if version:
                            logger.info(f"从版本文件读取版本号: {version_file} -> {version}")
                            return version
                except Exception as e:
                    logger.debug(f"从版本文件读取版本号失败: {e}")
            
            return None
        except Exception as e:
            logger.debug(f"读取版本号失败: {e}")
            return None
    
    def get_update_summary(self) -> Dict:
        """
        获取更新摘要
        
        Returns:
            包含更新信息的字典
        """
        if not self.update_info:
            return {
                "has_update": False,
                "current_version": self.current_version,
                "latest_version": None,
                "force_restart": False,
                "file_count": 0,
            }
        
        return {
            "has_update": True,
            "current_version": self.current_version,
            "latest_version": self.update_info.version,
            "force_restart": self.update_info.force_restart,
            "file_count": len(self.update_info.update_files),
            "description": self.update_info.description,
            "release_notes": self.update_info.release_notes,
        }


def check_and_update(update_url: str, current_version: str = CURRENT_VERSION,
                     proxy: Optional[Dict[str, str]] = None,
                     auto_apply: bool = False,
                     backup_dir: Optional[str] = None) -> Dict:
    """
    便捷函数：检查并应用更新
    
    Args:
        update_url: 更新信息地址
        current_version: 当前版本号
        proxy: 代理配置
        auto_apply: 是否自动应用更新
        backup_dir: 备份目录
        
    Returns:
        包含更新结果的字典
    """
    manager = HotUpdateManager(update_url, current_version, proxy=proxy)
    has_update, update_info, error_msg = manager.check_update()
    
    result = {
        "has_update": has_update,
        "update_info": update_info.to_dict() if update_info else None,
        "error": error_msg,
        "summary": manager.get_update_summary(),
    }
    
    if has_update and auto_apply:
        success, apply_error, updated_files = manager.apply_update(backup_dir)
        result["apply_success"] = success
        result["apply_error"] = apply_error
        result["updated_files"] = updated_files
        result["force_restart"] = update_info.force_restart if update_info else False
    
    return result


# 示例更新信息JSON格式

# 方式1：ZIP包更新（推荐，ZIP里有什么文件就更新什么文件）
EXAMPLE_UPDATE_INFO_ZIP = {
    "version": "1.0.1",
    "force_restart": True,
    "description": "全文件更新包",
    "release_notes": "本次更新包含以下改进：\n1. 修复了某些bug\n2. 性能优化\n3. 新增功能",
    "update_files": [
        {
            "url": "https://example.com/updates/update_v1.0.1.zip",
            "path": "tmp/update.zip",
            "type": "zip",
            "md5": "abc123def456..."  # 可选
        }
    ]
}

# 方式2：单个文件列表更新
EXAMPLE_UPDATE_INFO_FILES = {
    "version": "1.0.1",
    "force_restart": False,
    "description": "修复了一些已知问题",
    "release_notes": "本次更新包含以下改进：\n1. 修复了某些bug\n2. 性能优化",
    "update_files": [
        {
            "url": "https://example.com/update/file1.py",
            "path": "resouces/file1.py",
            "md5": "abc123def456..."  # 可选
        },
        {
            "url": "https://example.com/update/file2.py",
            "path": "resouces/file2.py"
        }
    ]
}

# 默认示例（保持向后兼容）
EXAMPLE_UPDATE_INFO = EXAMPLE_UPDATE_INFO_ZIP

