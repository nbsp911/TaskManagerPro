

from typing import Callable, Optional, Set

from PySide6.QtWidgets import (
    QDialog,
    QListWidget,
    QListWidgetItem,
    QPushButton,
    QVBoxLayout,
    QHBoxLayout,
    QInputDialog,
    QMessageBox,
    QWidget,
)

from file_oper import FileOper


def open_group_dialog(parent: QWidget, callback: Callable[[Set[str]], None] = None) -> Optional[Set[str]]:
    """打开分组管理对话框，返回更新后的分组集合（若取消则返回 None）。"""

    # 初始取调用方集合（优先），否则从磁盘加载
    current = FileOper.get_groups()

    dlg = QDialog(parent)
    dlg.setWindowTitle("分组管理")
    try:
        dlg.resize(420, 320)
    except Exception:
        pass

    list_widget = QListWidget(dlg)
    for g in sorted(current):
        QListWidgetItem(g, list_widget)

    add_btn = QPushButton("添加", dlg)
    edit_btn = QPushButton("修改", dlg)
    del_btn = QPushButton("删除", dlg)
    close_btn = QPushButton("关闭", dlg)

    def _refresh():
        list_widget.clear()
        for g in sorted(current):
            QListWidgetItem(g, list_widget)

        FileOper.write_groups(current)
        if callback:
            callback(current)
        
    def _add():
        name, ok = QInputDialog.getText(dlg, "添加分组", "分组名称：")
        if not ok:
            return
        name = (name or "").strip()
        if not name:
            return
        current.append(name)
        _refresh()

    def _edit():
        item = list_widget.currentItem()
        if not item:
            return
        old = item.text()
        new_name, ok = QInputDialog.getText(dlg, "修改分组", "新的分组名称：", text=old)
        if not ok:
            return
        new_name = (new_name or "").strip()
        if not new_name or new_name == old:
            return
        # 变更集合
        try:
            current.discard(old)
        except Exception:
            pass
        current.add(new_name)
        _refresh()

    def _delete():
        item = list_widget.currentItem()
        if not item:
            return
        g = item.text()
        # 仅从集合删除，是否仍被任务使用由调用方决定
        try:
            current.discard(g)
        except Exception:
            pass
        _refresh()

    add_btn.clicked.connect(_add)
    edit_btn.clicked.connect(_edit)
    del_btn.clicked.connect(_delete)
    close_btn.clicked.connect(dlg.accept)

    layout = QVBoxLayout(dlg)
    layout.addWidget(list_widget, 1)
    row = QHBoxLayout()
    row.addWidget(add_btn)
    row.addWidget(edit_btn)
    row.addWidget(del_btn)
    row.addStretch(1)
    row.addWidget(close_btn)
    layout.addLayout(row)

    if dlg.exec_():
        # 持久化并返回
        return current
    return None


