"""
注册码生成器
根据系统硬件信息生成唯一的注册码
"""

import hashlib
import platform
import subprocess
import sys
from typing import Optional

try:
    import psutil
    HAS_PSUTIL = True
except ImportError:
    HAS_PSUTIL = False


def get_cpu_id() -> str:
    """获取CPU ID"""
    try:
        if platform.system() == 'Windows':
            result = subprocess.run(
                ['wmic', 'cpu', 'get', 'ProcessorId'],
                capture_output=True,
                text=True,
                creationflags=subprocess.CREATE_NO_WINDOW
            )
            lines = result.stdout.strip().split('\n')
            if len(lines) > 1:
                return lines[1].strip()
        elif platform.system() == 'Linux':
            result = subprocess.run(
                ['cat', '/proc/cpuinfo'],
                capture_output=True,
                text=True
            )
            for line in result.stdout.split('\n'):
                if 'Serial' in line:
                    return line.split(':')[1].strip()
        elif platform.system() == 'Darwin':  # macOS
            result = subprocess.run(
                ['sysctl', '-n', 'machdep.cpu.brand_string'],
                capture_output=True,
                text=True
            )
            return result.stdout.strip()
    except Exception:
        pass
    return ""


def get_mac_address() -> str:
    """获取MAC地址"""
    import uuid
    mac = uuid.getnode()
    return ':'.join(('%012X' % mac)[i:i+2] for i in range(0, 12, 2))


def get_machine_guid() -> str:
    """获取机器GUID（Windows特有）"""
    try:
        if platform.system() == 'Windows':
            result = subprocess.run(
                ['reg', 'query', 'HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Cryptography', '/v', 'MachineGuid'],
                capture_output=True,
                text=True,
                creationflags=subprocess.CREATE_NO_WINDOW
            )
            for line in result.stdout.split('\n'):
                if 'MachineGuid' in line:
                    parts = line.split()
                    if len(parts) >= 3:
                        return parts[-1]
    except Exception:
        pass
    return ""


def get_disk_serial() -> str:
    """获取硬盘序列号"""
    try:
        if platform.system() == 'Windows':
            result = subprocess.run(
                ['wmic', 'diskdrive', 'get', 'serialnumber'],
                capture_output=True,
                text=True,
                creationflags=subprocess.CREATE_NO_WINDOW
            )
            lines = result.stdout.strip().split('\n')
            if len(lines) > 1:
                return lines[1].strip()
        elif platform.system() == 'Linux':
            result = subprocess.run(
                ['lsblk', '-o', 'SERIAL', '-n'],
                capture_output=True,
                text=True
            )
            return result.stdout.strip().split('\n')[0] if result.stdout.strip() else ""
    except Exception:
        pass
    return ""


def get_system_info() -> str:
    """
    收集系统唯一标识信息
    
    Returns:
        系统信息字符串
    """
    info_parts = []
    
    # CPU信息
    cpu_id = get_cpu_id()
    if cpu_id:
        info_parts.append(f"CPU:{cpu_id}")
    
    # MAC地址
    mac = get_mac_address()
    if mac:
        info_parts.append(f"MAC:{mac}")
    
    # 机器GUID（Windows）
    machine_guid = get_machine_guid()
    if machine_guid:
        info_parts.append(f"GUID:{machine_guid}")
    
    # 硬盘序列号
    disk_serial = get_disk_serial()
    if disk_serial:
        info_parts.append(f"DISK:{disk_serial}")
    
    # 系统平台信息
    info_parts.append(f"PLATFORM:{platform.system()}-{platform.machine()}")
    
    # 如果安装了psutil，添加更多硬件信息
    if HAS_PSUTIL:
        try:
            # 内存信息
            mem = psutil.virtual_memory()
            info_parts.append(f"MEM:{mem.total}")
        except Exception:
            pass
    
    # 组合所有信息
    system_info = "|".join(info_parts)
    
    return system_info


def generate_registration_code() -> str:
    """
    根据系统信息生成注册码
    
    Returns:
        32位十六进制注册码（格式：XXXX-XXXX-XXXX-XXXX-XXXX-XXXX-XXXX-XXXX）
    """
    # 获取系统信息
    system_info = get_system_info()
    
    # 使用SHA256哈希生成固定长度的注册码
    hash_obj = hashlib.sha256(system_info.encode('utf-8'))
    hash_hex = hash_obj.hexdigest()
    
    # 格式化为8组4位字符，用-分隔
    formatted_code = '-'.join([hash_hex[i:i+4] for i in range(0, 32, 4)])
    
    return formatted_code.upper()


def verify_registration_code(registration_code: str) -> bool:
    """
    验证注册码是否与当前系统匹配
    
    Args:
        registration_code: 要验证的注册码
    
    Returns:
        True: 注册码与系统匹配
        False: 注册码与系统不匹配
    """
    current_code = generate_registration_code()
    return registration_code.upper() == current_code.upper()
