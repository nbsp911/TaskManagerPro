

import math
import urllib.request
from typing import Optional

from PySide6.QtCore import Qt, QTimer, QUrl, Signal
from PySide6.QtGui import QColor, QDesktopServices, QPixmap, QPainter, QPainterPath
from PySide6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QGridLayout,
    QLabel,
    QPushButton,
    QSpinBox,
    QSizePolicy,
    QMessageBox,
    QDialog,
    QLineEdit,
    QTableWidget,
    QTableWidgetItem,
    QHeaderView,
    QAbstractItemView,
    QComboBox,
)
from tools import *
from app_globals import *
import datetime
from file_oper import FileOper

import logging
logger = logging.getLogger()

class BinanceAlphaSettingsTab(QWidget):
    """
    "Binance Alpha 设置"标签页：
    - 可配置交易对、合约地址、积分倍数
    - 展示 24h 行情（价格/高/低/涨跌幅/成交量）
    - 支持手动和定时刷新
    - 支持跳转到交易详情或区块浏览器
    """
    
    # 定义信号，用于线程安全的UI更新
    show_retry_dialog_signal = Signal()

    def __init__(self, *, parent: QWidget | None = None):
        super().__init__(parent)

        self._timer: Optional[QTimer] = None
        self.binance_alpha_token_list = []
        
        # 连接信号
        self.show_retry_dialog_signal.connect(self._show_retry_dialog)
        
        self._setup_ui()
        # 初次刷新
        self._refresh_now()

    # ---------- UI ----------
    def _setup_ui(self) -> None:
        root = QVBoxLayout(self)

        # 头部：代币图标 + 名称 + 积分倍数
        header_widget = QWidget()
        try:
            header_widget.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        except Exception:
            pass
        header_box = QVBoxLayout(header_widget)
        header_box.setSpacing(6)
        try:
            # 顶部预留空间，让图标整体下移
            header_box.setContentsMargins(0, 45, 0, 0)
        except Exception:
            pass

        # 粉色圆圈：代币图标（占位）
        self.token_icon_img = QLabel()
        try:
            self.token_icon_img.setFixedSize(96, 96)
            self.token_icon_img.setAlignment(Qt.AlignCenter)
            # 移除粉色占位样式，保持透明背景
            self.token_icon_img.setStyleSheet("")
        except Exception:
            pass
        # 右下角单独的小图标（初始化时创建并定位）
        try:
            overlay_size = max(10, self.token_icon_img.width() // 3)
            self._rt_overlay = QLabel(self.token_icon_img)
            self._rt_overlay.setScaledContents(True)
            # 加载默认小图（可替换为任意路径）
            try:
                self._rt_overlay.setPixmap(QPixmap("resouces/images/icon.ico"))
            except Exception:
                pass
            # 圆角 + 黑色边框
            radius = max(2, int(overlay_size * 0.2))
            self._rt_overlay.setStyleSheet(
                f"border: 3px solid #000; border-radius: {radius}px; background: transparent;"
            )
            self._rt_overlay.setFixedSize(overlay_size, overlay_size)
            # 定位在父图标右下角
            self._rt_overlay.move(self.token_icon_img.width() - overlay_size, self.token_icon_img.height() - overlay_size)
            self._rt_overlay.show()
        except Exception:
            pass
        header_box.addWidget(self.token_icon_img, 0, Qt.AlignHCenter)
        # 名称与倍数整体居中并紧随图标下方

        # 名称 + 倍数（同一行，居中）
        name_row = QHBoxLayout()
        name_row.setSpacing(8)
        self.token_name_label = QLabel("-")
        self.token_name_label.setAlignment(Qt.AlignCenter)
        self.token_name_label.setStyleSheet("color:#FFF; font-size:20px; font-weight:600;")
        self.points_display_label = QLabel("")
        self.points_display_label.setAlignment(Qt.AlignCenter)
        self.points_display_label.setStyleSheet("color:#F00; font-size:14px;")
        # 防止两侧拉伸，使用内容大小
        try:
            self.token_name_label.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Preferred)
            self.points_display_label.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Preferred)
        except Exception:
            pass
        name_row.addWidget(self.token_name_label)
        name_row.addWidget(self.points_display_label)
        header_box.addLayout(name_row)
        try:
            header_box.setAlignment(name_row, Qt.AlignHCenter)
        except Exception:
            pass

        # 将头部整体以固定尺寸添加，紧贴顶部且水平居中
        root.addWidget(header_widget, 0, Qt.AlignHCenter | Qt.AlignTop)

        # 顶部：基本设置行（仅合约地址）
        top_row = QHBoxLayout()
        top_row.setSpacing(10)
        # 手动选择项目 按钮（切换式，仅样式切换，不添加业务逻辑）
        try:
            self.manual_select_button = QPushButton("自动选择项目")
            self.manual_select_button.setObjectName("manualSelectBtn")
            self.manual_select_button.setCheckable(True)
            # 默认未按下（使用未按下的绿色背景）
            try:
                self.manual_select_button.setChecked(False)
            except Exception:
                pass
            try:
                self.manual_select_button.setCursor(Qt.PointingHandCursor)
                self.manual_select_button.setFixedHeight(28)
                # 缩小宽度
                self.manual_select_button.setFixedWidth(140)
            except Exception:
                pass
            # 未按下：绿色；按下：橙色
            self.manual_select_button.setStyleSheet(
                """
                QPushButton#manualSelectBtn {
                    background-color: #28a745;
                    color: #ffffff;
                    border-radius: 6px;
                    border: 1px solid #1e7e34;
                    font-weight: 600;
                }
                QPushButton#manualSelectBtn:checked {
                    background-color: #ff9800;
                    color: #ffffff;
                    border: 1px solid #f57c00;
                }
                QPushButton#manualSelectBtn:hover:!disabled {
                    background-color: #2cb34f;
                }
                QPushButton#manualSelectBtn:disabled {
                    background-color: #9aa0a6;
                    color: #f1f3f4;
                    border: 1px solid #6c757d;
                }
                """
            )
            # 文案随按下状态切换
            try:
                self.manual_select_button.clicked.connect(self._on_manual_select_toggled)
                # 初始化文案
                #self._on_manual_select_toggled(self.manual_select_button.isChecked())
            except Exception:
                pass
            # 居中：在按钮左右添加弹性伸展
            top_row.addStretch(1)
            top_row.addWidget(self.manual_select_button)
            top_row.addStretch(1)
        except Exception:
            pass
        # 合约地址展示为标签
        self.contract_value_label = QLabel("-")
        try:
            self.contract_value_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        except Exception:
            pass
        # 合约地址标签将放到信息网格底部显示，这里不加入 top_row

        root.addLayout(top_row)

        # 中部：信息网格（四列：左标题/左值/右标题/右值）
        grid = QGridLayout()
        grid.setHorizontalSpacing(24)
        grid.setVerticalSpacing(16)
        # 调整列伸展比例：缩小第三列（右侧标题），放大第四列的数值列
        try:
            grid.setColumnStretch(0, 3)
            grid.setColumnStretch(1, 2)
            grid.setColumnStretch(2, 1)  # 第三列更窄
            grid.setColumnStretch(3, 3)
        except Exception:
            pass

        def add_pair(r: int, ltitle: str, lvalue: QLabel, rtitle: str, rvalue: QLabel):
            l_title = QLabel(ltitle)
            r_title = QLabel(rtitle)
            # 对齐规则：标题右对齐，内容左对齐
            try:
                l_title.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
                r_title.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
                lvalue.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
                rvalue.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
                # 放大字体
                l_title.setStyleSheet("font-size: 14px;")
                r_title.setStyleSheet("font-size: 14px;")
                lvalue.setStyleSheet("font-size: 14px;")
                rvalue.setStyleSheet("font-size: 14px;")
            except Exception:
                pass
            lvalue.setText("-")
            rvalue.setText("-")
            grid.addWidget(l_title, r, 0)
            grid.addWidget(lvalue, r, 1)
            grid.addWidget(r_title, r, 2)
            grid.addWidget(rvalue, r, 3)

        self.price_label = QLabel()
        self.marketcap_label = QLabel()
        self.volume_label = QLabel()
        self.circ_marketcap_label = QLabel()
        self.spot_listed_label = QLabel()
        self.binance_exclusive_label = QLabel()
        self.alpha_score_label = QLabel()
        self.hot_label = QLabel()
        self.high24_label = QLabel()
        self.low24_label = QLabel()
        self.change24_label = QLabel()
        self.listing_time_label = QLabel()

        add_pair(0, "价格:", self.price_label, "市值:", self.marketcap_label)
        add_pair(1, "24h成交额:", self.volume_label, "流动性:", self.circ_marketcap_label)
        add_pair(2, "已上线现货:", self.spot_listed_label, "Binance 独家项目:", self.binance_exclusive_label)
        add_pair(3, "Alpha 官方评分:", self.alpha_score_label, "是否热门:", self.hot_label)
        add_pair(4, "24小时最高价:", self.high24_label, "24小时最低价:", self.low24_label)
        add_pair(5, "24小时涨跌幅:", self.change24_label, "上线时间:", self.listing_time_label)

        # 合约地址：单独占一行，值横跨右侧三列
        contract_title = QLabel("合约地址：")
        try:
            contract_title.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
            self.contract_value_label.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
            # 放大字体
            contract_title.setStyleSheet("font-size: 14px;")
            self.contract_value_label.setStyleSheet("font-size: 14px;")
        except Exception:
            pass
        grid.addWidget(contract_title, 6, 0)
        grid.addWidget(self.contract_value_label, 6, 1, 1, 3)

        # 行高更高一些
        try:
            for r in range(0, 7):
                grid.setRowMinimumHeight(r, 28)
        except Exception:
            pass

        # 与头部之间增加 20px 间距
        root.addSpacing(30)
        root.addLayout(grid)
        try:
            root.setAlignment(grid, Qt.AlignTop)
        except Exception:
            pass
        # 使用弹性伸展将网格固定在顶部，并把底部按钮区推到底部
        root.addStretch(1)

        # 底部：刷新与详情
        bottom_row = QHBoxLayout()
        bottom_row.setSpacing(12)
        self.interval_spin = QSpinBox()
        self.interval_spin.setRange(1, 1440)
        self.interval_spin.setValue(10)
        self.interval_spin.setPrefix("每 ")
        self.interval_spin.setSuffix(" 分钟刷新")

        self.refresh_button = QPushButton("手动刷新")
        self.detail_button = QPushButton("查看详情")

        bottom_row.addWidget(self.interval_spin)
        bottom_row.addWidget(self.refresh_button)
        bottom_row.addStretch(1)
        bottom_row.addWidget(self.detail_button)

        root.addSpacing(6)
        root.addLayout(bottom_row)

        # 行为
        self.refresh_button.clicked.connect(self._refresh_now)
        self.detail_button.clicked.connect(self._open_detail)
        self.interval_spin.valueChanged.connect(self._apply_timer)

        # 定时器
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._refresh_now)
        self._apply_timer()


    # ---------- Actions ----------
    def _apply_timer(self) -> None:
        if not self._timer:
            return
        minutes = max(1, int(self.interval_spin.value()))
        self._timer.stop()
        self._timer.start(minutes * 60 * 1000)

    # ---------- UI ----------
    def _create_manual_select_dialog(self):
        """创建手动选择项目弹窗的UI相关部分，返回 dlg, table, ok_btn"""
        dlg = QDialog(self)
        dlg.setWindowTitle("手动选择项目")
        try:
            dlg.resize(720, 520)
        except Exception:
            pass

        vbox = QVBoxLayout(dlg)
        vbox.setContentsMargins(12, 12, 12, 12)
        vbox.setSpacing(10)

        # 顶部搜索框
        search_edit = QLineEdit()
        try:
            search_edit.setPlaceholderText("请输入 Alpha 代币名称")
            search_edit.setFixedHeight(34)
        except Exception:
            pass
        vbox.addWidget(search_edit)

        # 表格
        table = QTableWidget()
        table.setColumnCount(8)
        table.setHorizontalHeaderLabels(["名称", "价格", "市值", "24h成交额", "流动性", "24小时涨跌", "上线时间", "积分倍数"])
        try:
            # 设置列宽模式：名称列使用拉伸模式，其他列使用内容自适应
            table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)  # 名称 - 拉伸填充剩余空间
            table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeToContents)  # 价格
            table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeToContents)  # 市值
            table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeToContents)  # 24h成交额
            table.horizontalHeader().setSectionResizeMode(4, QHeaderView.ResizeToContents)  # 流动性
            table.horizontalHeader().setSectionResizeMode(5, QHeaderView.ResizeToContents)  # 24小时涨跌
            table.horizontalHeader().setSectionResizeMode(6, QHeaderView.ResizeToContents)  # 上线时间
            table.horizontalHeader().setSectionResizeMode(7, QHeaderView.ResizeToContents)  # 积分倍数
            table.setSelectionBehavior(QAbstractItemView.SelectRows)
            table.setSelectionMode(QAbstractItemView.SingleSelection)
            table.setEditTriggers(QAbstractItemView.NoEditTriggers)
            
            # 设置其他列的最小宽度，名称列会自动拉伸填充剩余空间
            table.setColumnWidth(1, 120)  # 价格
            table.setColumnWidth(2, 120)  # 市值
            table.setColumnWidth(3, 120)  # 24h成交额
            table.setColumnWidth(4, 120)  # 流动性
            table.setColumnWidth(5, 100)  # 24小时涨跌
            table.setColumnWidth(6, 100)  # 上线时间
            table.setColumnWidth(7, 80)   # 积分倍数
        except Exception:
            pass
        vbox.addWidget(table, 1)

        # 底部按钮
        ok_btn = QPushButton("确定")
        try:
            ok_btn.setFixedHeight(34)
        except Exception:
            pass
        h = QHBoxLayout()
        h.addStretch(1)
        h.addWidget(ok_btn)
        h.addStretch(1)
        vbox.addLayout(h)
        # 预置选择结果
        try:
            setattr(dlg, "selected_token", None)
        except Exception:
            pass

        # 数据填充与筛选函数
        def fmt_amount(v):
            return format_amount(safe_float(v), suffix="")
        def fmt_price(v):
            return format_price(safe_float(v))
        def fmt_change(v):
            val = safe_float(v)
            if val is None:
                return "-"
            sign = "+" if val >= 0 else ""
            return f"{sign}{val:.2f}%"
        def fmt_date_ms(ms):
            if ms is None:
                return "-"
            try:
                return datetime.datetime.fromtimestamp(int(ms) / 1000).strftime("%Y-%m-%d")
            except Exception:
                return "-"
        def fmt_points(v):
            if v is None:
                return "-"
            return f"{v}x"
        def fmt_liquidity(v):
            return format_amount(safe_float(v), suffix="")

        raw_rows = list(self.binance_alpha_token_list or [])
        # 当前可见行（受搜索过滤影响）
        current_rows: list = []

        def apply_filter():
            keyword = (search_edit.text() or "").strip().lower()
            rows = raw_rows
            if keyword:
                rows = [r for r in raw_rows if keyword in ((r.get("symbol") or "").lower())]
            
            # 应用排序 - 统一的多级排序：积分 > 流动性 > 市值
            def sort_key(x):
                points = safe_float(x.get("mulPoint")) or 0
                liquidity = safe_float(x.get("liquidity")) or 0
                market_cap = safe_float(x.get("marketCap")) or 0
                return (-points, -liquidity, -market_cap)  # 负号表示降序
            
            rows.sort(key=sort_key)
            
            # 覆盖当前可见行
            try:
                current_rows[:] = rows
            except Exception:
                pass
            table.setRowCount(len(rows))
            for i, r in enumerate(rows):
                name = str(r.get("symbol") or "-")
                price = fmt_price(r.get("price"))
                mc = fmt_amount(r.get("marketCap"))
                volume = fmt_amount(r.get("volume24h"))
                points = fmt_points(r.get("mulPoint"))
                liquidity = fmt_liquidity(r.get("liquidity"))
                change = fmt_change(r.get("percentChange24h"))
                date = fmt_date_ms(r.get("listingTime"))

                items = [
                    QTableWidgetItem(name),
                    QTableWidgetItem(price),
                    QTableWidgetItem(mc),
                    QTableWidgetItem(volume),
                    QTableWidgetItem(liquidity),
                    QTableWidgetItem(change),
                    QTableWidgetItem(date),
                    QTableWidgetItem(points),
                ]
                # 设置积分倍数列（最后一列）居中对齐
                items[7].setTextAlignment(Qt.AlignCenter)
                
                for col, it in enumerate(items):
                    table.setItem(i, col, it)
        apply_filter()
        try:
            search_edit.textChanged.connect(apply_filter)
        except Exception:
            pass
        # 确定按钮：获取选中行并写回到对话框属性后关闭
        def _on_ok():
            try:
                row = table.currentRow()
            except Exception:
                row = -1
            selected = None
            if row is not None and row >= 0 and row < len(current_rows):
                selected = current_rows[row]
            try:
                setattr(dlg, "selected_token", selected)
            except Exception:
                pass
            dlg.accept()
        try:
            ok_btn.clicked.connect(_on_ok)
        except Exception:
            pass
        return dlg

    def _on_manual_select_toggled(self, checked: bool) -> None:
        
        if checked:
            dlg = self._create_manual_select_dialog()
            # 展示并等待选择
            dlg.exec()
            # 读取选择结果并应用
            try:
                selected = getattr(dlg, "selected_token", None)
                if selected:
                    # 保存配置
                    sys_config = FileOper.get_sys_config()
                    sys_config["hand_select_project"] = {"enabled": True, "tokenId": selected.get("tokenId")}
                    FileOper.write_sys_config(sys_config)

                    set_best_binance_alpha_token(selected)
                    self._refresh_now()

                    self.manual_select_button.setChecked(True)
                    self.manual_select_button.setText("手动选择项目")
            except Exception:
                pass
            self._refresh_now()
        else:
            sys_config = FileOper.get_sys_config()
            sys_config["hand_select_project"] = {"enabled": False, "tokenId": None}
            FileOper.write_sys_config(sys_config)
            
            self._refresh_now()
    

    # 打开详情
    def _open_detail(self) -> None:
        best_token = get_best_binance_alpha_token()
        if not best_token:
            QMessageBox.warning(self, "提示", "未获取到合适的币种或合约地址。")
            return
        chainName = (best_token.get("chainName") or "").strip()
        contract_address = (best_token.get("contractAddress") or "").strip()
        if not chainName or not contract_address:
            QMessageBox.warning(self, "提示", "未获取到合适的币种或合约地址。")
            return

        chainName = chainName.lower()
        url = f"https://www.binance.com/zh-CN/alpha/{chainName}/{contract_address}"
        try:
            QDesktopServices.openUrl(QUrl(url))
        except Exception:
            pass

    # ---------- Data ----------
    def _refresh_now(self) -> None:
        try:
            self.binance_alpha_token_list = get_binance_alpha_token_list_request(callback=self._on_binance_alpha_token_list_received)
        except Exception as e:
            logger.error(f"[BinanceAlpha设置] 启动数据获取时出错: {e}")
            # 使用信号安全地显示对话框
            self.show_retry_dialog_signal.emit()
        
    def _on_binance_alpha_token_list_received(self, data: any) -> None:
        try:
            self.binance_alpha_token_list = data
            if not self.binance_alpha_token_list:
                logger.error(f"[BinanceAlpha设置] 获取数据Alpha项目列表失败")
                # 使用信号安全地显示对话框
                self.show_retry_dialog_signal.emit()
                return

            # 自动选择项目
            data = None
            sys_config = FileOper.get_sys_config()
            hand_select_project = sys_config.get("hand_select_project", {})
            if sys_config and hand_select_project.get("enabled"):
                tokenId = hand_select_project.get("tokenId")
                if tokenId:
                    data = next((item for item in self.binance_alpha_token_list if item.get("tokenId") == tokenId), None)
                    if not data:
                        data = None
            
            if not data:
                data = sort_and_get_best_binance_alpha_token(self.binance_alpha_token_list)
                if not data:
                    logger.error(f"[BinanceAlpha设置] 获取数据Alpha项目失败")
                    # 使用信号安全地显示对话框
                    self.show_retry_dialog_signal.emit()
                    return
            
            set_best_binance_alpha_token(data)
            self._fetch_24h(data)
        except Exception as e:
            logger.error(f"[BinanceAlpha设置] 处理数据时出错: {e}")
            # 使用信号安全地显示对话框
            self.show_retry_dialog_signal.emit()

    def _show_retry_dialog(self) -> None:
        """显示重试对话框，用户点击确认后重新获取数据"""
        try:
            msg_box = QMessageBox(self)
            msg_box.setWindowTitle("获取数据失败")
            msg_box.setText("获取 Binance Alpha 项目列表失败，请检查网络，如果没有获取到列表，将无法正常刷积分，是否重试？")
            msg_box.setStandardButtons(QMessageBox.Ok | QMessageBox.Cancel)
            msg_box.setDefaultButton(QMessageBox.Ok)
            
            result = msg_box.exec()
            if result == QMessageBox.Ok:
                # 用户点击确认，重新获取数据
                logger.info(f"[BinanceAlpha设置] 用户选择重试，重新获取数据")
                self._refresh_now()
            else:
                # 用户取消，可以选择退出或显示错误信息
                logger.info(f"[BinanceAlpha设置] 用户取消重试，数据获取失败")
        except Exception as e:
            logger.error(f"[BinanceAlpha设置] 显示重试对话框时出错: {e}")
            # 如果对话框显示失败，直接重试
            self._refresh_now()

    def _fetch_24h(self, data: any) -> None:
        # 更新 UI
        last_price = safe_float(data.get("price"))
        high = safe_float(data.get("priceHigh24h"))
        low = safe_float(data.get("priceLow24h"))
        volume = safe_float(data.get("volume24h"))  # 以计价货币计价的成交额
        change_pct = safe_float(data.get("percentChange24h"))

        symbol = data.get("symbol") or "-"
        self.token_name_label.setText(symbol)

        # 获取合约地址
        contractAddress = data.get("contractAddress") or "-"
        self.contract_value_label.setText(contractAddress)

        # 市值设置
        market_cap = safe_float(data.get("marketCap"))
        circ_market_cap = safe_float(data.get("liquidity"))

        self.price_label.setText(format_price(last_price))
        self.high24_label.setText(format_price(high))
        self.low24_label.setText(format_price(low))
        self.volume_label.setText(format_amount(volume, suffix=""))


        # 积分倍数设置
        points_multiplier = data.get("mulPoint")
        self.points_display_label.setText(f"【{points_multiplier}x 积分】")


        # 涨跌幅着色
        if change_pct is None:
            self.change24_label.setText("-")
            self.change24_label.setStyleSheet("")
        else:
            sign = "+" if change_pct >= 0 else ""
            self.change24_label.setText(f"{sign}{change_pct:.2f}%")
            color = "#28a745" if change_pct >= 0 else "#dc3545"
            self.change24_label.setStyleSheet(f"color: {color};")

        # 其他字段暂无权威接口，先占位
        self.marketcap_label.setText(format_amount(market_cap, suffix="") if market_cap is not None else "-")
        self.circ_marketcap_label.setText(format_amount(circ_market_cap, suffix="") if circ_market_cap is not None else "-")
        self.alpha_score_label.setText(format_amount(data.get("score"), suffix="") if data.get("score") is not None else "-")
        
        # 是否热门
        hotTag = data.get("hotTag")
        self.hot_label.setText(self._format_state(hotTag))

        # 是否已上线现货
        listingCex = data.get("listingCex")
        self.spot_listed_label.setText(self._format_state(listingCex))

        # 是否独家：暂无官方公开接口，显示“-”
        bn_exclusive_state = data.get("bnExclusiveState")
        self.binance_exclusive_label.setText(self._format_state(bn_exclusive_state))

        # 上线时间
        listing_time = data.get("listingTime")
        # 上线时间（毫秒时间戳）转换为年月日格式
        self.listing_time_label.setText(self._format_listing_time(listing_time))

        sys_config = FileOper.get_sys_config()
        hand_select_project = sys_config.get("hand_select_project", {})

        #设置按钮状态
        if not sys_config or not hand_select_project.get("enabled"):
            self.manual_select_button.setChecked(False)
            self.manual_select_button.setText("自动选择项目")
        else:
            self.manual_select_button.setChecked(True)
            self.manual_select_button.setText("手动选择项目")

        # 设置图标
        self.set_token_icon_by_url(data.get("iconUrl"))

        self.set_rt_overlay_by_url(data.get("chainIconUrl"))


    def set_token_icon_by_url(self, url: str) -> None:
        """
        根据URL设置图标。如果下载失败则忽略。
        """
        if not url:
            self.token_icon_img.setPixmap(QPixmap())
            return
        try:
            # 下载图片数据
            with urllib.request.urlopen(url, timeout=8) as resp:
                data = resp.read()
            pixmap = QPixmap()
            if pixmap.loadFromData(data):
                # 缩放并裁剪为圆形头像（96x96）
                rounded = self._to_round_pixmap(pixmap, 96)
                self.token_icon_img.setPixmap(rounded)
                return
        except Exception:
            pass
        # 失败则清空图标
        self.token_icon_img.setPixmap(QPixmap())

    def set_rt_overlay_by_url(self, url: str) -> None:
        """
        根据URL设置右下角图标（链logo等），网络图片。
        """
        if not url:
            self._rt_overlay.setPixmap(QPixmap())
            return
        try:
            # 网络下载图片数据，和set_token_icon_by_url类似
            with urllib.request.urlopen(url, timeout=8) as resp:
                data = resp.read()
            pixmap = QPixmap()
            if pixmap.loadFromData(data):
                self._rt_overlay.setPixmap(pixmap)
                return
        except Exception:
            pass
        # 失败则清空
        self._rt_overlay.setPixmap(QPixmap())

    def _format_listing_time(self, time: any) -> str:
        if time is None:
            return "-"
        try:
            date_str = datetime.datetime.fromtimestamp(int(time) / 1000).strftime("%Y-%m-%d")
            return date_str
        except Exception:
            return "-"
    
    def _to_round_pixmap(self, src: QPixmap, size: int) -> QPixmap:
        try:
            # 先按比例放大裁剪成正方形以填满圆
            scaled = src.scaled(size, size, Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
            if scaled.width() != size or scaled.height() != size:
                # 中心裁剪
                x = max(0, (scaled.width() - size) // 2)
                y = max(0, (scaled.height() - size) // 2)
                scaled = scaled.copy(x, y, size, size)
            canvas = QPixmap(size, size)
            canvas.fill(Qt.transparent)
            painter = QPainter(canvas)
            painter.setRenderHint(QPainter.Antialiasing, True)
            path = QPainterPath()
            path.addEllipse(0, 0, size, size)
            painter.setClipPath(path)
            painter.drawPixmap(0, 0, scaled)
            painter.end()
            return canvas
        except Exception:
            return src.scaled(size, size, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            

    def _format_state(self, state: any) -> str:
        if state is None:
            return "-"
        if isinstance(state, bool):
            return "是" if state else "否"
        return str(state)

    def _format_points_multiplier_text(self, value: float) -> str:
        try:
            # 去除无意义的小数位
            if abs(value - int(value)) < 1e-9:
                return f"{int(value)}x积分"
            return f"{value:.1f}x积分"
        except Exception:
            return f"{value}x积分"


# ---------- helpers ----------
def safe_float(x) -> Optional[float]:
    try:
        if x is None:
            return None
        return float(x)
    except Exception:
        return None


def format_price(v: Optional[float]) -> str:
    if v is None or math.isnan(v):
        return "-"
    # 根据数值范围选择小数位数
    if v >= 1:
        return f"${v:,.4f}"
    if v >= 0.01:
        return f"${v:,.6f}"
    return f"${v:,.8f}"


def format_amount(v: Optional[float], *, suffix: str = "") -> str:
    if v is None or math.isnan(v):
        return "-"
    # 简易缩写：K/M/B
    abs_v = abs(v)
    if abs_v >= 1_000_000_000:
        return f"{v/1_000_000_000:.2f}B{suffix}"
    if abs_v >= 1_000_000:
        return f"{v/1_000_000:.2f}M{suffix}"
    if abs_v >= 1_000:
        return f"{v/1_000:.2f}K{suffix}"
    return f"{v:.0f}{suffix}"


