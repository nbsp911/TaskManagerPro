"""
脚本配置文件 - 替代 scripts_config.json
定义所有可用的自动化脚本及其参数配置
"""


from typing import Dict, Any, List
from data_type import ScriptConfig

# 脚本配置数据
SCRIPTS_CONFIG_DATA: List[Dict[str, Any]] = [
    {
        "id": "binance_alpha",
        "name": "BinanceAlpha",
        "path": "scripts.binance_alpha",
        "dynamic_property": {
            "buy_premium": {
                "show_name": "买入溢价(%)",
                "type": "text",
                "regex": "^(?:[0-4](?:\\.\\d+)?|5(?:\\.0*)?)$",
                "desc": "*浮动设置大一点防止价格波动太大，委托订单无法成交",
                "def_val": 0.5
            },
            "sell_discount": {
                "show_name": "卖出折扣(%)",
                "type": "text",
                "regex": "^(?:[0-4](?:\\.\\d+)?|5(?:\\.0*)?)$",
                "desc": "*浮动设置大一点，防止价格波动太大，无法成效订单，订单累计过多，流水刷不上去",
                "def_val": 1.0
            },
            "trade_amount_per_order": {
                "show_name": "单次交易额(USDT)",
                "type": "text",
                "regex": "^[1-9]\\d*$",
                "desc": "*帐户里请保持交易额的5倍，否则可能出现订单委托累积无法继续刷流水",
                "def_val": 100
            },
            "total_points_stop": {
                "show_name": "每日积分上限",
                "type": "text",
                "regex": "^[1-9]\\d*$",
                "desc": "*单日刷65536档性价比最好，每可获得16点积分, 积分为交易额*积分倍数, 每日统计一次总数",
                "def_val": 65700
            },
            "authenticator": {
                "show_name": "Google Authenticator",
                "type": "text",
                "regex": None,
                "desc": "*如果未设置验证器，一段时间后要人工干预",
                "def_val": ""
            },
            "qr_code_btn": {
                "show_name": "上传 Google Authenticator 二维码 ",
                "type": "button",
                "regex": None,
                "desc": None,
                "def_val": None
            }
        }
    }
]


def get_scripts_config() -> List[ScriptConfig]:
    """
    获取所有脚本配置
    
    Returns:
        List[ScriptConfig]: 脚本配置列表
    """
    return [ScriptConfig(**script_data) for script_data in SCRIPTS_CONFIG_DATA]


def get_script_config_by_id(script_id: str) -> ScriptConfig | None:
    """
    根据脚本ID获取脚本配置
    
    Args:
        script_id (str): 脚本ID
        
    Returns:
        ScriptConfig | None: 脚本配置，如果不存在则返回None
    """
    for script_data in SCRIPTS_CONFIG_DATA:
        if script_data["id"] == script_id:
            return ScriptConfig(**script_data)
    return None