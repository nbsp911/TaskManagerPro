
import random
# 代理常用国家列表，若有缺少的可补充
countries = [
    {
        "show_name": "中国",
        "lang_list": "zh-CN,zh;q=0.9,en;q=0.8",
        "timezone": "Asia/Shanghai"
    },
    {
        "show_name": "中国香港",
        "lang_list": "zh-HK,zh-TW;q=0.9,zh;q=0.8,en;q=0.7",
        "timezone": "Asia/Hong_Kong"
    },
    {
        "show_name": "中国台湾",
        "lang_list": "zh-TW,zh-HK;q=0.9,zh;q=0.8,en;q=0.7",
        "timezone": "Asia/Taipei"
    },
    {
        "show_name": "美国",
        "lang_list": "en-US,en;q=0.9",
        "timezone": "America/New_York"
    },
    {
        "show_name": "日本",
        "lang_list": "ja-JP,ja;q=0.9,en;q=0.8",
        "timezone": "Asia/Tokyo"
    },
    {
        "show_name": "韩国",
        "lang_list": "ko-KR,ko;q=0.9,en;q=0.8",
        "timezone": "Asia/Seoul"
    },
    {
        "show_name": "德国",
        "lang_list": "de-DE,de;q=0.9,en;q=0.8",
        "timezone": "Europe/Berlin"
    },
    {
        "show_name": "英国",
        "lang_list": "en-GB,en;q=0.9",
        "timezone": "Europe/London"
    },
    {
        "show_name": "法国",
        "lang_list": "fr-FR,fr;q=0.9,en;q=0.8",
        "timezone": "Europe/Paris"
    },
    {
        "show_name": "意大利",
        "lang_list": "it-IT,it;q=0.9,en;q=0.8",
        "timezone": "Europe/Rome"
    },
    {
        "show_name": "加拿大",
        "lang_list": "en-CA,en;q=0.9",
        "timezone": "America/Toronto"
    },
    {
        "show_name": "澳大利亚",
        "lang_list": "en-AU,en;q=0.9",
        "timezone": "Australia/Sydney"
    },
    {
        "show_name": "俄罗斯",
        "lang_list": "ru-RU,ru;q=0.9,en;q=0.8",
        "timezone": "Europe/Moscow"
    },
    {
        "show_name": "印度",
        "lang_list": "hi-IN,hi;q=0.9,en;q=0.8",
        "timezone": "Asia/Kolkata"
    },
    {
        "show_name": "新加坡",
        "lang_list": "en-US,en;q=0.9",
        "timezone": "Asia/Singapore"
    },
    {
        "show_name": "巴西",
        "lang_list": "pt-BR,pt;q=0.9,en;q=0.8",
        "timezone": "America/Sao_Paulo"
    },
    {
        "show_name": "西班牙",
        "lang_list": "es-ES,es;q=0.9,en;q=0.8",
        "timezone": "Europe/Madrid"
    },
    {
        "show_name": "墨西哥",
        "lang_list": "es-MX,es;q=0.9,en;q=0.8",
        "timezone": "America/Mexico_City"
    },
    {
        "show_name": "泰国",
        "lang_list": "th-TH,th;q=0.9,en;q=0.8",
        "timezone": "Asia/Bangkok"
    },
    {
        "show_name": "越南",
        "lang_list": "vi-VN,vi;q=0.9,en;q=0.8",
        "timezone": "Asia/Ho_Chi_Minh"
    },
    {
        "show_name": "马来西亚",
        "lang_list": "ms-MY,ms;q=0.9,en;q=0.8",
        "timezone": "Asia/Kuala_Lumpur"
    },
    {
        "show_name": "印度尼西亚",
        "lang_list": "id-ID,id;q=0.9,en;q=0.8",
        "timezone": "Asia/Jakarta"
    },
    {
        "show_name": "土耳其",
        "lang_list": "tr-TR,tr;q=0.9,en;q=0.8",
        "timezone": "Europe/Istanbul"
    },
    {
        "show_name": "阿根廷",
        "lang_list": "es-AR,es;q=0.9,en;q=0.8",
        "timezone": "America/Argentina/Buenos_Aires"
    },
    {
        "show_name": "南非",
        "lang_list": "af-ZA,af;q=0.9,en;q=0.8",
        "timezone": "Africa/Johannesburg"
    },
    {
        "show_name": "沙特阿拉伯",
        "lang_list": "ar-SA,ar;q=0.9,en;q=0.8",
        "timezone": "Asia/Riyadh"
    },
    {
        "show_name": "阿联酋",
        "lang_list": "ar-AE,ar;q=0.9,en;q=0.8",
        "timezone": "Asia/Dubai"
    },
    {
        "show_name": "瑞典",
        "lang_list": "sv-SE,sv;q=0.9,en;q=0.8",
        "timezone": "Europe/Stockholm"
    },
    {
        "show_name": "瑞士",
        "lang_list": "de-CH,de;q=0.9,en;q=0.8",
        "timezone": "Europe/Zurich"
    },
    {
        "show_name": "荷兰",
        "lang_list": "nl-NL,nl;q=0.9,en;q=0.8",
        "timezone": "Europe/Amsterdam"
    },
    {
        "show_name": "波兰",
        "lang_list": "pl-PL,pl;q=0.9,en;q=0.8",
        "timezone": "Europe/Warsaw"
    },
    {
        "show_name": "葡萄牙",
        "lang_list": "pt-PT,pt;q=0.9,en;q=0.8",
        "timezone": "Europe/Lisbon"
    },
    {
        "show_name": "希腊",
        "lang_list": "el-GR,el;q=0.9,en;q=0.8",
        "timezone": "Europe/Athens"
    },
    {
        "show_name": "比利时",
        "lang_list": "fr-BE,fr;q=0.9,en;q=0.8",
        "timezone": "Europe/Brussels"
    },
    {
        "show_name": "奥地利",
        "lang_list": "de-AT,de;q=0.9,en;q=0.8",
        "timezone": "Europe/Vienna"
    },
    {
        "show_name": "新西兰",
        "lang_list": "en-NZ,en;q=0.9",
        "timezone": "Pacific/Auckland"
    },
    {
        "show_name": "埃及",
        "lang_list": "ar-EG,ar;q=0.9,en;q=0.8",
        "timezone": "Africa/Cairo"
    },
    {
        "show_name": "以色列",
        "lang_list": "he-IL,he;q=0.9,en;q=0.8",
        "timezone": "Asia/Jerusalem"
    },
    {
        "show_name": "捷克",
        "lang_list": "cs-CZ,cs;q=0.9,en;q=0.8",
        "timezone": "Europe/Prague"
    },
    {
        "show_name": "匈牙利",
        "lang_list": "hu-HU,hu;q=0.9,en;q=0.8",
        "timezone": "Europe/Budapest"
    },
    {
        "show_name": "乌克兰",
        "lang_list": "uk-UA,uk;q=0.9,en;q=0.8",
        "timezone": "Europe/Kyiv"
    },
    {
        "show_name": "丹麦",
        "lang_list": "da-DK,da;q=0.9,en;q=0.8",
        "timezone": "Europe/Copenhagen"
    },
    {
        "show_name": "挪威",
        "lang_list": "nb-NO,nb;q=0.9,no;q=0.8,en;q=0.7",
        "timezone": "Europe/Oslo"
    },
    {
        "show_name": "爱尔兰",
        "lang_list": "ga-IE,ga;q=0.9,en;q=0.8",
        "timezone": "Europe/Dublin"
    },
    {
        "show_name": "芬兰",
        "lang_list": "fi-FI,fi;q=0.9,en;q=0.8",
        "timezone": "Europe/Helsinki"
    },
    {
        "show_name": "菲律宾",
        "lang_list": "en-US,en;q=0.9",
        "timezone": "Asia/Manila"
    },
    {
        "show_name": "巴基斯坦",
        "lang_list": "ur-PK,ur;q=0.9,en;q=0.8",
        "timezone": "Asia/Karachi"
    },
    {
        "show_name": "智利",
        "lang_list": "es-CL,es;q=0.9,en;q=0.8",
        "timezone": "America/Santiago"
    },
    {
        "show_name": "哥伦比亚",
        "lang_list": "es-CO,es;q=0.9,en;q=0.8",
        "timezone": "America/Bogota"
    },
    {
        "show_name": "罗马尼亚",
        "lang_list": "ro-RO,ro;q=0.9,en;q=0.8",
        "timezone": "Europe/Bucharest"
    },
    {
        "show_name": "委内瑞拉",
        "lang_list": "es-VE,es;q=0.9,en;q=0.8",
        "timezone": "America/Caracas"
    },
    {
        "show_name": "哈萨克斯坦",
        "lang_list": "kk-KZ,kk;q=0.9,ru;q=0.8,en;q=0.7",
        "timezone": "Asia/Almaty"
    },
    {
        "show_name": "爱沙尼亚",
        "lang_list": "et-EE,et;q=0.9,en;q=0.8",
        "timezone": "Europe/Tallinn"
    },
    {
        "show_name": "立陶宛",
        "lang_list": "lt-LT,lt;q=0.9,en;q=0.8",
        "timezone": "Europe/Vilnius"
    },
    {
        "show_name": "拉脱维亚",
        "lang_list": "lv-LV,lv;q=0.9,en;q=0.8",
        "timezone": "Europe/Riga"
    },
    {
        "show_name": "斯洛伐克",
        "lang_list": "sk-SK,sk;q=0.9,en;q=0.8",
        "timezone": "Europe/Bratislava"
    },
    {
        "show_name": "斯洛文尼亚",
        "lang_list": "sl-SI,sl;q=0.9,en;q=0.8",
        "timezone": "Europe/Ljubljana"
    },
    {
        "show_name": "克罗地亚",
        "lang_list": "hr-HR,hr;q=0.9,en;q=0.8",
        "timezone": "Europe/Zagreb"
    },
    {
        "show_name": "塞尔维亚",
        "lang_list": "sr-RS,sr;q=0.9,en;q=0.8",
        "timezone": "Europe/Belgrade"
    },
    {
        "show_name": "保加利亚",
        "lang_list": "bg-BG,bg;q=0.9,en;q=0.8",
        "timezone": "Europe/Sofia"
    },
    {
        "show_name": "卢森堡",
        "lang_list": "fr-FR,fr;q=0.9,en;q=0.8",
        "timezone": "Europe/Luxembourg"
    },
    {
        "show_name": "摩纳哥",
        "lang_list": "fr-FR,fr;q=0.9,en;q=0.8",
        "timezone": "Europe/Monaco"
    },
    {
        "show_name": "冰岛",
        "lang_list": "is-IS,is;q=0.9,en;q=0.8",
        "timezone": "Atlantic/Reykjavik"
    },
    {
        "show_name": "格鲁吉亚",
        "lang_list": "ka-GE,ka;q=0.9,en;q=0.8",
        "timezone": "Asia/Tbilisi"
    },
    {
        "show_name": "摩洛哥",
        "lang_list": "ar-MA,ar;q=0.9,en;q=0.8",
        "timezone": "Africa/Casablanca"
    },
    {
        "show_name": "肯尼亚",
        "lang_list": "sw-KE,sw;q=0.9,en;q=0.8",
        "timezone": "Africa/Nairobi"
    },
    {
        "show_name": "尼日利亚",
        "lang_list": "yo-NG,yo;q=0.9,en;q=0.8",
        "timezone": "Africa/Lagos"
    },
    {
        "show_name": "秘鲁",
        "lang_list": "es-PE,es;q=0.9,en;q=0.8",
        "timezone": "America/Lima"
    },
    {
        "show_name": "厄瓜多尔",
        "lang_list": "es-EC,es;q=0.9,en;q=0.8",
        "timezone": "America/Guayaquil"
    },
    {
        "show_name": "哥斯达黎加",
        "lang_list": "es-CR,es;q=0.9,en;q=0.8",
        "timezone": "America/Costa_Rica"
    },
    {
        "show_name": "巴拿马",
        "lang_list": "es-PA,es;q=0.9,en;q=0.8",
        "timezone": "America/Panama"
    },
    {
        "show_name": "乌拉圭",
        "lang_list": "es-UY,es;q=0.9,en;q=0.8",
        "timezone": "America/Montevideo"
    },
    {
        "show_name": "巴拉圭",
        "lang_list": "es-PY,es;q=0.9,en;q=0.8",
        "timezone": "America/Asuncion"
    },
    {
        "show_name": "阿尔及利亚",
        "lang_list": "ar-SA,ar;q=0.9,en;q=0.8",
        "timezone": "Africa/Algiers"
    },
    {
        "show_name": "卡塔尔",
        "lang_list": "ar-QA,ar;q=0.9,en;q=0.8",
        "timezone": "Asia/Qatar"
    },
    {
        "show_name": "科威特",
        "lang_list": "ar-SA,ar;q=0.9,en;q=0.8",
        "timezone": "Asia/Kuwait"
    }
]

user_anget = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.7390.108 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.7390.99 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.7390.72 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.7390.55 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.7359.94 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.7359.82 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.7359.33 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.7238.123 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.7238.68 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.6900.66 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.6900.30 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.6854.112 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.6854.70 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.6846.21 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.6846.10 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.6801.99 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.6796.47 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.6240.149 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.6240.76 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.6175.95 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.6161.86 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.5999.123 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.5985.77 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.6582.5 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.6582.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.6582.1 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.6582.2 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.6582.3 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.6533.36 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.6533.20 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.6533.25 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.6533.29 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.6533.32 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.6478.71 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.6478.57 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.6478.54 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.6478.69 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.6478.70 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.6422.117 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.6422.112 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.6422.113 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.6422.114 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.6422.116 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.6367.91 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.6367.78 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.6367.76 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.6367.60 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.6367.42 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.6312.122 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.6312.86 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.6312.70 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.6312.45 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.6312.17 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.6261.119 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.6261.111 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.6261.92 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.6261.70 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.6261.47 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.6167.185 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.6167.160 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.6167.72 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.6167.49 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.6167.9 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.6099.110 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.6099.91 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.6099.58 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.6099.42 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.6099.13 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.6045.199 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.6045.160 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.5993.118 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.5993.90 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.5938.149 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.5938.92 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.5845.188 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.5845.172 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.5790.198 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.5790.102 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.5735.199 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.5735.134 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.5672.147 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.5672.126 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.5615.197 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.5615.138 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.5563.148 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.5563.65 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.5481.178 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.5481.69 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.5414.119 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.5414.87 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.5359.125 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.5359.95 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.5304.121 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.5304.107 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.5249.199 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.5249.119 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.5195.125 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.5195.102 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.5112.102 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.5112.101 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.5060.134 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.5060.53 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.5005.148 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.5005.63 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.67 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.41 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.75 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.60 Safari/537.36",
    ]



def get_countries():
    return countries

def get_country_by_idx(idx=0):
    return countries[idx]

def get_random_user_anget():
    return random.choice(user_anget)