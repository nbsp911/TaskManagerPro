from typing import Any
from selenium import webdriver
from data_type import *
from file_oper import FileOper
from slot_events import DriverManagerSignal
from selenium_connect import create_webdriver_by_config_data
import traceback, importlib, threading
from selenium_tools import *
from scripts.scripts_config import get_script_config_by_id
from register_dialog import check_registration
import logging

logger = logging.getLogger()
class DriverSessionStatusEvent():
    status: DriverSessionStatus = DriverSessionStatus.IDLE
    def change(self, config_id: str, status: DriverSessionStatus):
        prev_status = self.status
        if prev_status == status:
            return
        self.status = status
        DriverManagerSignal.status_changed.emit(config_id, prev_status, self.status)

@dataclass
class DriverSession:
    config_data: ConfigData | None = None
    loop_thread: threading.Thread | None = None
    loop_thread_stop_event: threading.Event | None = None
    status_event: DriverSessionStatusEvent = field(default_factory=DriverSessionStatusEvent)
    driver: webdriver.Remote | None = None
    script_instance: Any | None = None

class DriverManager:
    _driver_session_map: dict[str, DriverSession] = {}

    @staticmethod
    def active_count() -> int:
        return len(DriverManager._driver_session_map)

    @staticmethod
    def update_session(config_id: str):

        config_data = FileOper.get_config_by_id(config_id)
        if config_data is None:
            logger.error(f" DriverSession 添加失败: config_data not found: {config_id}")
            return False
        if config_id in DriverManager._driver_session_map:
            logger.error(f" DriverSession 添加失败: DriverSession 已存在: {config_id}")
            return False

        if DriverManager._driver_session_map.get(config_id) is None:
            DriverManager._driver_session_map[config_id] = DriverSession(config_data=config_data)
            logger.info(f"DriverSession 添加成功: {config_id}")
        else:
            DriverManager._driver_session_map[config_id].config_data = config_data
            logger.info(f"DriverSession 更新成功: {config_id}")

            # TODO: 浏览器对象看下要不要更新
        return True
    
    @staticmethod
    def get_session(config_id: str) -> DriverSession | None:
        return DriverManager._driver_session_map.get(config_id)

    @staticmethod
    def start(config_id: str):

        if not check_registration():
            return False

        # 检查单实例运行
        DriverManager.update_session(config_id)
        driver_session = DriverManager.get_session(config_id)
        if driver_session is None:
            logger.error(f" DriverSession 启动失败: DriverSession 不存在: {config_id}")
            return False

        config_data = driver_session.config_data
        if config_data is None:
            logger.error(f" DriverSession 启动失败: config_data not found: {config_id}")
            return False

        driver_session.loop_thread_stop_event = threading.Event()

        # 创建 loop 线程
        driver_session.loop_thread = DriverManager._create_loop_thread(driver_session)
        if driver_session.loop_thread is None:
            return False

        return True
        
    # TODO: 需要实现这个方法
    @staticmethod
    def stop(config_id: str):
        driver_session = DriverManager.get_session(config_id)
        if driver_session is None:
            logger.error(f" DriverSession 停止失败: DriverSession 不存在: {config_id}")
            return False

        # 判断状态是否为 RUNNING,如果不是则不停止
        if driver_session.status_event.status != DriverSessionStatus.RUNNING:
            logger.info(f" DriverSession 停止失败: DriverSession 状态不是 RUNNING: {config_id}")
            return False

        # 设置状态为停止中
        driver_session.status_event.change(config_id=config_id, status=DriverSessionStatus.STOPPING)

        def _stop_driver_session():
            # 停止 loop 线程
            try:
                driver_session.loop_thread_stop_event.set()
                driver_session.loop_thread.join()
            except Exception as e:
                logger.error(f" DriverSession 停止失败: {e} driver_session: {driver_session}")

            # 停止脚本实例
            try:
                driver_session.script_instance.clear()
            except Exception as e:
                logger.error(f" DriverSession 停止失败: {e} driver_session: {driver_session}")

            # 停止浏览器对象
            try:
                driver_session.driver.quit()
            except Exception as e:
                logger.error(f" DriverSession 停止失败: {e} driver_session: {driver_session}")

            driver_session.status_event.change(config_id=config_id, status=DriverSessionStatus.STOPPED)

            # 删除 DriverSession 对象在 DriverManager._driver_session_map 中的引用
            try:
                if config_id in DriverManager._driver_session_map:
                    DriverManager._driver_session_map.pop(config_id)
                else:
                    logger.warning(f" DriverSession 删除时未找到: {config_id}")
            except Exception as e:
                logger.error(f" DriverSession 停止失败: {e} driver_session: {driver_session}")

            return True

        stop_thread = threading.Thread(target=_stop_driver_session)
        stop_thread.name = f"DriverManager_stop_thread_{config_id}"
        stop_thread.start()
        return True

    # 停止所有处于 RUNNING 状态的 DriverSession
    @staticmethod
    def stop_all():
        for config_id, driver_session in list(DriverManager._driver_session_map.items()):
            try:
                if hasattr(driver_session, "status_event") and \
                   getattr(driver_session.status_event, "status", None) == DriverSessionStatus.RUNNING:
                    DriverManager.stop(config_id)
            except Exception as e:
                logger.error(f" stop_all 停止任务异常: {e} config_id: {config_id}")

    @staticmethod
    def _create_loop_thread(driver_session: DriverSession):
        # if driver_session.loop_thread_stop_event is not None:
        #     logger.warning(f" 循环_loop_thread 线程已存在: {driver_session}")
        #     return None

        try:
            thread = threading.Thread(target=DriverManager._loop_thread, args=(driver_session,))
            thread.name = f"DriverManager_loop_thread_{driver_session.config_data.id}"
            thread.daemon = True
            thread.start()
            return thread
        except Exception as e:
            logger.error(f" 创建 loop_thread 失败: {e} driver_session: {driver_session}")
            
        return None

    @staticmethod
    def _loop_thread(driver_session: DriverSession):
        logger.info(f" ---[启动]---循环_loop_thread 线程 | 线程名: {threading.current_thread().name}")
        driver_session.status_event.change(config_id=driver_session.config_data.id, status=DriverSessionStatus.RUNNING)

        while True:
            try:
                # 0.判断是否需要停止
                if driver_session.loop_thread_stop_event.is_set():
                    break

                # 1.判断浏览器对象是否存活
                if not is_driver_alive(driver_session.driver):
                    driver_session.driver = None

                # 2.创建浏览器对象
                if driver_session.driver is None:
                    driver_session.driver = create_webdriver_by_config_data(driver_session.config_data)
                    
                # 3.创建脚本实例
                if driver_session.script_instance is None:
                    script_config = get_script_config_by_id(driver_session.config_data.script_id)
                    if script_config is None:
                        logger.error(f" 脚本配置不存在: {driver_session.config_data.script_id}")
                        break
                    module = importlib.import_module(script_config.path)
                    driver_session.script_instance = getattr(module, "return_script_instance")(driver_session)

                # 执行脚本
                driver_session.script_instance.run(driver_session)
                driver_session.loop_thread_stop_event.wait(1)
            except Exception as e:
                try:
                    logger.error(f" 循环_loop_thread 线程失败: {e} traceback: {traceback.format_exc()}")
                    driver_session.status_event.change(config_id=driver_session.config_data.id, status=DriverSessionStatus.STOPPED)
                    if driver_session.script_instance:
                        driver_session.script_instance.notify_event(NotifyType.ABNORMAL_EXIT)
                    else:
                        logger.error(f" 循环_loop_thread 线程失败: 初始化脚本出错")
                except Exception as e:
                    pass
                break
        
        
        logger.info(f" ---[结束]---循环_loop_thread 线程 | 线程名: {threading.current_thread().name}")