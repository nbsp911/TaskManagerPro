

from dataclasses import dataclass, field, asdict
from typing import Dict, Optional
from enum import Enum
import uuid
from PySide6.QtGui import QColor
from datetime import datetime

# 代理状态
class ProxyStatus(Enum):
    RUNNING = "running"
    STOPPED = "stopped"

# 代理测速状态
class ProxyTestStatus(Enum):
    TESTING = "testing"
    TESTED = "tested"
    FAILED = "failed"
    TIMEOUT = "timeout"


# 驱动会话状态
class DriverSessionStatus(Enum):
    IDLE = "idle"
    RUNNING = "running"
    STOPPING = "stopping"
    STOPPED = "stopped"

# 枚举值到中文映射
DRIVER_SESSION_STATUS_LABELS: dict[DriverSessionStatus, str] = {
    DriverSessionStatus.IDLE: "待启动",
    DriverSessionStatus.RUNNING: "运行中",
    DriverSessionStatus.STOPPING: "停止中",
    DriverSessionStatus.STOPPED: "已停止",
}

DRIVER_SESSION_STATUS_COLORS: dict[DriverSessionStatus, QColor] = {
    DriverSessionStatus.IDLE: QColor(154, 160, 166),
    DriverSessionStatus.RUNNING: QColor(40, 167, 69),
    DriverSessionStatus.STOPPING: QColor(220, 53, 69),
    DriverSessionStatus.STOPPED: QColor(255, 159, 67),
}


class TradeAction(Enum):
    NOT_TIP_DIALOG = "not_tip_dialog"
    YES_TIP_DIALOG = "yes_tip_dialog"
    VERIFIED = "verified"
    

class NotifyType(Enum):
    NETWORK = "network" # 网络异常
    LOGIN = "login" # 登录失效
    NO_MONEY = "no_money" # 余额不足
    HUMAN_VERIFICATION = "human_verification" # 人工验证
    TRADE_COMPLETED = "trade_completed" # 交易完成
    ABNORMAL_EXIT = "abnormal_exit" # 异常退出
    ORDER_ACCUMULATED = "order_accumulated" # 订单累积
    NO_GOOGLE_AUTH = "no_google_auth" # 没有谷歌认证

@dataclass
class EmailJsonConfig:
    email: str
    password: str
    server: str
    port: int
    use_ssl: bool
    enabled: bool
    last_used: Optional[str] = None
    send_count: int = 0
    error_count: int = 0


@dataclass
class ConfigData:
    id: str
    name: str
    script_id: Optional[str] = None
    script_path: Optional[str] = None
    browser: str = "auto"
    headless: bool = False
    proxy_id: Optional[str] = None
    group: Optional[str] = None
    country_index: Optional[int] = None
    user_agent: Optional[str] = None
    extra_args: Dict[str, str] = field(default_factory=dict)



@dataclass
class ScriptConfig:
    id: str
    name: str
    path: str
    dynamic_property: Dict[str, str] = field(default_factory=dict)



@dataclass
class ProxyConfig:
    id: str
    name: str
    type: str
    server: str
    port: int
    username: Optional[str] = None
    password: Optional[str] = None
    raw: Optional[str] = None
    # 实例配置字段
    listen_host: str = "127.0.0.1"
    listen_port: Optional[int] = None
    timeout: int = 30
    max_connections: int = 100
    enabled: bool = True
    port_forward: bool = True  # 是否启用端口转发，默认为True

    @property
    def requests_proxy(self) -> Dict[str, str]:
        scheme = self.type.lower()
        auth = ""
        if self.username and self.password:
            auth = f"{self.username}:{self.password}@"
        elif self.username and not self.password:
            auth = f"{self.username}@"

        # 对于SOCKS5代理，需要使用socks5h协议来支持域名解析
        if scheme == 'socks5':
            scheme = 'socks5h'

        proxy_uri = f"{scheme}://{auth}{self.server}:{self.port}"
        return {
            "http": proxy_uri,
            "https": proxy_uri,
        }
    
    @property
    def listen_addr(self) -> str:
        """获取监听地址"""
        if self.listen_port:
            return f"{self.listen_host}:{self.listen_port}"
        return f"{self.listen_host}:0"  # 0 表示自动分配端口

    def to_dict(self) -> Dict:
        data = asdict(self)
        return data

    @classmethod
    def from_dict(cls, data: Dict) -> "ProxyConfig":
        return cls(
            id=data.get("id", str(uuid.uuid4())),
            name=data.get("name", "未命名节点"),
            type=data.get("type", "http"),
            server=data.get("server", ""),
            port=int(data.get("port", 0)),
            username=data.get("username"),
            password=data.get("password"),
            raw=data.get("raw"),
            # 实例配置字段
            listen_host=data.get("listen_host", "127.0.0.1"),
            listen_port=data.get("listen_port"),
            timeout=int(data.get("timeout", 30)),
            max_connections=int(data.get("max_connections", 100)),
            enabled=bool(data.get("enabled", True)),
            port_forward=bool(data.get("port_forward", True)),  # 默认启用端口转发
        )
