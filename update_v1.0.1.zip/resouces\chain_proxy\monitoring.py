"""
Monitoring - 监控系统
包括线程监控、性能统计、状态报告
"""

import threading
import time
import psutil
import logging
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, field
from enum import Enum
import json
import os
from pathlib import Path

logger = logging.getLogger()


class MonitorLevel(Enum):
    """监控级别"""
    BASIC = "basic"
    DETAILED = "detailed"
    DEBUG = "debug"


@dataclass
class ThreadInfo:
    """线程信息"""
    thread_id: int
    thread_name: str
    is_alive: bool
    daemon: bool
    start_time: float
    cpu_percent: float = 0.0
    memory_mb: float = 0.0


@dataclass
class SystemStats:
    """系统统计"""
    timestamp: float
    cpu_percent: float
    memory_percent: float
    memory_available_mb: float
    disk_usage_percent: float
    network_sent_mb: float
    network_recv_mb: float
    active_threads: int
    active_connections: int


@dataclass
class ProxyStats:
    """代理统计"""
    proxy_id: str
    status: str
    connections: int
    bytes_sent: int
    bytes_received: int
    uptime: float
    last_activity: float
    error_count: int
    success_rate: float


class ThreadMonitor:
    """线程监控器"""
    
    def __init__(self):
        self.threads: Dict[int, ThreadInfo] = {}
        self._lock = threading.RLock()
        self._monitoring = False
        self._monitor_thread = None
        self._monitor_interval = 5.0  # 监控间隔（秒）
    
    def start_monitoring(self, interval: float = 5.0):
        """开始监控"""
        if self._monitoring:
            return
        
        self._monitor_interval = interval
        self._monitoring = True
        self._monitor_thread = threading.Thread(
            target=self._monitor_loop,
            name="ThreadMonitor",
            daemon=True
        )
        self._monitor_thread.start()
        logger.info("线程监控已启动")
    
    def stop_monitoring(self):
        """停止监控"""
        if not self._monitoring:
            return
        
        self._monitoring = False
        if self._monitor_thread:
            self._monitor_thread.join(timeout=2.0)
        logger.info("线程监控已停止")
    
    def _monitor_loop(self):
        """监控循环"""
        while self._monitoring:
            try:
                self._update_thread_info()
                time.sleep(self._monitor_interval)
            except Exception as e:
                logger.error(f"线程监控异常: {e}")
                time.sleep(1.0)
    
    def _update_thread_info(self):
        """更新线程信息"""
        with self._lock:
            current_threads = {}
            
            for thread in threading.enumerate():
                thread_id = thread.ident
                if thread_id:
                    # 获取线程信息
                    try:
                        # 获取进程信息
                        process = psutil.Process()
                        thread_cpu = 0.0
                        thread_memory = 0.0
                        
                        # 尝试获取线程级别的CPU和内存使用
                        try:
                            thread_info = process.threads()
                            for t in thread_info:
                                if t.id == thread_id:
                                    thread_cpu = t.cpu_percent or 0.0
                                    thread_memory = t.memory_info().rss / 1024 / 1024  # MB
                                    break
                        except:
                            pass
                        
                        thread_info = ThreadInfo(
                            thread_id=thread_id,
                            thread_name=thread.name,
                            is_alive=thread.is_alive(),
                            daemon=thread.daemon,
                            start_time=getattr(thread, '_start_time', time.time()),
                            cpu_percent=thread_cpu,
                            memory_mb=thread_memory
                        )
                        
                        current_threads[thread_id] = thread_info
                    except Exception as e:
                        logger.debug(f"获取线程信息失败: {e}")
            
            self.threads = current_threads
    
    def get_thread_info(self, thread_id: Optional[int] = None) -> Optional[ThreadInfo]:
        """获取线程信息"""
        with self._lock:
            if thread_id:
                return self.threads.get(thread_id)
            return None
    
    def get_all_threads(self) -> Dict[int, ThreadInfo]:
        """获取所有线程信息"""
        with self._lock:
            return self.threads.copy()
    
    def get_thread_stats(self) -> Dict[str, Any]:
        """获取线程统计"""
        with self._lock:
            total_threads = len(self.threads)
            alive_threads = sum(1 for t in self.threads.values() if t.is_alive())
            daemon_threads = sum(1 for t in self.threads.values() if t.daemon)
            
            total_cpu = sum(t.cpu_percent for t in self.threads.values())
            total_memory = sum(t.memory_mb for t in self.threads.values())
            
            return {
                "total_threads": total_threads,
                "alive_threads": alive_threads,
                "daemon_threads": daemon_threads,
                "total_cpu_percent": total_cpu,
                "total_memory_mb": total_memory,
                "avg_cpu_percent": total_cpu / total_threads if total_threads > 0 else 0,
                "avg_memory_mb": total_memory / total_threads if total_threads > 0 else 0
            }


class SystemMonitor:
    """系统监控器"""
    
    def __init__(self):
        self.stats_history: List[SystemStats] = []
        self._lock = threading.RLock()
        self._monitoring = False
        self._monitor_thread = None
        self._monitor_interval = 10.0  # 监控间隔（秒）
        self._max_history = 100  # 最大历史记录数
        
        # 网络统计基准
        self._network_sent_base = 0
        self._network_recv_base = 0
        self._last_network_time = time.time()
    
    def start_monitoring(self, interval: float = 10.0):
        """开始监控"""
        if self._monitoring:
            return
        
        self._monitor_interval = interval
        self._monitoring = True
        
        # 初始化网络统计基准
        self._init_network_baseline()
        
        self._monitor_thread = threading.Thread(
            target=self._monitor_loop,
            name="SystemMonitor",
            daemon=True
        )
        self._monitor_thread.start()
        logger.info("系统监控已启动")
    
    def stop_monitoring(self):
        """停止监控"""
        if not self._monitoring:
            return
        
        self._monitoring = False
        if self._monitor_thread:
            self._monitor_thread.join(timeout=2.0)
        logger.info("系统监控已停止")
    
    def _init_network_baseline(self):
        """初始化网络统计基准"""
        try:
            net_io = psutil.net_io_counters()
            self._network_sent_base = net_io.bytes_sent
            self._network_recv_base = net_io.bytes_recv
            self._last_network_time = time.time()
        except Exception as e:
            logger.debug(f"初始化网络统计基准失败: {e}")
    
    def _monitor_loop(self):
        """监控循环"""
        while self._monitoring:
            try:
                stats = self._collect_system_stats()
                self._add_stats(stats)
                time.sleep(self._monitor_interval)
            except Exception as e:
                logger.error(f"系统监控异常: {e}")
                time.sleep(1.0)
    
    def _collect_system_stats(self) -> SystemStats:
        """收集系统统计"""
        try:
            # CPU 使用率
            cpu_percent = psutil.cpu_percent(interval=1)
            
            # 内存使用率
            memory = psutil.virtual_memory()
            memory_percent = memory.percent
            memory_available_mb = memory.available / 1024 / 1024
            
            # 磁盘使用率
            disk = psutil.disk_usage('/')
            disk_usage_percent = disk.percent
            
            # 网络统计
            net_io = psutil.net_io_counters()
            current_time = time.time()
            time_diff = current_time - self._last_network_time
            
            if time_diff > 0:
                network_sent_mb = (net_io.bytes_sent - self._network_sent_base) / 1024 / 1024
                network_recv_mb = (net_io.bytes_recv - self._network_recv_base) / 1024 / 1024
                
                # 更新基准
                self._network_sent_base = net_io.bytes_sent
                self._network_recv_base = net_io.bytes_recv
                self._last_network_time = current_time
            else:
                network_sent_mb = 0
                network_recv_mb = 0
            
            # 线程统计
            active_threads = threading.active_count()
            
            return SystemStats(
                timestamp=time.time(),
                cpu_percent=cpu_percent,
                memory_percent=memory_percent,
                memory_available_mb=memory_available_mb,
                disk_usage_percent=disk_usage_percent,
                network_sent_mb=network_sent_mb,
                network_recv_mb=network_recv_mb,
                active_threads=active_threads,
                active_connections=0  # 这里可以添加连接统计
            )
            
        except Exception as e:
            logger.error(f"收集系统统计失败: {e}")
            return SystemStats(
                timestamp=time.time(),
                cpu_percent=0,
                memory_percent=0,
                memory_available_mb=0,
                disk_usage_percent=0,
                network_sent_mb=0,
                network_recv_mb=0,
                active_threads=0,
                active_connections=0
            )
    
    def _add_stats(self, stats: SystemStats):
        """添加统计记录"""
        with self._lock:
            self.stats_history.append(stats)
            
            # 限制历史记录数量
            if len(self.stats_history) > self._max_history:
                self.stats_history = self.stats_history[-self._max_history:]
    
    def get_current_stats(self) -> Optional[SystemStats]:
        """获取当前统计"""
        with self._lock:
            return self.stats_history[-1] if self.stats_history else None
    
    def get_stats_history(self, limit: Optional[int] = None) -> List[SystemStats]:
        """获取统计历史"""
        with self._lock:
            if limit:
                return self.stats_history[-limit:]
            return self.stats_history.copy()
    
    def get_stats_summary(self, hours: int = 1) -> Dict[str, Any]:
        """获取统计摘要"""
        cutoff_time = time.time() - (hours * 3600)
        
        with self._lock:
            recent_stats = [s for s in self.stats_history if s.timestamp > cutoff_time]
        
        if not recent_stats:
            return {}
        
        # 计算平均值
        avg_cpu = sum(s.cpu_percent for s in recent_stats) / len(recent_stats)
        avg_memory = sum(s.memory_percent for s in recent_stats) / len(recent_stats)
        avg_threads = sum(s.active_threads for s in recent_stats) / len(recent_stats)
        
        # 计算网络流量
        total_sent = sum(s.network_sent_mb for s in recent_stats)
        total_recv = sum(s.network_recv_mb for s in recent_stats)
        
        return {
            "period_hours": hours,
            "sample_count": len(recent_stats),
            "avg_cpu_percent": round(avg_cpu, 2),
            "avg_memory_percent": round(avg_memory, 2),
            "avg_active_threads": round(avg_threads, 1),
            "total_network_sent_mb": round(total_sent, 2),
            "total_network_recv_mb": round(total_recv, 2),
            "current_cpu": recent_stats[-1].cpu_percent if recent_stats else 0,
            "current_memory": recent_stats[-1].memory_percent if recent_stats else 0
        }


class ProxyMonitor:
    """代理监控器"""
    
    def __init__(self):
        self.proxy_stats: Dict[str, ProxyStats] = {}
        self._lock = threading.RLock()
        self._monitoring = False
        self._monitor_thread = None
        self._monitor_interval = 5.0
    
    def start_monitoring(self, interval: float = 5.0):
        """开始监控"""
        if self._monitoring:
            return
        
        self._monitor_interval = interval
        self._monitoring = True
        self._monitor_thread = threading.Thread(
            target=self._monitor_loop,
            name="ProxyMonitor",
            daemon=True
        )
        self._monitor_thread.start()
        logger.info("代理监控已启动")
    
    def stop_monitoring(self):
        """停止监控"""
        if not self._monitoring:
            return
        
        self._monitoring = False
        if self._monitor_thread:
            self._monitor_thread.join(timeout=2.0)
        logger.info("代理监控已停止")
    
    def _monitor_loop(self):
        """监控循环"""
        while self._monitoring:
            try:
                self._update_proxy_stats()
                time.sleep(self._monitor_interval)
            except Exception as e:
                logger.error(f"代理监控异常: {e}")
                time.sleep(1.0)
    
    def _update_proxy_stats(self):
        """更新代理统计"""
        # 这里需要与 ChainProxyManager 集成
        # 暂时使用模拟数据
        pass
    
    def update_proxy_stats(self, proxy_id: str, stats: Dict[str, Any]):
        """更新代理统计"""
        with self._lock:
            self.proxy_stats[proxy_id] = ProxyStats(
                proxy_id=proxy_id,
                status=stats.get("status", "unknown"),
                connections=stats.get("connections", 0),
                bytes_sent=stats.get("bytes_sent", 0),
                bytes_received=stats.get("bytes_received", 0),
                uptime=stats.get("uptime", 0),
                last_activity=stats.get("last_activity", time.time()),
                error_count=stats.get("error_count", 0),
                success_rate=stats.get("success_rate", 0.0)
            )
    
    def get_proxy_stats(self, proxy_id: str) -> Optional[ProxyStats]:
        """获取代理统计"""
        with self._lock:
            return self.proxy_stats.get(proxy_id)
    
    def get_all_proxy_stats(self) -> Dict[str, ProxyStats]:
        """获取所有代理统计"""
        with self._lock:
            return self.proxy_stats.copy()
    
    def get_proxy_summary(self) -> Dict[str, Any]:
        """获取代理摘要"""
        with self._lock:
            if not self.proxy_stats:
                return {}
            
            total_proxies = len(self.proxy_stats)
            running_proxies = sum(1 for s in self.proxy_stats.values() if s.status == "running")
            total_connections = sum(s.connections for s in self.proxy_stats.values())
            total_bytes_sent = sum(s.bytes_sent for s in self.proxy_stats.values())
            total_bytes_received = sum(s.bytes_received for s in self.proxy_stats.values())
            
            return {
                "total_proxies": total_proxies,
                "running_proxies": running_proxies,
                "stopped_proxies": total_proxies - running_proxies,
                "total_connections": total_connections,
                "total_bytes_sent": total_bytes_sent,
                "total_bytes_received": total_bytes_received,
                "avg_connections_per_proxy": total_connections / total_proxies if total_proxies > 0 else 0
            }


class MonitoringSystem:
    """监控系统"""
    
    def __init__(self, persistence_file: str = "tmp/monitoring.json"):
        self.persistence_file = persistence_file
        self.thread_monitor = ThreadMonitor()
        self.system_monitor = SystemMonitor()
        self.proxy_monitor = ProxyMonitor()
        self._monitoring = False
        self._lock = threading.RLock()
        
        # 监控回调
        self.monitor_callbacks: List[Callable] = []
    
    def start_monitoring(self, 
                        thread_interval: float = 5.0,
                        system_interval: float = 10.0,
                        proxy_interval: float = 5.0):
        """开始监控"""
        with self._lock:
            if self._monitoring:
                return
            
            self.thread_monitor.start_monitoring(thread_interval)
            self.system_monitor.start_monitoring(system_interval)
            self.proxy_monitor.start_monitoring(proxy_interval)
            
            self._monitoring = True
            logger.info("监控系统已启动")
    
    def stop_monitoring(self):
        """停止监控"""
        with self._lock:
            if not self._monitoring:
                return
            
            self.thread_monitor.stop_monitoring()
            self.system_monitor.stop_monitoring()
            self.proxy_monitor.stop_monitoring()
            
            self._monitoring = False
            logger.info("监控系统已停止")
    
    def get_comprehensive_report(self) -> Dict[str, Any]:
        """获取综合报告"""
        with self._lock:
            return {
                "timestamp": time.time(),
                "monitoring_active": self._monitoring,
                "thread_stats": self.thread_monitor.get_thread_stats(),
                "system_stats": self.system_monitor.get_current_stats(),
                "system_summary": self.system_monitor.get_stats_summary(1),
                "proxy_summary": self.proxy_monitor.get_proxy_summary(),
                "proxy_stats": self.proxy_monitor.get_all_proxy_stats()
            }
    
    def export_monitoring_data(self, filename: str):
        """导出监控数据"""
        report = self.get_comprehensive_report()
        
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(report, f, indent=2, ensure_ascii=False, default=str)
    
    def add_monitor_callback(self, callback: Callable[[Dict[str, Any]], None]):
        """添加监控回调"""
        self.monitor_callbacks.append(callback)
    
    def remove_monitor_callback(self, callback: Callable[[Dict[str, Any]], None]):
        """移除监控回调"""
        if callback in self.monitor_callbacks:
            self.monitor_callbacks.remove(callback)
    
    def __del__(self):
        """析构函数"""
        try:
            self.stop_monitoring()
        except:
            pass
