from pathlib import Path
from typing import Optional

from urllib.parse import urlparse
from selenium import webdriver

from selenium.webdriver import Chrome, Edge, Firefox
from selenium.webdriver.chrome.options import Options as ChromeOptions
from selenium.webdriver.edge.options import Options as EdgeOptions
from selenium.webdriver.firefox.options import Options as FirefoxOptions

from chain_proxy.chain_proxy_manager import get_chain_proxy_manager

from data_type import ConfigData
from datas import get_country_by_idx

import logging
logger = logging.getLogger()

cache_root = Path.cwd() / "tmp" / "cache"
cache_root.mkdir(parents=True, exist_ok=True)

def _force_window_size_chromium(driver, width: int, height: int, x: int = 0, y: int = 0) -> None:
    """Use Chrome DevTools Protocol to normalize window state and force size.

    This helps override remembered maximized/fullscreen states from user-data-dir.
    """
    try:
        info = driver.execute_cdp_cmd("Browser.getWindowForTarget", {})
        window_id = info.get("windowId") if isinstance(info, dict) else None
        if window_id:
            # Step 1: ensure normal state
            try:
                driver.execute_cdp_cmd(
                    "Browser.setWindowBounds",
                    {"windowId": window_id, "bounds": {"windowState": "normal"}},
                )
            except Exception:
                pass
            # Step 2: set exact bounds
            try:
                driver.execute_cdp_cmd(
                    "Browser.setWindowBounds",
                    {
                        "windowId": window_id,
                        "bounds": {"left": int(x), "top": int(y), "width": int(width), "height": int(height)},
                    },
                )
            except Exception:
                pass
    except Exception:
        pass

def _apply_proxy(options, browser: str, proxy: Optional[urlparse]) -> None:
    if proxy is None:
        return
    host = proxy.hostname
    port = proxy.port
    scheme = (proxy.scheme or "http").lower()

    if browser in {"chrome", "edge"}:
        proxy_arg = f"--proxy-server={scheme}://{host}:{port}" if port else f"--proxy-server={scheme}://{host}"
        options.add_argument(proxy_arg)
    elif browser == "firefox":
        if port is None:
            raise ValueError("Firefox 代理需要指定端口，例如 host:port")
        options.set_preference("network.proxy.type", 1)
        if scheme.startswith("socks"):
            options.set_preference("network.proxy.socks", host)
            options.set_preference("network.proxy.socks_port", port)
        else:
            options.set_preference("network.proxy.http", host)
            options.set_preference("network.proxy.http_port", port)
            options.set_preference("network.proxy.ssl", host)
            options.set_preference("network.proxy.ssl_port", port)
        options.set_preference("network.proxy.no_proxies_on", "")

def create_webdriver_by_config_data(config_data: ConfigData) -> webdriver.Remote:
    browser_name = config_data.browser.strip().lower()
    headless = config_data.headless
    config_id = config_data.id

    
    cache_identifier = config_id or browser_name
    cache_dir = cache_root / browser_name / cache_identifier
    cache_dir.mkdir(parents=True, exist_ok=True)


    driver = None
    if browser_name == "chrome":
        options = ChromeOptions()
        if headless:
            options.add_argument("--headless=new")
        options.add_argument(f"--user-data-dir={cache_dir}")

        # 设置 chrome 基础参数
        _set_chrome_base_params(options)

        # 设置 user_agent
        if config_data.user_agent:
            options.add_argument("--user-agent=" + config_data.user_agent)

        # 设置语言
        country = get_country_by_idx(config_data.country_index)
        if country:
            try:
                options.add_experimental_option("prefs", {"intl.accept_languages": country.get("lang_list")})
                options.add_argument(f'--timezone={country.get("timezone")}')
                # 取country.lang_list里的第一个逗号前的内容
                lang_code = country.get("lang_list").split(',')[0] if ',' in country.get("lang_list") else country.get("lang_list")
                options.add_argument("--lang=" + lang_code)
            except Exception as e:
                logger.warning(f" 设置时区失败: country_index: {config_data.country_index}, error: {e}")
        
        # 设置代理
        if config_data.proxy_id and config_data.proxy_id != "":
            try:
                chain_proxy_manager = get_chain_proxy_manager()
                parsed_proxy = chain_proxy_manager.get_proxy_addr(config_data.proxy_id)
                if parsed_proxy:
                    proxy_arg = f"--proxy-server={parsed_proxy}"
                    options.add_argument(proxy_arg)
            except Exception as e:
                logger.warning(f" 设置代理失败: proxy_id: {config_data.proxy_id}, error: {e}")

        driver = Chrome(options=options)

        # 设置时区
        if country:
            try:
                driver.execute_cdp_cmd('Emulation.setTimezoneOverride', {'timezoneId': country.get("timezone")})
            except Exception as e:
                logger.warning(f" 设置时区失败: country_index: {config_data.country_index}, error: {e}")

        # 设置 execute_cdp_cmd
        _set_chrome_execute_cdp_cmd(driver)
        
        #_force_window_size_chromium(driver, 1440, 1080, 0, 0)
        # 设置最大化
        try:
            driver.maximize_window()
        except Exception:
            pass

    elif browser_name == "edge":
        options = EdgeOptions()
        if headless:
            options.add_argument("--headless=new")
            options.add_argument("--disable-gpu")
        options.add_argument(f"--user-data-dir={cache_dir}")
        options.add_argument(f"--profile-directory={cache_dir}")
        options.add_argument(f"--debugging-port=0")
        _apply_proxy(options, "edge", parsed_proxy)
        driver = Edge(options=options)
        _force_window_size_chromium(driver, 1440, 1080, 0, 0)
    elif browser_name == "firefox":
        options = FirefoxOptions()
        if headless:
            options.add_argument("--headless")
        options.set_preference("browser.cache.disk.enable", True)
        options.set_preference("browser.cache.memory.enable", True)
        options.set_preference("browser.cache.offline.enable", True)
        options.set_preference("browser.tabs.loadInBackground", False)
        profile_dir = cache_dir
        options.set_preference("profile", str(profile_dir))
        _apply_proxy(options, "firefox", parsed_proxy)
        driver = Firefox(options=options)
        try:
            driver.set_window_position(0, 0)
            driver.set_window_size(1440, 1080)
        except Exception:
            pass
    else:
        raise ValueError(f"不支持的浏览器类型: {browser_name}")

    return driver

# 设置chrome基础参数
def _set_chrome_base_params(options):
    # ========== 基础浏览器稳定性与隔离参数 ==========
    # 会话及多开用户隔离（一般由调用者 --user-data-dir 控制，这里仅必要项）
    #options.add_argument("--no-sandbox")                         # 启用沙盒隔离，增加安全性
    options.add_argument("--disable-web-security")               # 关闭跨域安全（如需跨域自动化）
    options.add_argument("--disable-features=VizDisplayCompositor")  # 关闭Viz（减少显卡依赖）

    # ========== 禁用后台与节能策略 ==========
    options.add_argument("--disable-background-timer-throttling")        # 禁用后台定时器节流
    options.add_argument("--disable-backgrounding-occluded-windows")     # 禁用后台窗口暂停
    options.add_argument("--disable-renderer-backgrounding")             # 禁用渲染进程后台优化

    # ========== 禁用隐私及同步相关功能 ==========
    options.add_argument("--disable-geolocation")                # 禁用地理位置访问
    options.add_argument("--disable-notifications")              # 禁用网页通知
    options.add_argument("--no-first-run")                       # 跳过首次运行体验
    options.add_argument("--skip-first-run-ui")                  # 跳过首启UI
    options.add_argument("--disable-sync")                       # 禁用账号同步

    # ========== 屏蔽自动化检测特征 ==========
    options.add_experimental_option("excludeSwitches", ["enable-automation"])  # 屏蔽自动化特征
    options.add_experimental_option("useAutomationExtension", False)           # 移除自动化扩展
    options.add_argument("--disable-blink-features=AutomationControlled")      # 去除Automation特性标签

    # ========== 禁用插件、扩展、默认应用等 ==========
    #options.add_argument("--disable-extensions")                 # 禁用所有扩展
    options.add_argument("--disable-default-apps")               # 关闭默认内置App
    options.add_argument("--disable-popup-blocking")             # 禁用弹窗拦截，部分场景下更兼容
    options.add_argument("--no-default-browser-check")           # 不检查默认浏览器
    options.add_argument("--disable-component-extensions-with-background-pages")  # 关闭后台扩展页         

    # ========== 降低/避免指纹唯一性特征（部分反爬利器） ==========
    options.add_argument("--disable-webgl")                      # 禁用 WebGL（减少指纹采集面）
    options.add_argument("--disable-webgl2")
    options.add_argument("--disable-gpu")                        # 禁用GPU渲染，降低Canvas指纹一致性

    # ========== 调试端口与启动优化 ==========
    options.add_argument("--debugging-port=0")                   # 禁用默认debug端口，避免被检测


# 设置 chrome 的 cdp
def _set_chrome_execute_cdp_cmd(driver, appVersion=None, cpu_core=16):
    # 多个cpu核心数的列表（每个子列表包含不同的cpu线程数）
    # cpu_cores_options = [8,12,16,20,24,28,32,40,48]
    # cpu_cores = random.choice(cpu_cores_options)
    try:
        if driver is not None:

            appVersion_cmd = ""
            if appVersion:
                # Remove leading 'Mozilla/' and any whitespace before or after
                if appVersion.startswith("Mozilla/"):
                    appVersion = appVersion[len("Mozilla/"):].lstrip()
                
                appVersion_cmd = f"""
                    Object.defineProperty(navigator, 'appVersion', {{
                        get: () => '{appVersion}'
                    }});
                """

            driver.execute_cdp_cmd(
                "Page.addScriptToEvaluateOnNewDocument",
                {
                    "source": f"""
                        Object.defineProperty(navigator, 'webdriver', {{
                            get: () => undefined
                        }});
                        {appVersion_cmd}
                        Object.defineProperty(navigator, 'hardwareConcurrency', {{
                            get: () => {cpu_core}
                        }});

                        // Hook WebGLRenderingContext.getExtension to log/mechanism for anti-fingerprinting
                        (function() {{
                            const original_getExtension = WebGLRenderingContext.prototype.getExtension;
                            WebGLRenderingContext.prototype.getExtension = function(...args) {{
                                try {{
                                    console.log('[WebGL-Hook] getExtension called:', args);
                                    return original_getExtension.apply(this, args);
                                }} catch (e) {{
                                    return original_getExtension.apply(this, args);
                                }}
                            }};
                        }})();

                    """
                }
            )
    except Exception as e:
        logger.warning(f" 浏览器指纹CDP注入失败: {e}")








# '''
#                         // Hook CanvasRenderingContext2D.measureText to log/mechanism for anti-fingerprinting
#                         (function() {{
#                             const original_measureText = CanvasRenderingContext2D.prototype.measureText;
#                             CanvasRenderingContext2D.prototype.measureText = function(...args) {{
#                                 try {{
#                                     // 可在这里做额外的反指纹逻辑、修改返回等，或仅仅是hook和日志
#                                     // console.log('[FontMeasure-Hook] measureText called:', args);
#                                     // 如需返回伪造宽度，参考如下：
#                                     // let metrics = original_measureText.apply(this, args);
#                                     // metrics.width = metrics.width + (Math.random() - 0.5) * 0.00001; // 或其他处理
#                                     // return metrics;
#                                     // 打印出所有的参数
#                                     console.log('[FontMeasure-Hook] measureText called:', args);
#                                     return original_measureText.apply(this, args);
#                                 }} catch (e) {{
#                                     return original_measureText.apply(this, args);
#                                 }}
#                             }};
#                         }})();

#                         // Hook document.fonts.check and log calls
#                         console.log('[FontCheck-Hook-Start]');
#                         if (typeof document.fonts !== 'undefined' && typeof document.fonts.check === 'function') {{
#                             const original_check = document.fonts.check.bind(document.fonts);
#                             document.fonts.check = function(...args) {{
#                                 try {{
#                                     console.log('[FontCheck-Hook] document.fonts.check called with args:', args);
#                                 }} catch (_e) {{}}
#                                 return original_check(...args);
#                             }};
#                         }}
                        

# '''

