

"""
集中存放全局少量共享变量。

仅保存一个变量：best_binance_alpha_token
提供线程安全的读写函数。
同时提供时区相关的工具函数。
"""

from typing import Optional
import threading
from datetime import datetime
try:
    from zoneinfo import ZoneInfo
except ImportError:
    # Python < 3.9 回退方案（如果需要）
    from backports.zoneinfo import ZoneInfo


_lock = threading.RLock()

# 最佳 Binance Alpha 代币（例如 "AOP" 或合约地址等），默认无
best_binance_alpha_token: Optional[str] = None


def set_best_binance_alpha_token(value: Optional[str]) -> None:
    """设置全局最佳代币（线程安全）。"""
    global best_binance_alpha_token
    with _lock:
        best_binance_alpha_token = value


def get_best_binance_alpha_token() -> Optional[str]:
    # return {"chainName": "bsc", "contractAddress": "0xd5df4d260d7a0145f655bcbf3b398076f21016c7", "symbol": "AOP", "mulPoint": 1, "tokenId": "1234567890"}
    """读取全局最佳代币（线程安全）。"""
    with _lock:
        return best_binance_alpha_token


# 时区配置：使用 Asia/Shanghai (UTC+8)
DEFAULT_TIMEZONE = ZoneInfo("Asia/Shanghai")


def get_now() -> datetime:
    """
    获取当前时间（时区感知，使用 Asia/Shanghai UTC+8）。
    替代 datetime.now()，确保所有时间都使用统一的时区。
    """
    return datetime.now(DEFAULT_TIMEZONE)


