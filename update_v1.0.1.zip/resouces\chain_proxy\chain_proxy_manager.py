"""
ChainProxyManager - 链式代理管理器
负责管理多个 UpstreamInstance 实例
"""

import asyncio, threading, logging, socket
from typing import Dict, List, Optional, Any
from concurrent.futures import ThreadPoolExecutor

from data_type import ProxyStatus, ProxyTestStatus
from file_oper import FileOper
from chain_proxy.upstream_instance import UpstreamInstance
from chain_proxy.speed_tester import SpeedTestManager
from chain_proxy.port_manager import PortManager
from chain_proxy.error_handler import ErrorHandler, ErrorLevel, ErrorCategory
from slot_events import ProxyManagerSignal

logger = logging.getLogger()


class ChainProxyManager:
    """链式代理管理器"""
    
    def __init__(self, max_workers: int = 10):
        self.max_workers = max_workers
        self.file_oper = FileOper()
        self.proxy_instances: Dict[str, UpstreamInstance] = {}
        self.instance_threads: Dict[str, threading.Thread] = {}
        self.port_allocations: Dict[str, int] = {}  # proxy_id -> port
        self._lock = threading.RLock()
        self.thread_pool = ThreadPoolExecutor(max_workers=max_workers)
        self._running = False
        
        # 测速管理器
        self.speed_tester = SpeedTestManager(max_concurrent=10, max_workers=5)
        
        # 端口管理器
        self.port_manager = PortManager(
            start_port=17717,
            end_port=18717,
            persistence_file="tmp/port_allocations.json"
        )
        
        # 错误处理器
        self.error_handler = ErrorHandler(
            max_records=1000,
            persistence_file="tmp/error_log.json"
        )
    def get_running_instances_count(self) -> int:
        """获取所有实例的数量"""
        return len(self.instance_threads)
        
    def _get_next_available_port(self) -> int:
        """获取下一个可用端口"""
        with self._lock:
            while self._next_port <= self.port_range_end:
                if self._is_port_available(self._next_port):
                    port = self._next_port
                    self._next_port += 1
                    return port
                self._next_port += 1
            
            # 如果范围内没有可用端口，尝试随机端口
            import random
            for _ in range(100):  # 最多尝试100次
                port = random.randint(1024, 65535)
                if self._is_port_available(port):
                    return port
            
            raise RuntimeError("无法找到可用端口")
    
    def _is_port_available(self, port: int) -> bool:
        """检查端口是否可用"""
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.bind(('127.0.0.1', port))
                return True
        except OSError:
            return False
    
    def add_proxy(self, proxy_id: str) -> bool:
        """添加代理实例"""
        with self._lock:
            if proxy_id in self.proxy_instances:
                logger.warning(f"代理实例已存在: {proxy_id}")
                return True
            
            try:
                # 获取代理配置
                proxy_config = self.file_oper.get_proxy_config_by_id(proxy_id)
                if not proxy_config:
                    logger.error(f"未找到代理配置: {proxy_id}")
                    return False
                
                # 分配端口
                listen_port = self.port_manager.get_port(proxy_id)
                if listen_port is None:
                    # 尝试使用配置中的端口
                    preferred_port = proxy_config.listen_port
                    listen_port = self.port_manager.allocate_port(proxy_id, preferred_port)
                    if listen_port is None:
                        logger.error(f"无法为代理 {proxy_id} 分配端口")
                        return False
                    
                    # 设置代理配置的监听端口
                    proxy_config.listen_port = listen_port
                    # 更新 FileOper 中的配置
                    self.file_oper.update_proxy_config(proxy_config)
                
                # 创建实例（实例会从 FileOper 获取配置）
                instance = UpstreamInstance(proxy_id)
                self.proxy_instances[proxy_id] = instance
                
                logger.info(f"已添加代理实例: {proxy_id}, 端口: {listen_port}")
                return True
                
            except Exception as e:
                logger.error(f"添加代理实例失败: {e}")
                self.error_handler.log_error(
                    f"添加代理实例失败: {proxy_id}",
                    ErrorLevel.ERROR,
                    ErrorCategory.PROXY,
                    e,
                    {"proxy_id": proxy_id}
                )
                return False
    
    def remove_proxy(self, proxy_id: str) -> bool:
        """移除代理实例"""
        with self._lock:
            if proxy_id not in self.proxy_instances:
                logger.warning(f"代理实例不存在: {proxy_id}")
                return True
            
            try:
                # 停止实例
                instance = self.proxy_instances[proxy_id]
                if instance.is_running():
                    self.stop_proxy(proxy_id)
                
                # 移除实例
                del self.proxy_instances[proxy_id]
                
                # 释放端口
                self.port_manager.release_port(proxy_id)
                
                logger.info(f"已移除代理实例: {proxy_id}")
                return True
                
            except Exception as e:
                logger.error(f"移除代理实例失败: {e}")
                return False
    
    def start_proxy(self, proxy_id: str) -> bool:
        """启动代理实例"""
        with self._lock:
            if proxy_id not in self.proxy_instances:
                logger.error(f"代理实例不存在: {proxy_id}")
                return False
            
            if proxy_id in self.instance_threads:
                logger.warning(f"代理实例已在运行: {proxy_id}")
                return True
            
            try:
                instance = self.proxy_instances[proxy_id]
                
                # 创建实例线程
                thread = threading.Thread(
                    target=self._run_instance,
                    args=(instance,),
                    name=f"ProxyInstance-{proxy_id}",
                    daemon=True
                )
                
                self.instance_threads[proxy_id] = thread
                thread.start()
                
                # 发送代理状态变化事件
                ProxyManagerSignal.proxy_status_changed.emit(proxy_id, ProxyStatus.RUNNING)
                
                logger.info(f"已启动代理实例: {proxy_id}")
                return True
                
            except Exception as e:
                logger.error(f"启动代理实例失败: {e}")
                return False
    
    def stop_proxy(self, proxy_id: str) -> bool:
        """停止代理实例"""
        with self._lock:
            if proxy_id not in self.instance_threads:
                logger.debug(f"代理实例线程不存在: {proxy_id}")
                return True
            
            try:
                # 停止实例
                instance = self.proxy_instances.get(proxy_id)
                if instance:
                    # 检查实例是否正在运行
                    is_running = instance.is_running()
                    logger.debug(f"代理实例 {proxy_id} 运行状态: {is_running}")
                    
                    if not is_running:
                        logger.debug(f"代理实例 {proxy_id} 未运行，直接清理")
                    else:
                        # 设置停止标志
                        instance._running = False
                        logger.debug(f"已设置停止标志: {proxy_id}")
                else:
                    logger.debug(f"代理实例 {proxy_id} 不存在，直接清理线程")
                
                # 等待线程结束
                thread = self.instance_threads[proxy_id]
                thread.join(timeout=5.0)
                
                if thread.is_alive():
                    logger.warning(f"代理实例线程未正常结束: {proxy_id}")
                else:
                    logger.debug(f"代理实例线程正常结束: {proxy_id}")
                
                del self.instance_threads[proxy_id]
                
                # 发送代理状态变化事件
                ProxyManagerSignal.proxy_status_changed.emit(proxy_id, ProxyStatus.STOPPED)
                
                logger.info(f"已停止代理实例: {proxy_id}")
                return True
                
            except Exception as e:
                logger.error(f"停止代理实例失败: {e}")
                return False
    
    def _run_instance(self, instance: UpstreamInstance):
        """在独立线程中运行实例"""
        loop = None
        try:
            # 创建新的事件循环
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            
            # 运行实例
            loop.run_until_complete(instance.start())
            
            # 持续运行直到实例停止
            while instance.is_running():
                try:
                    loop.run_until_complete(asyncio.sleep(0.1))
                except Exception as e:
                    logger.debug(f"实例 {instance.proxy_id} 循环异常: {e}")
                    break
            
            # 停止实例
            try:
                loop.run_until_complete(instance.stop())
            except Exception as e:
                logger.debug(f"停止实例异常: {e}")
            
        except Exception as e:
            logger.error(f"实例 {instance.proxy_id} 运行异常: {e}")
        finally:
            try:
                if loop and not loop.is_closed():
                    # 取消所有剩余任务
                    try:
                        pending = asyncio.all_tasks(loop)
                        for task in pending:
                            task.cancel()
                        if pending:
                            loop.run_until_complete(asyncio.gather(*pending, return_exceptions=True))
                    except Exception as e:
                        logger.debug(f"清理任务异常: {e}")
                    
                    loop.close()
            except Exception as e:
                logger.debug(f"关闭事件循环异常: {e}")
    
    def start_all(self) -> bool:
        """启动所有启用的代理实例"""
        with self._lock:
            try:
                success_count = 0
                enabled_count = 0
                
                for proxy_id in self.proxy_instances:
                    # 检查代理是否启用
                    proxy_config = self.file_oper.get_proxy_config_by_id(proxy_id)
                    if proxy_config and proxy_config.enabled:
                        enabled_count += 1
                        if self.start_proxy(proxy_id):
                            success_count += 1
                    else:
                        logger.info(f"跳过已禁用的代理: {proxy_id}")
                
                logger.info(f"已启动 {success_count}/{enabled_count} 个启用的代理实例（共 {len(self.proxy_instances)} 个代理）")
                return success_count > 0
                
            except Exception as e:
                logger.error(f"启动所有代理实例失败: {e}")
                return False
    
    def stop_all(self) -> bool:
        """停止所有代理实例"""
        with self._lock:
            try:
                success_count = 0
                failed_count = 0
                
                # 获取所有代理ID的副本
                proxy_ids = list(self.instance_threads.keys())
                logger.info(f"开始停止 {len(proxy_ids)} 个代理实例")
                
                for proxy_id in proxy_ids:
                    try:
                        if self.stop_proxy(proxy_id):
                            success_count += 1
                        else:
                            failed_count += 1
                    except Exception as e:
                        logger.error(f"停止代理实例 {proxy_id} 失败: {e}")
                        failed_count += 1
                
                logger.info(f"停止完成: 成功 {success_count} 个, 失败 {failed_count} 个")
                return failed_count == 0
                
            except Exception as e:
                logger.error(f"停止所有代理实例失败: {e}")
                return False
    
    def test_speed(self, proxy_id: str = None, test_url: str = "https://httpbin.org/ip") -> Dict[str, Any]:
        """测试代理速度"""
        if proxy_id:
            # 测试指定代理
            if proxy_id not in self.proxy_instances:
                logger.error(f"代理实例不存在: {proxy_id}")
                return {"success": False, "error": f"代理实例不存在: {proxy_id}"}
            
            # 获取代理配置
            proxy_config = self.file_oper.get_proxy_config_by_id(proxy_id)
            if not proxy_config:
                logger.error(f"代理配置不存在: {proxy_id}")
                return {"success": False, "error": f"代理配置不存在: {proxy_id}"}
            
            logger.info(f"开始测速代理: {proxy_id}")
            
            # 发送TESTING状态事件
            ProxyManagerSignal.proxy_latency_tested.emit(proxy_id, -1.0, ProxyStatus.RUNNING, ProxyTestStatus.TESTING, "")
            
            # 执行同步测速
            result = self.speed_tester.test_proxy_sync(proxy_config, test_url)
            logger.info(f"测速结果: {proxy_id} - 成功: {result.success}, 响应时间: {result.response_time}")
            
            # 发送代理延迟测速事件
            if result.success:
                test_status = ProxyTestStatus.TESTED
                latency_value = result.response_time * 1000  # 转换为毫秒
                response_content = result.response_content or ""
            else:
                # 检查是否是超时错误
                if result.error and ("timeout" in result.error.lower() or "超时" in result.error):
                    test_status = ProxyTestStatus.TIMEOUT
                else:
                    test_status = ProxyTestStatus.FAILED
                latency_value = -1.0  # 使用-1表示失败，而不是None
                response_content = ""
            
            logger.info(f"发送测速事件: {proxy_id} - 状态: {test_status}, 延迟: {latency_value}")
            ProxyManagerSignal.proxy_latency_tested.emit(proxy_id, latency_value, ProxyStatus.RUNNING, test_status, response_content)
            
            return {
                "success": result.success,
                "response_time": result.response_time,
                "error": result.error,
                "timestamp": result.timestamp
            }
        else:
            # 测试所有代理
            results = {}
            for pid in self.proxy_instances.keys():
                proxy_config = self.file_oper.get_proxy_config_by_id(pid)
                if proxy_config:
                    # 发送TESTING状态事件
                    ProxyManagerSignal.proxy_latency_tested.emit(pid, -1.0, ProxyStatus.RUNNING, ProxyTestStatus.TESTING, "")
                    
                    result = self.speed_tester.test_proxy_sync(proxy_config, test_url)
                    
                    # 发送代理延迟测速事件
                    if result.success:
                        test_status = ProxyTestStatus.TESTED
                        latency_value = result.response_time * 1000  # 转换为毫秒
                        response_content = result.response_content or ""
                    else:
                        # 检查是否是超时错误
                        if result.error and ("timeout" in result.error.lower() or "超时" in result.error):
                            test_status = ProxyTestStatus.TIMEOUT
                        else:
                            test_status = ProxyTestStatus.FAILED
                        latency_value = -1.0  # 使用-1表示失败，而不是None
                        response_content = ""
                    
                    ProxyManagerSignal.proxy_latency_tested.emit(pid, latency_value, ProxyStatus.RUNNING, test_status, response_content)
                    
                    results[pid] = {
                        "success": result.success,
                        "response_time": result.response_time,
                        "error": result.error,
                        "timestamp": result.timestamp
                    }
            return results
    
    async def test_speed_async(self, proxy_id: str = None, test_url: str = "https://httpbin.org/ip") -> Dict[str, Any]:
        """异步测试代理速度"""
        if proxy_id:
            # 测试指定代理
            if proxy_id not in self.proxy_instances:
                return {"success": False, "error": f"代理实例不存在: {proxy_id}"}
            
            # 获取代理配置
            proxy_config = self.file_oper.get_proxy_config_by_id(proxy_id)
            if not proxy_config:
                return {"success": False, "error": f"代理配置不存在: {proxy_id}"}
            
            # 发送TESTING状态事件
            ProxyManagerSignal.proxy_latency_tested.emit(proxy_id, -1.0, ProxyStatus.RUNNING, ProxyTestStatus.TESTING, "")
            
            # 执行异步测速
            result = await self.speed_tester.test_proxy_async(proxy_config, test_url)
            
            # 发送代理延迟测速事件
            if result.success:
                test_status = ProxyTestStatus.TESTED
                latency_value = result.response_time * 1000  # 转换为毫秒
                response_content = result.response_content or ""
            else:
                # 检查是否是超时错误
                if result.error and ("timeout" in result.error.lower() or "超时" in result.error):
                    test_status = ProxyTestStatus.TIMEOUT
                else:
                    test_status = ProxyTestStatus.FAILED
                latency_value = -1.0  # 使用-1表示失败，而不是None
                response_content = ""
            
            ProxyManagerSignal.proxy_latency_tested.emit(proxy_id, latency_value, ProxyStatus.RUNNING, test_status, response_content)
            
            return {
                "success": result.success,
                "response_time": result.response_time,
                "error": result.error,
                "timestamp": result.timestamp
            }
        else:
            # 测试所有代理
            proxy_configs = []
            for pid in self.proxy_instances.keys():
                proxy_config = self.file_oper.get_proxy_config_by_id(pid)
                if proxy_config:
                    proxy_configs.append(proxy_config)
                    # 发送TESTING状态事件
                    ProxyManagerSignal.proxy_latency_tested.emit(pid, -1.0, ProxyStatus.RUNNING, ProxyTestStatus.TESTING, "")
            
            results = await self.speed_tester.test_proxies_async(proxy_configs, test_url)
            
            # 为每个结果发送代理延迟测速事件
            for result in results:
                if result.success:
                    test_status = ProxyTestStatus.TESTED
                    latency_value = result.response_time * 1000  # 转换为毫秒
                    response_content = result.response_content or ""
                else:
                    # 检查是否是超时错误
                    if result.error and ("timeout" in result.error.lower() or "超时" in result.error):
                        test_status = ProxyTestStatus.TIMEOUT
                    else:
                        test_status = ProxyTestStatus.FAILED
                    latency_value = -1.0  # 使用-1表示失败，而不是None
                    response_content = ""
                
                ProxyManagerSignal.proxy_latency_tested.emit(result.proxy_id, latency_value, ProxyStatus.RUNNING, test_status, response_content)
            
            return {
                result.proxy_id: {
                    "success": result.success,
                    "response_time": result.response_time,
                    "error": result.error,
                    "timestamp": result.timestamp
                }
                for result in results
            }
    
    def get_speed_stats(self, proxy_id: str = None) -> Dict[str, Any]:
        """获取测速统计"""
        if proxy_id:
            return self.speed_tester.get_proxy_stats(proxy_id)
        else:
            stats = {}
            for pid in self.proxy_instances.keys():
                stats[pid] = self.speed_tester.get_proxy_stats(pid)
            return stats
    
    def get_best_proxies(self, limit: int = 5) -> List[Dict[str, Any]]:
        """获取最佳代理"""
        best_results = self.speed_tester.get_best_proxies(limit)
        return [
            {
                "proxy_id": result.proxy_id,
                "response_time": result.response_time,
                "timestamp": result.timestamp,
                "test_url": result.test_url
            }
            for result in best_results
        ]
    
    def get_proxy_status(self, proxy_id: str) -> str:
        """获取代理状态"""
        if proxy_id in self.instance_threads:
            return "running"
        elif proxy_id in self.proxy_instances:
            return "stopped"
        else:
            return "not_found"
    
    def get_proxy_addr(self, proxy_id: str) -> str:
        """获取代理地址"""
        if proxy_id in self.proxy_instances:
            if self.proxy_instances.get(proxy_id):
                return self.proxy_instances.get(proxy_id).get_proxy_addr()
            else:
                return ""
        return ""
    
    def get_proxy_info(self, proxy_id: str) -> Dict[str, Any]:
        """获取代理信息"""
        if proxy_id in self.proxy_instances:
            instance = self.proxy_instances[proxy_id]
            return {
                "proxy_id": proxy_id,
                "status": self.get_proxy_status(proxy_id),
                "address": self.get_proxy_addr(proxy_id),
                "config": instance.get_config(),
                "stats": instance.get_stats()
            }
        return {}
    
    def load_all_proxies(self) -> bool:
        """从 FileOper 加载所有代理"""
        try:
            proxies = self.file_oper.get_proxys()
            success_count = 0
            
            for proxy in proxies:
                if self.add_proxy(proxy.id):
                    success_count += 1
            
            logger.info(f"已加载 {success_count}/{len(proxies)} 个代理")
            return success_count > 0
            
        except Exception as e:
            logger.error(f"加载所有代理失败: {e}")
            return False
    
    def get_all_proxies(self) -> List[Dict[str, Any]]:
        """获取所有代理信息"""
        with self._lock:
            return [self.get_proxy_info(proxy_id) for proxy_id in self.proxy_instances.keys()]
    
    def get_proxy_by_id(self, proxy_id: str) -> Optional[Dict[str, Any]]:
        """根据ID获取代理信息"""
        if proxy_id in self.proxy_instances:
            return self.get_proxy_info(proxy_id)
        return None
    
    def refresh_proxies(self) -> bool:
        """刷新代理配置"""
        try:
            # 重新加载所有代理
            self.stop_all()
            self.proxy_instances.clear()
            self.instance_threads.clear()
            self.port_allocations.clear()
            
            return self.load_all_proxies()
            
        except Exception as e:
            logger.error(f"刷新代理配置失败: {e}")
            return False
    
    def get_manager_stats(self) -> Dict[str, Any]:
        """获取管理器统计信息"""
        with self._lock:
            return {
                "total_proxies": len(self.proxy_instances),
                "running_proxies": len(self.instance_threads),
                "stopped_proxies": len(self.proxy_instances) - len(self.instance_threads),
                "port_allocations": self.port_manager.get_all_allocations(),
                "max_workers": self.max_workers,
                "port_stats": self.port_manager.get_port_stats()
            }
    
    def get_port_info(self, proxy_id: str) -> Optional[Dict[str, Any]]:
        """获取代理端口信息"""
        allocation = self.port_manager.get_allocation(proxy_id)
        if allocation:
            return {
                "proxy_id": allocation.proxy_id,
                "port": allocation.port,
                "host": allocation.host,
                "status": allocation.status,
                "allocated_time": allocation.allocated_time
            }
        return None
    
    def reserve_port(self, proxy_id: str, port: int, host: str = "127.0.0.1") -> bool:
        """预留端口"""
        return self.port_manager.reserve_port(proxy_id, port, host)
    
    def get_available_ports(self, count: int = 10) -> List[int]:
        """获取可用端口列表"""
        return self.port_manager.get_available_ports(count)
    
    def cleanup_ports(self):
        """清理端口分配"""
        self.port_manager.cleanup_released_ports()
    
    def remove_proxy_port_allocation(self, proxy_id: str) -> bool:
        """直接删除特定代理的端口分配记录"""
        return self.port_manager.remove_proxy_allocation(proxy_id)
    
    def export_port_allocations(self, filename: str):
        """导出端口分配记录"""
        self.port_manager.export_allocations(filename)
    
    def import_port_allocations(self, filename: str) -> bool:
        """导入端口分配记录"""
        return self.port_manager.import_allocations(filename)
    
    def get_errors(self, level=None, category=None, resolved=None, limit=None):
        """获取错误记录"""
        return self.error_handler.get_errors(level, category, resolved, limit)
    
    def get_error_stats(self):
        """获取错误统计"""
        return self.error_handler.get_error_stats()
    
    def resolve_error(self, error_id: str) -> bool:
        """标记错误为已解决"""
        return self.error_handler.resolve_error(error_id)
    
    def clear_errors(self, older_than_hours: int = None):
        """清理错误记录"""
        self.error_handler.clear_errors(older_than_hours)
    
    def export_errors(self, filename: str, level=None, category=None):
        """导出错误记录"""
        self.error_handler.export_errors(filename, level, category)
    
    def __del__(self):
        """析构函数"""
        try:
            self.stop_all()
            self.thread_pool.shutdown(wait=True)
        except:
            pass
    
    def __str__(self) -> str:
        return f"ChainProxyManager(proxies={len(self.proxy_instances)}, running={len(self.instance_threads)})"
    
    def __repr__(self) -> str:
        return self.__str__()



# 启动 ChainProxyManager（链式代理管理器）
_chain_proxy_manager = None
def init_chain_proxy_manager():
    """
    初始化 ChainProxyManager 实例（静态方法，适用于 task_tab.py 逻辑）
    便于主程序或外部工具初始化并启动代理管理器。
    """
    import threading

    global _chain_proxy_manager
    if _chain_proxy_manager is None:
        logger.info("正在初始化 Chain-Proxy 管理器...")
        _chain_proxy_manager = ChainProxyManager(max_workers=5)  # 可根据需要调整线程数

        def _init_chain_proxy():
            try:
                logger.info("开始加载代理配置...")
                success = _chain_proxy_manager.load_all_proxies()
                if success:
                    logger.info("代理配置加载成功")
                    # 启动所有代理
                    start_success = _chain_proxy_manager.start_all()
                    if start_success:
                        logger.info("Chain-Proxy 管理器启动成功")
                        all_proxies = _chain_proxy_manager.get_all_proxies()
                        logger.info(f"已启动 {len(all_proxies)} 个代理实例")
                        for proxy_info in all_proxies:
                            logger.info(f"  - {proxy_info['proxy_id']}: {proxy_info['status']} - {proxy_info['address']}")
                    else:
                        logger.error("Chain-Proxy 启动失败")
                else:
                    logger.error("代理配置加载失败")
            except Exception as e:
                logger.error(f"Chain-Proxy 初始化失败: {e}")
                import traceback
                logger.error(traceback.format_exc())
        threading.Thread(target=_init_chain_proxy, daemon=True, name="ChainProxyInit").start()
    else:
        logger.info("Chain-Proxy 管理器已存在")

def get_chain_proxy_manager():
    return _chain_proxy_manager