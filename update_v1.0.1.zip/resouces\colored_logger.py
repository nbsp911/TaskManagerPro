"""
简化版ANSI颜色日志系统
适用于现代终端环境，特别针对Win11优化
"""

import sys
import time
import logging
import os


class SimpleColoredFormatter(logging.Formatter):
    """简化的ANSI彩色格式化器"""
    
    # ANSI颜色代码映射
    LEVEL_COLORS = {
        'DEBUG': '\033[36m',      # 青色
        'INFO': '\033[32m',       # 绿色
        'WARNING': '\033[33m',    # 黄色
        'ERROR': '\033[31m',      # 红色
        'CRITICAL': '\033[35m',   # 紫色
    }
    
    RESET = '\033[0m'  # 重置颜色
    
    def format(self, record):
        """格式化日志记录，添加颜色"""
        # 获取基础消息
        message = super().format(record)

        # if record.name == "root":
        #     message = message.replace("root:", "").replace("root :", "")
        
        # 添加颜色
        color = self.LEVEL_COLORS.get(record.levelname, '')
        if color:
            return f"{color}{message}{self.RESET}"
        
        return message


class Win11ColoredFormatter(logging.Formatter):
    """专为Win11优化的彩色格式化器，支持更多样式"""
    
    # Win11完全支持的亮色系列
    COLORS = {
        'DEBUG': '\033[90m',      # 亮黑色（灰色）
        'INFO': '\033[92m',       # 亮绿色
        'WARNING': '\033[93m',    # 亮黄色
        'ERROR': '\033[91m',      # 亮红色
        'CRITICAL': '\033[95m',   # 亮紫色
    }
    
    # 样式代码
    STYLES = {
        'RESET': '\033[0m',       # 重置
        'BOLD': '\033[1m',        # 粗体
        'DIM': '\033[2m',         # 暗淡
        'UNDERLINE': '\033[4m',   # 下划线
    }
    
    def __init__(self, fmt=None, datefmt=None, style='%', validate=True):
        """初始化格式化器，保存原始格式用于动态切换"""
        super().__init__(fmt, datefmt, style, validate)
        # 保存有名称和无名称的格式
        self._fmt_with_name = fmt or '%(asctime)s [%(levelname)8s] %(name)s: %(message)s'
        self._fmt_without_name = '%(asctime)s [%(levelname)8s] %(message)s'
    
    def format(self, record):
        """格式化日志记录，支持多种样式"""
        # 检查是否需要隐藏root logger名称
        show_name = record.name != 'root'
        
        # 动态构建格式字符串
        if show_name:
            # 显示logger名称
            format_str = '%(asctime)s [%(levelname)8s] %(name)s: %(message)s'
        else:
            # 不显示logger名称
            format_str = '%(asctime)s [%(levelname)8s] %(message)s'
        
        # 临时设置格式
        original_fmt = self._fmt
        self._fmt = format_str
        
        message = super().format(record)
        
        # 恢复原始格式
        self._fmt = original_fmt
        
        color = self.COLORS.get(record.levelname, '')
        
        if record.levelname in ['ERROR', 'CRITICAL']:
            # 错误和严重错误使用粗体
            return f"{self.STYLES['BOLD']}{color}{message}{self.STYLES['RESET']}"
        elif color:
            return f"{color}{message}{self.STYLES['RESET']}"
        
        return message


class AdvancedColoredFormatter(logging.Formatter):
    """高级彩色格式化器，支持256色和RGB"""
    
    # 256色支持（更丰富的颜色）
    COLORS_256 = {
        'DEBUG': '\033[38;5;240m',    # 深灰
        'INFO': '\033[38;5;34m',      # 森林绿
        'WARNING': '\033[38;5;214m',  # 橙色
        'ERROR': '\033[38;5;196m',    # 亮红
        'CRITICAL': '\033[38;5;201m', # 洋红
    }
    
    # RGB真彩色支持
    COLORS_RGB = {
        'DEBUG': '\033[38;2;128;128;128m',     # 灰色
        'INFO': '\033[38;2;0;200;0m',          # 绿色
        'WARNING': '\033[38;2;255;165;0m',     # 橙色
        'ERROR': '\033[38;2;220;20;60m',       # 深红
        'CRITICAL': '\033[38;2;255;20;147m',   # 深粉
    }
    
    # 背景色（可选）
    BG_COLORS = {
        'ERROR': '\033[48;2;255;240;240m',     # 浅红背景
        'CRITICAL': '\033[48;2;255;240;245m',  # 浅粉背景
    }
    
    def __init__(self, color_mode='256', use_background=False):
        """
        初始化高级格式化器
        
        Args:
            color_mode: '256' 使用256色, 'rgb' 使用RGB真彩色
            use_background: 是否使用背景色
        """
        super().__init__()
        self.use_background = use_background
        
        if color_mode == 'rgb':
            self.colors = self.COLORS_RGB
        else:
            self.colors = self.COLORS_256
    
    def format(self, record):
        message = super().format(record)
        
        color = self.colors.get(record.levelname, '')
        bg_color = self.BG_COLORS.get(record.levelname, '') if self.use_background else ''
        
        if record.levelname in ['ERROR', 'CRITICAL']:
            return f"{bg_color}{color}\033[1m{message}\033[0m"
        elif color:
            return f"{color}{message}\033[0m"
        
        return message


def setup_simple_colored_logging():
    """设置简单的彩色日志系统"""
    # 获取根logger
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    
    # 清除现有handlers
    logger.handlers.clear()
    
    # 创建控制台handler
    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(logging.INFO)
    
    # 设置彩色格式化器
    # '%(asctime)s [%(levelname)8s] %(name)s: %(message)s',
    # datefmt='%Y-%m-%d %H:%M:%S'
    formatter = SimpleColoredFormatter(
        '%(asctime)s: %(message)s',
        datefmt='【%H:%M:%S】'
    )
    
    
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    
    return logger


def setup_win11_colored_logging():
    """设置Win11优化的彩色日志系统"""
    root_logger = logging.getLogger()
    root_logger.handlers.clear()
    root_logger.setLevel(logging.DEBUG)
    
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.DEBUG)
    
    formatter = Win11ColoredFormatter(
        fmt='%(asctime)s [%(levelname)8s] %(name)s: %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    
    console_handler.setFormatter(formatter)
    root_logger.addHandler(console_handler)
    
    return root_logger


def setup_advanced_colored_logging(color_mode='256', use_background=False):
    """
    设置高级彩色日志系统
    
    Args:
        color_mode: '256' 或 'rgb'
        use_background: 是否使用背景色
    """
    root_logger = logging.getLogger()
    root_logger.handlers.clear()
    root_logger.setLevel(logging.DEBUG)
    
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.DEBUG)
    
    formatter = AdvancedColoredFormatter(
        color_mode=color_mode,
        use_background=use_background
    )
    
    # 设置更详细的格式
    logging_format = '%(asctime)s [%(levelname)8s] %(name)s:%(lineno)d - %(message)s'
    formatter._fmt = logging_format
    formatter.datefmt = '%Y-%m-%d %H:%M:%S'
    
    console_handler.setFormatter(formatter)
    root_logger.addHandler(console_handler)
    
    return root_logger
