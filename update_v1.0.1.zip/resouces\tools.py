import base64, hmac, hashlib, time, struct, re, requests, threading, shutil, logging, datetime
from typing import Optional
from urllib.parse import urlparse, parse_qs
from pathlib import Path
from PySide6.QtGui import QColor
from email_sender import EmailSender
from file_oper import FileOper


logger = logging.getLogger()

# 根据延迟返回显示颜色。
def qcolor_for_latency(latency: Optional[float]) -> QColor:
    # 规则：<=500 绿色；<1500 橙色；<5000 红色；None 视为红色
    if latency is None:
        return QColor(220, 53, 69)
    if latency <= 500:
        return QColor(40, 167, 69)
    if latency < 1500:
        return QColor(255, 159, 67)
    if latency < 5000:
        return QColor(220, 53, 69)
    return QColor(220, 53, 69)



# 格式化延迟显示文本。
def format_latency_text(latency: Optional[float]) -> str:
    # 与原有逻辑一致：None => 失败；>=10000 => 连接超时；否则四舍五入显示 ms
    if latency is None:
        return "失败"
    if latency >= 10000:  # 10秒超时阈值
        return "连接超时"
    return f"{latency:.0f} ms"


# TOTP 验证码
def get_totp_code(secret: str, for_time: int = None) -> str:
    """
    根据 Google Authenticator 密钥（Base32，大写/小写均可），生成当前 6 位 TOTP 验证码。
    :param secret: TOTP 密钥（Base32 字符串）
    :param for_time: 指定时间（秒，UTC）；不填为当前时间
    :return: 6 位字符串验证码，失败返回空字符串
    """

    if not secret:
        return ""
    secret = secret.replace(" ", "").replace("-", "").upper()
    # 补齐 base32 padding
    padding = '=' * ((8 - len(secret) % 8) % 8)
    try:
        key = base64.b32decode(secret + padding, casefold=True)
    except Exception:
        return ""
    if for_time is None:
        for_time = int(time.time())
    timestep = int(for_time // 30)
    msg = struct.pack(">Q", timestep)
    h = hmac.new(key, msg, hashlib.sha1).digest()
    o = h[19] & 0x0F
    code = (struct.unpack(">I", h[o:o+4])[0] & 0x7fffffff) % 1000000
    return f"{code:06d}"



# 解析 Google Authenticator 二维码/字符串，提取 TOTP 密钥（Base32，大写）。
def parse_google_authenticator_secret(two_fa_code: str) -> str:
    """
    解析 Google Authenticator 二维码/字符串，提取 TOTP 密钥（Base32，大写）。
    支持：
    - 直接密钥（Base32，可含空格/横线）
    - otpauth://...（标准）
    - otpauth-migration://offline?data=...（迁移导出，自动解析第一个账号的 secret）
    无法解析返回空字符串。
    """
    
    if not two_fa_code:
        return ""
    code = two_fa_code.strip()

    # 1) otpauth-migration:// 处理（Google 迁移导出，data 为 protobuf）
    if code.lower().startswith("otpauth-migration://"):
        try:
            parsed = urlparse(code)
            qs = parse_qs(parsed.query)
            data_param = (qs.get("data", [""])[0] or "").strip()
            if not data_param:
                return ""
            # urlsafe base64 解码（补齐 padding）
            padding = '=' * (-len(data_param) % 4)
            payload = base64.urlsafe_b64decode(data_param + padding)

            # 仅实现需要的 protobuf 子集解析：
            # 顶层 message MigrationPayload 中的 field(1) 为重复 OtpParameters（length-delimited）
            # OtpParameters 中 field(1) 为 secret 的 bytes（length-delimited）
            def read_varint(buf, i):
                shift = 0
                result = 0
                while True:
                    b = buf[i]
                    i += 1
                    result |= (b & 0x7F) << shift
                    if (b & 0x80) == 0:
                        break
                    shift += 7
                return result, i

            def read_len_delimited(buf, i):
                ln, i = read_varint(buf, i)
                j = i + ln
                return buf[i:j], j

            def parse_otp_parameters_secret(msg_bytes):
                i = 0
                n = len(msg_bytes)
                while i < n:
                    tag, i = read_varint(msg_bytes, i)
                    field_no = tag >> 3
                    wire = tag & 0x7
                    if wire == 2:  # length-delimited
                        val, i = read_len_delimited(msg_bytes, i)
                        if field_no == 1:  # secret
                            return val
                    elif wire == 0:  # varint
                        _, i = read_varint(msg_bytes, i)
                    elif wire == 5:  # 32-bit
                        i += 4
                    elif wire == 1:  # 64-bit
                        i += 8
                    else:
                        break
                return None

            # 遍历顶层，提取第一个 OtpParameters 的 secret
            i = 0
            n = len(payload)
            first_secret = None
            while i < n and first_secret is None:
                tag, i = read_varint(payload, i)
                field_no = tag >> 3
                wire = tag & 0x7
                if field_no == 1 and wire == 2:  # otp_parameters
                    submsg, i = read_len_delimited(payload, i)
                    secret_bytes = parse_otp_parameters_secret(submsg)
                    if secret_bytes:
                        first_secret = secret_bytes
                elif wire == 2:
                    _, i = read_len_delimited(payload, i)
                elif wire == 0:
                    _, i = read_varint(payload, i)
                elif wire == 5:
                    i += 4
                elif wire == 1:
                    i += 8
                else:
                    break

            if first_secret:
                # 转为 Base32（去除 padding，大写）
                b32 = base64.b32encode(first_secret).decode('ascii').replace('=', '').upper()
                return b32
        except Exception:
            return ""
        return ""

    # 2) 标准 otpauth://
    if code.lower().startswith("otpauth://"):
        parsed = urlparse(code)
        qs = parse_qs(parsed.query)
        secret = qs.get("secret")
        if secret:
            return (secret[0] or "").replace(" ", "").upper()
        import re as _re
        match = _re.search(r'secret=([\w\-]+)', code)
        if match:
            return match.group(1).replace(" ", "").upper()
        return ""

    # 3) 直接 Base32 密钥（容忍空格和横线）
    match = re.fullmatch(r'[\s\-A-Za-z2-7]+', code)
    if match:
        return code.replace(" ", "").replace("-", "").upper()

    # 4) 其他字符串里包含 secret= 片段
    match = re.search(r'secret=([\w\-]+)', code)
    if match:
        return match.group(1).replace(" ", "").upper()
    return ""


def detect_browsers() -> list[str]:
    browsers = []
    
    if is_browser_available("chrome"):
        browsers.append("chrome")
    if is_browser_available("edge"):
        browsers.append("edge")
    if is_browser_available("firefox"):
        browsers.append("firefox")
    if not browsers:
        browsers.append("chrome")
    return browsers


# 检测本机浏览器可用性。
def is_browser_available(browser: str) -> bool:
    if browser == "chrome":
        return bool(shutil.which("chrome")) or any(
            (Path(path).exists())
            for path in [
                "C:/Program Files/Google/Chrome/Application/chrome.exe",
                "C:/Program Files (x86)/Google/Chrome/Application/chrome.exe",
            ]
        )
    # if browser == "edge":
    #     return bool(shutil.which("msedge")) or any(
    #         (Path(path).exists())
    #         for path in [
    #             "C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe",
    #             "C:/Program Files/Microsoft/Edge/Application/msedge.exe",
    #         ]
    #     )
    # if browser == "firefox":
    #     return bool(shutil.which("firefox")) or any(
    #         (Path(path).exists())
    #         for path in [
    #             "C:/Program Files/Mozilla Firefox/firefox.exe",
    #             "C:/Program Files (x86)/Mozilla Firefox/firefox.exe",
    #         ]
    #     )
    return False





# 全局变量用于缓存 token 列表
# 异步获取 Binance Alpha Token 列表，完成后通过回调返回。
# callback 的签名为 callback(result: list[dict] | None)
def get_binance_alpha_token_list_request(timeout: float = 8.0, callback=None, max_retries: int = 3) -> None:
    url = "https://www.binance.com/bapi/defi/v1/public/wallet-direct/buw/wallet/cex/alpha/all/token/list"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        "Accept": "application/json, text/plain, */*",
        "Accept-Language": "en-US,en;q=0.9",
        "Accept-Encoding": "gzip, deflate, br",
        "Connection": "keep-alive",
        "Referer": "https://www.binance.com/",
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "same-origin"
    }

    def fetch():
        result = None
        last_error = None
        
        for attempt in range(max_retries):
            try:
                # 创建会话以复用连接
                session = requests.Session()
                
                # 配置重试策略
                from requests.adapters import HTTPAdapter
                from urllib3.util.retry import Retry
                
                retry_strategy = Retry(
                    total=2,
                    backoff_factor=1,
                    status_forcelist=[429, 500, 502, 503, 504],
                )
                
                adapter = HTTPAdapter(max_retries=retry_strategy)
                session.mount("http://", adapter)
                session.mount("https://", adapter)
                
                # 发送请求
                resp = session.get(url, headers=headers, timeout=timeout, verify=True)
                resp.raise_for_status()
                
                # 解析响应
                data = resp.json()
                if isinstance(data, dict) and "data" in data and isinstance(data["data"], list):
                    result = data["data"]
                    break  # 成功获取数据，退出重试循环
                else:
                    result = None
                    break
                    
            except requests.exceptions.SSLError as ssl_ex:
                last_error = ssl_ex
                if attempt < max_retries - 1:
                    logger.warning(f" SSL错误，尝试重试 ({attempt + 1}/{max_retries}): {ssl_ex}")
                    time.sleep(2 ** attempt)  # 指数退避
                    continue
                else:
                    logger.error(f" SSL连接失败，已重试 {max_retries} 次: {ssl_ex}")
                    break
                    
            except requests.exceptions.ConnectionError as conn_ex:
                last_error = conn_ex
                if attempt < max_retries - 1:
                    logger.warning(f" 连接错误，尝试重试 ({attempt + 1}/{max_retries}): {conn_ex}")
                    time.sleep(2 ** attempt)  # 指数退避
                    continue
                else:
                    logger.error(f" 连接失败，已重试 {max_retries} 次: {conn_ex}")
                    break
                    
            except requests.exceptions.Timeout as timeout_ex:
                last_error = timeout_ex
                if attempt < max_retries - 1:
                    logger.warning(f" 请求超时，尝试重试 ({attempt + 1}/{max_retries}): {timeout_ex}")
                    time.sleep(2 ** attempt)  # 指数退避
                    continue
                else:
                    logger.error(f" 请求超时，已重试 {max_retries} 次: {timeout_ex}")
                    break
                    
            except requests.exceptions.HTTPError as http_ex:
                last_error = http_ex
                logger.error(f" HTTP错误: {http_ex}")
                break  # HTTP错误通常不需要重试
                
            except Exception as ex:
                last_error = ex
                logger.error(f" 获取 Binance Alpha Token 列表失败: {ex}")
                break
        
        # 如果所有重试都失败了，记录最终错误
        if result is None and last_error:
            logger.error(f" 获取 Binance Alpha Token 列表最终失败: {last_error}")
        
        # 调用回调函数
        if callback:
            try:
                callback(result)
            except Exception as ex2:
                logger.warning(f" 调用 Binance Alpha Token 回调出错: {ex2}")

    t = threading.Thread(target=fetch, daemon=True)
    t.start()



# 排序并获取最佳 Binance Alpha Token
def sort_and_get_best_binance_alpha_token(token_list) -> dict | None:
    if not token_list:
        return None
    filtered = list(token_list)
    if not filtered:
        return None
    # 排序是从高到低的。mulPoint 优先降序，marketCap 次之降序
    def key_func(token):
        mulPoint = token.get("mulPoint", 0)
        market_cap = token.get("marketCap", 0)
        try:
            market_cap = float(market_cap) if market_cap is not None else 0
        except Exception:
            market_cap = 0
        return (mulPoint, market_cap)
    filtered.sort(key=key_func, reverse=True)  # reverse=True 表示从高到低
    return filtered[0] if filtered else None



# 安全转换为浮点数，仅保留换行分割的第一个字段进行转换
def safe_float(text):
    """
    从包含杂项字符和/或换行的字符串中提取第一个出现的浮点数。先去除,分隔符再处理。
    如 '可用\n820,312.79 USDT\n预估手续费\n-- COAI' 能正确提取出 820312.79。
    """
    if not isinstance(text, str):
        text = str(text)
    # 先删除所有英文逗号
    text = text.replace(',', '')
    # 用正则查找所有可能的数字（整数或小数，可带负号）
    matches = re.findall(r'-?\d+(?:\.\d+)?', text)
    if matches:
        try:
            return float(matches[0])
        except Exception:
            return 0.0
    return 0.0

def send_email(subject: str, content: str) -> bool:
    notify_email = FileOper.get_sys_config().get("notify_email", None)
    if not notify_email:
        logger.warning(f"[邮件] 未配置收件人邮箱")
        return False
    sender = EmailSender()
    success, message = sender.send_email(
        to_emails=[notify_email],
        subject=subject,
        body=content,
        is_html=False
    )
    logger.info(f"发送结果: {success}, {message}")


# 获取域名后的一级目录基础地址，如 https://www.binance.com/zh-CN/my/dashboard -> https://www.binance.com/zh-CN
def get_domain_first_path(url: str) -> str:
    try:
        p = urlparse(url)
        if not p.scheme or not p.netloc:
            return url
        # 规整 path，提取第一个目录片段
        path = (p.path or "/").strip()
        if not path or path == "/":
            first = ""
        else:
            parts = [seg for seg in path.split("/") if seg]
            first = "/" + parts[0] if parts else ""
        base = f"{p.scheme}://{p.netloc}{first}"
        return base
    except Exception:
        return url

# 智能解析日期时间字符串
def smart_parse_datetime(dt_str: str, timezone: str = "Asia/Shanghai"):
    """
    智能解析日期时间字符串，将解析到的时间加上指定时区（默认 Asia/Shanghai）。
    返回带有 tzinfo 的 datetime.datetime 对象。
    """
    if not isinstance(dt_str, str) or not dt_str.strip():
        return None

    try:
        # 优先尝试用 zoneinfo，如果没有则 fallback pytz
        try:
            from zoneinfo import ZoneInfo
            tz = ZoneInfo(timezone)
        except ImportError:
            import pytz
            tz = pytz.timezone(timezone)
    except Exception:
        tz = None

    text = dt_str.strip()
    # 统一中文分隔符
    text = text.replace("年", "-").replace("月", "-").replace("日", "")
    text = text.replace("上午", "AM").replace("下午", "PM")

    # 去除多余空格
    text = re.sub(r"\s+", " ", text)

    # 特定适配常见格式：Y-m-d H:M:S（包含 2025-10-28 15:38:54 这种格式）
    try:
        m = re.match(r"(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2}):(\d{2})$", text)
        if m:
            dt = datetime.datetime(
                int(m.group(1)), int(m.group(2)), int(m.group(3)),
                int(m.group(4)), int(m.group(5)), int(m.group(6))
            )
            if tz:
                dt = dt.replace(tzinfo=tz)
            return dt
    except Exception:
        pass

    # 常见候选格式，中/美时间混合，优先常见写法
    formats = [
        "%Y-%m-%d %H:%M:%S",
        "%Y/%m/%d %H:%M:%S",
        "%Y.%m.%d %H:%M:%S",
        "%Y-%m-%d %H:%M",
        "%Y/%m/%d %H:%M",
        "%Y.%m.%d %H:%M",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%dT%H:%M:%S.%f",
        "%Y-%m-%d",
        "%Y/%m/%d",
        "%Y.%m.%d",

        "%m/%d/%Y %I:%M:%S %p",  # 美式 06/25/2023 03:37:08 PM
        "%m/%d/%Y %H:%M:%S",
        "%m/%d/%Y",

        "%d/%m/%Y %H:%M:%S",    # 欧式 25/06/2023 15:37:08
        "%d/%m/%Y %I:%M:%S %p",
        "%d/%m/%Y",

        "%m-%d-%Y %H:%M:%S",
        "%m-%d-%Y",

        "%H:%M:%S %Y-%m-%d",
        "%Y-%m-%d %H:%M",
        "%Y年%m月%d日 %H:%M:%S",
        "%Y年%m月%d日 %H:%M",
        "%Y年%m月%d日",

        "%m/%d/%y %H:%M:%S",
        "%m/%d/%y",

        "%d.%m.%Y",
        "%Y%m%d",
    ]
    # 秒数可能有小数
    if re.search(r"\d{2}:\d{2}:\d{2}\.\d+", text):
        for basefmt in ["%Y-%m-%d %H:%M:%S.%f", "%Y/%m/%d %H:%M:%S.%f", "%Y.%m.%d %H:%M:%S.%f"]:
            try:
                dt = datetime.datetime.strptime(text, basefmt)
                if tz:
                    dt = dt.replace(tzinfo=tz)
                return dt
            except Exception:
                continue

    # 逐一尝试所有格式
    for fmt in formats:
        try:
            dt = datetime.datetime.strptime(text, fmt)
            if tz:
                dt = dt.replace(tzinfo=tz)
            return dt
        except Exception:
            continue

    # 自动检测 ISO 8601 (带T的)
    try:
        dt = datetime.datetime.fromisoformat(text)
        if tz and dt.tzinfo is None:
            dt = dt.replace(tzinfo=tz)
        return dt
    except Exception:
        pass

    # 尝试去掉AM/PM前缀的空格
    alt_text = re.sub(r'\s*(AM|PM)$', r'\1', text, flags=re.IGNORECASE)
    for fmt in ["%m/%d/%Y %I:%M:%S%p", "%d/%m/%Y %I:%M:%S%p"]:
        try:
            dt = datetime.datetime.strptime(alt_text, fmt)
            if tz:
                dt = dt.replace(tzinfo=tz)
            return dt
        except Exception:
            continue

    return None