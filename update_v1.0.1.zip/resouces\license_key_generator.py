"""
许可证密钥生成器
根据注册码和时间生成带时间限制的密钥
"""

import json
import base64
from datetime import datetime, timedelta
from typing import Optional, Tuple
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.backends import default_backend
from app_globals import get_now


# 默认密钥（实际使用时应该改为更安全的密钥，或从配置文件读取）
DEFAULT_SECRET_KEY = "MySecretKey2024!@#$%^&*()"


def _get_fernet_key(secret_key: str) -> bytes:
    """
    从密钥字符串生成Fernet密钥
    
    Args:
        secret_key: 密钥字符串
        
    Returns:
        Fernet密钥字节
    """
    # 使用PBKDF2从密钥字符串生成Fernet密钥
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=b'license_salt_2024',  # 固定盐值，确保每次生成相同的密钥
        iterations=100000,
        backend=default_backend()
    )
    key = base64.urlsafe_b64encode(kdf.derive(secret_key.encode('utf-8')))
    return key


def generate_license_key(
    registration_code: str,
    expiration_days: int = 30,
    secret_key: Optional[str] = None
) -> str:
    """
    加密功能：根据注册码和时间生成加密的许可证密钥
    
    Args:
        registration_code: 注册码
        expiration_days: 有效天数（从当前时间开始计算）
        secret_key: 密钥（用于加密），如果为None则使用默认密钥
    
    Returns:
        许可证密钥（Base64编码的加密字符串）
    """
    if secret_key is None:
        secret_key = DEFAULT_SECRET_KEY
    
    # 清理注册码（移除分隔符并转为大写）
    clean_reg_code = registration_code.replace('-', '').upper()
    
    # 计算过期时间戳
    expiration_date = get_now() + timedelta(days=expiration_days)
    expiration_timestamp = int(expiration_date.timestamp())
    
    # 组合数据：注册码 + 过期时间戳（JSON格式）
    data_dict = {
        "registration_code": clean_reg_code,
        "expiration_timestamp": expiration_timestamp
    }
    data_json = json.dumps(data_dict, separators=(',', ':'))
    data_bytes = data_json.encode('utf-8')
    
    # 获取Fernet密钥并加密
    fernet_key = _get_fernet_key(secret_key)
    fernet = Fernet(fernet_key)
    encrypted_data = fernet.encrypt(data_bytes)
    
    # 返回Base64编码的加密字符串
    license_key = encrypted_data.decode('utf-8')
    
    return license_key


def parse_license_key(
    license_key: str,
    secret_key: Optional[str] = None
) -> Tuple[bool, Optional[datetime], str]:
    """
    解密功能：解密许可证密钥并验证注册码和时间

    Args:
        license_key: 许可证密钥（加密的Base64字符串）
        secret_key: 密钥（用于解密），如果为None则使用默认密钥

    Returns:
        (是否有效, 过期时间, 消息)
    """
    if secret_key is None:
        secret_key = DEFAULT_SECRET_KEY

    from app_globals import DEFAULT_TIMEZONE

    try:
        # 清理许可证密钥（移除空白字符）
        clean_license = license_key.strip()

        # 获取Fernet密钥并解密
        fernet_key = _get_fernet_key(secret_key)
        fernet = Fernet(fernet_key)

        # 解密数据
        encrypted_data = clean_license.encode('utf-8')
        decrypted_data = fernet.decrypt(encrypted_data)
        data_json = decrypted_data.decode('utf-8')
        data_dict = json.loads(data_json)

        # 提取注册码和过期时间戳
        encrypted_reg_code = data_dict.get("registration_code", "")
        expiration_timestamp = data_dict.get("expiration_timestamp", 0)

        # 验证注册码：比较解密出的注册码与当前机器的注册码
        from registration_code import generate_registration_code
        current_reg_code = generate_registration_code().replace('-', '').upper()
        encrypted_reg_code_clean = encrypted_reg_code.upper()

        # 比较解密出的注册码与当前机器的注册码
        if encrypted_reg_code_clean != current_reg_code:
            return False, None, f"注册码不匹配！许可证中的注册码与当前机器不符。"

        # 转换时间戳为datetime，指定Asia/Shanghai时区
        expiration_date = datetime.fromtimestamp(expiration_timestamp, DEFAULT_TIMEZONE)
        now = get_now()

        # 验证时间是否有效
        if expiration_date < now:
            return False, expiration_date, f"许可证已过期（过期时间: {expiration_date.strftime('%Y-%m-%d %H:%M:%S')}）"
        else:
            remaining = expiration_date - now
            return True, expiration_date, f"许可证有效（过期时间: {expiration_date.strftime('%Y-%m-%d %H:%M:%S')}，剩余: {remaining.days}天）"
    except Exception as e:
        return False, None, f"密钥解析异常: {e}"
    


def verify_license_key(
    license_key: str,
    secret_key: Optional[str] = None
) -> bool:
    """
    验证许可证密钥是否有效，同时在验证成功或失败时发送LicenseSignal事件

    Args:
        license_key: 许可证密钥（加密的Base64字符串）
        secret_key: 密钥（用于解密）

    Returns:
        True: 密钥有效且未过期
        False: 密钥无效或已过期
    """
    from slot_events import LicenseSignal

    is_valid, expiration_date, message = parse_license_key(
        license_key, secret_key
    )
    now = get_now()

    if is_valid and expiration_date:
        if expiration_date > now:
            remaining_days = (expiration_date - now).days
            LicenseSignal.license_status_changed.emit("已注册", remaining_days)
            return True
        else:
            LicenseSignal.license_status_changed.emit("已过期", -1)
            return False
    else:
        LicenseSignal.license_status_changed.emit("未注册", -1)
        return False



def generate_license_key_with_timestamp(
    registration_code: str,
    expiration_timestamp: int,
    secret_key: Optional[str] = None
) -> str:
    """
    根据注册码和指定的时间戳生成加密的许可证密钥
    
    Args:
        registration_code: 注册码
        expiration_timestamp: 过期时间戳（Unix时间戳）
        secret_key: 密钥（用于加密）
    
    Returns:
        许可证密钥（Base64编码的加密字符串）
    """
    if secret_key is None:
        secret_key = DEFAULT_SECRET_KEY
    
    # 清理注册码（移除分隔符并转为大写）
    clean_reg_code = registration_code.replace('-', '').upper()
    
    # 组合数据：注册码 + 过期时间戳（JSON格式）
    data_dict = {
        "registration_code": clean_reg_code,
        "expiration_timestamp": expiration_timestamp
    }
    data_json = json.dumps(data_dict, separators=(',', ':'))
    data_bytes = data_json.encode('utf-8')
    
    # 获取Fernet密钥并加密
    fernet_key = _get_fernet_key(secret_key)
    fernet = Fernet(fernet_key)
    encrypted_data = fernet.encrypt(data_bytes)
    
    # 返回Base64编码的加密字符串
    license_key = encrypted_data.decode('utf-8')
    
    return license_key


