import random, traceback, os, time

from selenium.webdriver.common.by import By
from selenium.webdriver.firefox.options import Log
from file_oper import FileOper
from datas import get_country_by_idx
from tools import *
from selenium_tools import *
from driver_manager import DriverSession, DriverManager
from app_globals import get_best_binance_alpha_token, get_now
from scripts.scripts_tag_config import ScriptTagConfig
from data_type import TradeAction, NotifyType
from slot_events import ScriptSignal
import logging
logger = logging.getLogger()


# 未验证方式等待的超时时间（单位：秒）
UNVERIFIED_STOP_TIMEOUT = 2 * 60  # 2分钟

BASE_URL = "binance.com"
ROOT_URL = "https://www.binance.com"
LOGIN_URL = "https://accounts.binance.com"

    
# 邮件通知时间间隔（单位：秒）
NOTIFY_INTERVAL = {
    NotifyType.HUMAN_VERIFICATION: 10 * 60,  # 人工验证10分钟
    NotifyType.NETWORK: 10 * 60,  # 网络异常20分钟
    NotifyType.LOGIN: 60 * 60,  # 登录失效20分钟
    NotifyType.NO_MONEY: 20 * 60,  # 余额不足20分钟
    NotifyType.TRADE_COMPLETED: 10 * 60,  # 交易完成10分钟
    NotifyType.ABNORMAL_EXIT: 10 * 60,  # 异常退出10分钟
    NotifyType.ORDER_ACCUMULATED: 10 * 60,  # 订单累积10分钟
    NotifyType.NO_GOOGLE_AUTH: 10 * 60,  # 没有谷歌认证10分钟
}

class BinanceAlpha:
    def __init__(self, driver_session: DriverSession):
        self.sell_event_counter = 0
        self.buy_error_counter = 0
        self.buy_success_counter = 0
        self._last_notify_times = {
            NotifyType.HUMAN_VERIFICATION: 0,
            NotifyType.NETWORK: 0,
            NotifyType.LOGIN: 0,
            NotifyType.NO_MONEY: 0,
            NotifyType.TRADE_COMPLETED: 0,
            NotifyType.ABNORMAL_EXIT: 0,
            NotifyType.ORDER_ACCUMULATED: 0,
            NotifyType.NO_GOOGLE_AUTH: 0,
        }

        self._init_from_config(driver_session=driver_session)
        
    # 从配置文件中初始化脚本
    def _init_from_config(self, driver_session: DriverSession):
        self.driver_session = driver_session
        self.driver = self.driver_session.driver
        self.config = self.driver_session.config_data
        self.extra_args = self.config.extra_args
        self.config_id = self.config.id

        self.country_index = self.config.country_index
        self.country = get_country_by_idx(self.country_index)
        self.timezone = self.country.get("timezone", "Asia/Shanghai")

        self.buy_premium = abs(float(self.extra_args.get("buy_premium", 0.0)))
        self.sell_discount = abs(float(self.extra_args.get("sell_discount", 0.0)))
        self.trade_amount_per_order = abs(float(self.extra_args.get("trade_amount_per_order", 0.0)))
        self.total_points_stop = abs(float(self.extra_args.get("total_points_stop", 0)))
        self.authenticator = self.extra_args.get("authenticator", None)
        driver_get(self.driver, ROOT_URL)

        # 获取当前浏览器的语言首选项（accept-language）
        self.accept_language = None
        try:
            self.accept_language = self.driver.execute_script(
                "return (navigator.languages && navigator.languages.length) ? navigator.languages[0] : navigator.language;"
            )
        except Exception as e:
            logger.error(f"[binance_alpha] 获取浏览器语言首选项失败: {e}")


        if self.accept_language:
            self.script_tag_config = ScriptTagConfig.get("binance_alpha").get(self.accept_language)
        else:
            logger.error(f"[binance_alpha] 不支持的地区")
            self.clear()

        idx = 0
        while True:
            if ROOT_URL == self.driver.current_url:
                self.sleep(1)
                idx+=1
                if idx%3 == 0:
                    driver_get(self.driver, ROOT_URL)
                if idx > 100:
                    logger.error(f"[binance_alpha] 币安页面加载失败")
                    self.clear()
            else:
                break

        # 睡眠3秒，等待页面加载完成
        self.sleep(2)
        best_token = None
        try:
            best_token = get_best_binance_alpha_token()
            if best_token:
                url_host = get_domain_first_path(self.driver.current_url);
                chainName = best_token.get("chainName", "").lower()
                contractAddress = best_token.get("contractAddress", "")

                self.trade_url = f"{url_host}/alpha/{chainName}/{contractAddress}"
            else:
                logger.error(f"[binance_alpha] 币安代币获取失败")
                self.clear()
                return False
        except Exception as e:
            ScriptSignal.script_warning.emit(self.config_id, "币安代币获取失败")
            logger.error(f"[binance_alpha] 币安代币获取失败: {e}")
            self.clear()
            return False
        
        mulPoint = None
        if isinstance(best_token, dict) and "mulPoint" in best_token:
            try:
                mulPoint = float(best_token.get("mulPoint", None))
            except Exception as e:
                logger.error(f"[binance_alpha] 币安代币获取失败: {e}")
                ScriptSignal.script_warning.emit(self.config_id, "币安代币获取失败")
                self.clear()
                return False
        # 若 best_token 只是 str，则忽略
        if mulPoint is not None:
            self.points_multiplier = abs(mulPoint)
        else:
            self.points_multiplier = abs(float(self.extra_args.get("mulPoint", 1)))

        self.symbol = best_token.get("symbol", "")

    # 登录逻辑
    def _login(self):
        # 如果出现二维码登录UI，立即发送“需要验证”状态
        # 查找__APP的元素
        appid_elem = find_element_unique(
            self.driver,
            By.XPATH,
            '//*[@id="__APP"]'
        )
        if appid_elem is None:
            logger.error(f"[binance_alpha] 未找到 __APP 元素")
            return False

        # 判断是否勾选了“不在显示此消息”
        checkbox_div = find_element_unique(
            appid_elem, By.ID, "stay-signed-checkbox"
        )
        if checkbox_div and checkbox_div.is_displayed():
            logger.info(f"[binance_alpha] 登录成功")
            try_click_element(appid_elem, checkbox_div)

            # 点击“是”按钮
            # 查找与checkbox_div同级且class为bn-button__primary的button
            btn_elem = find_element_unique(
                checkbox_div,
                By.XPATH,
                "./following-sibling::button[contains(@class, 'bn-button__primary')]"
            )
            if btn_elem and btn_elem.is_displayed():
                try_click_element(appid_elem, btn_elem)

            return True
        

        # 判断二维码是否过期，如果过期就刷新二维码
        expired_elem = find_element_unique(
            appid_elem, 
            By.XPATH, 
            ".//div[@role='tooltip']//div[contains(@class, 'bn-bubble-content')]//div[@role='button' and @aria-label]"
        )
        if expired_elem and expired_elem.is_displayed():
            try_click_element(appid_elem, expired_elem)
            ScriptSignal.script_warning.emit(self.config_id, "币安登录验证")
            self.notify_event(NotifyType.LOGIN)
            return True

        # [点击二维码小图标按钮] 查找 appid_elem 下面的 svg 元素，并且 fill="textPrimary"，使用 By.XPATH
        qr_small_icon = find_element_unique(
            appid_elem,
            By.XPATH,
            ".//div[@role='button' and @aria-label and @aria-expanded]"
        )
        if qr_small_icon:
            aria_expanded = qr_small_icon.get_attribute("aria-expanded")
            if aria_expanded == "false":
                try_click_element(appid_elem, qr_small_icon)
                logger.info(f"[binance_alpha] 找到二维码小图标按钮")

        return True
    
    # 交易逻辑
    def _trade(self):
        self._enter_front()

        #--------------------------------------------------------------------------#
        # 查找根元素、买卖面板元素
        #------------------------------------------------------------------------------------------------
        # ---查找根元素---
        appid_elem = find_element_unique(self.driver, By.ID, "__APP")
        if not appid_elem:
            logger.error(f"[binance_alpha] 未找到 id=__APP 根元素 ")
            return False

        # ---查找买卖面板元素---
        flexlayout_tab_elem = find_element_unique(
            appid_elem,
            By.XPATH,
            './/div[contains(@class, "flexlayout__tab") and @data-layout-path="/r1/ts0/t0"]'
        )
        if not flexlayout_tab_elem:
            logger.error(f"[binance_alpha] 未找到【查找买卖面板元素】")
            return False

        #--------------------------------------------------------------------------#
        # 查找【买入】、【卖出】、【限价】tab按钮
        #------------------------------------------------------------------------------------------------
        # 查找【买入】tab按钮
        bn_tab_buy_elem = find_element_unique(flexlayout_tab_elem, By.ID, "bn-tab-0")
        if not bn_tab_buy_elem:
            logger.error(f"[binance_alpha] 未找到 flexlayout_tab_elem 下的 id=bn-tab-0 的【买入】元素")
            return False

        # 查找【卖出】tab按钮
        bn_tab_sell_elem = find_element_unique(flexlayout_tab_elem, By.ID, "bn-tab-1")
        if not bn_tab_sell_elem:
            logger.error(f"[binance_alpha] 未找到 flexlayout_tab_elem 下的 id=bn-tab-1 的【卖出】元素")
            return False

        # 查找【限价】tab按钮
        bn_tab_limit_elem = find_element_unique(flexlayout_tab_elem, By.ID, "bn-tab-LIMIT")
        if not bn_tab_limit_elem:
            logger.error(f"[binance_alpha] 未找到 flexlayout_tab_elem 下的 id=bn-tab-LIMIT 的【限价】元素")
            return False
            
        # # 查找【即时】tab按钮
        # bn_tab_instant_elem = find_element_unique(flexlayout_tab_elem, By.ID, "bn-tab-INSTANT")
        # if not bn_tab_instant_elem:
        #     logger.error(f"[binance_alpha] 未找到 flexlayout_tab_elem 下的 id=bn-tab-INSTANT 的【即时】标签元素")
        #     return False
        # try_click_element(self.driver, bn_tab_instant_elem)
        # logger.info(f"[binance_alpha] 已点击 flexlayout_tab_elem 下的 id=bn-tab-INSTANT 的【即时】标签元素")



        # 先点限价，再点卖出，在点买入，可获得最新价格
        try_click_element(self.driver, bn_tab_limit_elem)
        try_click_element(self.driver, bn_tab_sell_elem)
        #self.sleep(random.uniform(0.5, 1))
        try_click_element(self.driver, bn_tab_buy_elem)
        self.sleep(random.uniform(0.5, 1))
        #--------------------------------------------------------------------------#
        # 获得所有输入框元素
        #------------------------------------------------------------------------------------------------

        #判断反向订单元素是否存在和可用金额是否大于0
        # 查找反向订单的复选框，判断role="checkbox"并且aria-checked存在（使用find_element_unique，使用默认超时）
        reverse_checkbox_elem = find_element_unique(
            flexlayout_tab_elem,
            By.XPATH,
            ".//*[@role='checkbox' and @aria-checked]"  # 注意前面用.，只在flexlayout_tab_elem下查找
        )
        if not reverse_checkbox_elem:
            logger.error(f"[binance_alpha] 未找到反向订单复选框元素")
            return False
        
        # 单击【反向订单】复选框
        aria_checked = reverse_checkbox_elem.get_attribute("aria-checked")
        if aria_checked != "true":
            try_click_element(self.driver, reverse_checkbox_elem)
            logger.info(f"[binance_alpha] 已点击反向订单复选框元素")
        
        # 查找【限价卖出】的输入框
        # 使用一条 xpath 查找 reverse_checkbox_elem 的祖父节点下 id=limitTotal 的 input 元素
        sell_limit_total_input = find_element_unique(
            reverse_checkbox_elem,
            By.XPATH,
            "./parent::*/parent::*/descendant::input[@id='limitTotal']"
        )

        if not sell_limit_total_input:
            logger.error(f"[binance_alpha] 未找到 限价卖出 的输入框元素")
            return False
        
        
        # 查找可用金额
        # 查找 reverse_checkbox_elem 的祖父节点同级下的第一个 div 元素
        available_amount_div = find_element_unique(
            reverse_checkbox_elem,
            By.XPATH,
            "./parent::*/parent::*/following-sibling::div[1]"
        )
        if not available_amount_div:
            logger.error(f"[binance_alpha] 未找到 可用金额 div 元素")
            return False
        
        available_amount_text = available_amount_div.text
        available_amount_value = safe_float(available_amount_text)
        if available_amount_value <= 0:
            logger.error(f"[binance_alpha] 可用金额不足，无法交易")
            return False

        # 判断可用金额是否足够
        if available_amount_value < self.trade_amount_per_order:
            logger.error(f"[binance_alpha] 可用金额不足: {self.trade_amount_per_order} USDT")
            self.notify_event(NotifyType.NO_MONEY)
            self.clear();
            return False


        # 查找【价格】输入框，通过 flexlayout_tab_elem 查找 limitPrice 输入框
        limit_price_input = find_element_unique(
            flexlayout_tab_elem,
            By.XPATH,
            ".//input[@id='limitPrice']"
        )
        if not limit_price_input:
            logger.error(f"[binance_alpha] 未找到 限价价格 limitPrice 的输入框元素")
            return False

        # 判断 limit_price_input 的内容大于0
        limit_price_value = None
        try:
            limit_price_text = getattr(limit_price_input, 'get_attribute', lambda x: None)('value')
            limit_price_value = safe_float(limit_price_text)
        except Exception:
            limit_price_value = None
            return False

        if not limit_price_value or limit_price_value <= 0:
            logger.error(f"[binance_alpha] 限价价格输入框内容不合法或小于等于0, 获取当前价格出错")
            return False


        # 获取 【成效额】 输入框
        # 查找ID为limitTotal，使用flexlayout_tab_elem
        buy_total_input = find_element_unique(
            flexlayout_tab_elem,
            By.ID,
            "limitTotal"
        )
        if not buy_total_input:
            logger.error(f"[binance_alpha] 未找到 成效额 limitTotal 的输入框元素")
            return False


        #--------------------------------------------------------------------------#
        # 设置所有输入框元素的值
        #------------------------------------------------------------------------------------------------
        buy_price = limit_price_value * ((100+self.buy_premium)/100)
        sell_price = limit_price_value * ((100 - self.sell_discount)/100)


        set_input_value_with_actions(self.driver, limit_price_input, buy_price)
        set_input_value_with_actions(self.driver, sell_limit_total_input, sell_price)
        set_input_value_with_actions(self.driver, buy_total_input, self.trade_amount_per_order)


        #--------------------------------------------------------------------------#
        # 单击【买入】按钮
        #------------------------------------------------------------------------------------------------

        # 单击【买入】按钮
        # 使用 find_element_unique 方法查找 flexlayout_tab_elem 下的 class=bn-button__bu 的 button
        buy_button = find_element_unique(
            flexlayout_tab_elem,
            By.XPATH,
            ".//button[contains(@class, 'bn-button__bu')]"
        )
        if not buy_button:
            logger.error(f"[binance_alpha] 未找到 class=bn-button__bu 的【买入】按钮元素")
            return False

        try_click_element(self.driver, buy_button)
        logger.info(f"[binance_alpha] 已点击 class=bn-button__bu 的【买入】按钮元素")


        self._check_disclaimer_dialog()


        is_buy_coin = self._buy_coin()
        if is_buy_coin:
            self._check_order_success_alert()
            
            return True
        else:
            return False

    # 检测免责声明弹窗
    def _check_disclaimer_dialog(self):
        if hasattr(self, "_check_disclaimer_dialog_runned") and self._check_disclaimer_dialog_runned:
            return False
        self._check_disclaimer_dialog_runned = True

        dialog_div = self._get_dialog_div()
        if not dialog_div:
            return False

        # 查找免责申明的复选框
        checkbox_div = find_element_unique(
            dialog_div,
            By.XPATH,
            ".//div[@role='checkbox' and @aria-checked='false']"
        )
        if not checkbox_div:
            return False

        # checkbox_div 查找这下面的第一个div
        next_div = find_element_unique(
            checkbox_div, 
            By.XPATH, 
            './div[contains(@class, "bn-checkbox-icon")]'
        )
        if not next_div:
            return False
        try_click_element(dialog_div, next_div)
        logger.info(f"[binance_alpha] 已点击免责声明弹窗中的未勾选的checkbox")

        # 查找免责声明弹窗中的主按钮
        primary_btn = find_element_unique(
            dialog_div,
            By.XPATH,
            './/button[contains(@class, "bn-button__primary")]'
        )
        if not primary_btn:
            return False
        try_click_element(dialog_div, primary_btn)
        logger.info(f"[binance_alpha] 已点击免责声明弹窗中的主按钮")
        return True

    # 提交订单前
    def _enter_front(self):
        # 判断只执行一次
        if hasattr(self, "_enter_front_runned") and self._enter_front_runned:
            return True
        self._enter_front_runned = True

        for i in range(2):
            dialog_div = self._get_dialog_div()
            if dialog_div:
                confirm_button = find_element_unique(
                    dialog_div,
                    By.XPATH,
                    ".//button[contains(@class, 'bn-button__primary')]"
                )
                if confirm_button:
                    try_click_element(self.driver, confirm_button)
                    logger.info(f"[binance_alpha] 已点击 class=bn-button__primary 的按钮")
                else:
                    logger.error(f"[binance_alpha] 未找到 class=bn-button__primary 的按钮")

            # 查找 [接受所有 Cookie] 按钮
            onetrust_elem = find_element_unique(self.driver, By.ID, "onetrust-accept-btn-handler")
            if onetrust_elem:
                try_click_element(self.driver, onetrust_elem)
                logger.info(f"[binance_alpha] 已点击 [接受所有 Cookie] 按钮")


            # 香港IP登录提示框
            binance_hk_compliance_popup_proceed_elem = find_element_unique(self.driver, By.ID, "binance_hk_compliance_popup_proceed")
            if binance_hk_compliance_popup_proceed_elem:
                try_click_element(self.driver, binance_hk_compliance_popup_proceed_elem)
                logger.info(f"[binance_alpha] 已点击 【我知道了】 按钮")

        return True

    # 购买功能，返回True表示购买成功，False表示购买失败
    def _buy_coin(self):
        # 获取 role="dialog" 的 div 元素
        dialog_div = self._get_dialog_div(timeout_seconds=10)
        if not dialog_div:
            logger.error(f"[binance_alpha] _buy_coin 方法未找到 role='dialog' 的 div 元素")
            return False

        # 判断是否有下单手滑弹窗
        self._check_order_misclick_dialog()
        is_confirm_buy = self._check_confirm_buy_dialog()
        if not is_confirm_buy:
            return False

        
        return self._check_mfa_shadow_host_dialog()
    
    # 判断是否有mfa_shadow_host提示框
    def _check_mfa_shadow_host_dialog(self):
        # 判断是否输入google authenticator 验证码
        ret = self._check_google_authenticator_dialog()
        if ret == TradeAction.VERIFIED or ret == TradeAction.NOT_TIP_DIALOG:
            return True


        # 判断是否有mfa_option_box安全验证框提示框
        ret = self._check_mfa_option_box_dialog()
        if ret == TradeAction.VERIFIED or ret == TradeAction.NOT_TIP_DIALOG:
            return True

        # 有时Google 验证还是没有检查到，再检查一次
        ret = self._check_google_authenticator_dialog()
        if ret == TradeAction.VERIFIED or ret == TradeAction.NOT_TIP_DIALOG:
            return True

        # 未知框提示
        self._tip_human_verification_dialog()
        return False

        
    # 判断是否存在需要人工验证的弹窗
    def _tip_human_verification_dialog(self):
        screenshot_path = self._capture_screenshot()
        logger.error(f"[binance_alpha] 出现未知的弹窗，可能需要人工干预_get_mfa_shadow_host(): 截图路径：{screenshot_path}")
        ScriptSignal.script_warning.emit(self.config_id, "出现未知的弹窗")
        self.notify_event(NotifyType.HUMAN_VERIFICATION)
        self.sleep(UNVERIFIED_STOP_TIMEOUT)


    # 判断是否安全验证（手机和人脸）
    def _check_mfa_option_box_dialog(self):
        mfa_shadow_elem = self._get_mfa_shadow_host()
        if not mfa_shadow_elem:
            return TradeAction.NOT_TIP_DIALOG

        mfa_option_box_elem = find_shadow_element_by_selector(
            self.driver,
            mfa_shadow_elem,
            'div[class="mfa-option-box"]'
        )

        if not mfa_option_box_elem:
            return TradeAction.YES_TIP_DIALOG

        ScriptSignal.script_warning.emit(self.config_id, "安全验证，请人工介入")
        # TODO:邮件通知
        for i in range(5*60):
            mfa_shadow_elem = self._get_mfa_shadow_host()
            if not mfa_shadow_elem:
                return TradeAction.VERIFIED
            try:
                if self.driver_session.loop_thread_stop_event.is_set():
                    return TradeAction.YES_TIP_DIALOG
            except Exception as e:
                logger.error(f"[binance_alpha] 判断安全验证框出错: {e} traceback: {traceback.format_exc()}")
                return TradeAction.YES_TIP_DIALOG
            self.sleep(1)

    # 获取 mfa-shadow-host 的 dialog 元素
    def _get_mfa_shadow_host(self):
        mfa_shadow_elem = find_element_unique(
            self.driver, 
            By.ID, 
            "mfa-shadow-host",
            5
        )
        return mfa_shadow_elem

    # 获取 role="presentation" 的 div 元素
    def _get_presentation_div(self, timeout_seconds=2):
        return find_element_unique(
            self.driver,
            By.XPATH,
            "//div[@role='presentation']",
            timeout_seconds
        )

    # 获取 role="dialog" 的 div 元素
    def _get_dialog_div(self, timeout_seconds=2):
        presentation_div = self._get_presentation_div(timeout_seconds)
        if not presentation_div:
            return None
        return find_element_unique(
            presentation_div,
            By.XPATH,
            ".//div[@role='dialog']"
        )

    # 判断是否有下单手滑弹窗
    def _check_order_misclick_dialog(self):
        logger.info(f"[binance_alpha] 开始判断是否有下单手滑弹窗")
        dialog_div = self._get_dialog_div()
        if not dialog_div:
            return False

        # 查找 class="bn-modal-confirm-title" 的元素
        confirm_title_elem = find_element_unique(
            dialog_div,
            By.XPATH,
            './/div[contains(@class, "bn-modal-confirm-title")]'
        )
        if not confirm_title_elem:
            return False

        confirm_title_text = confirm_title_elem.text
        order_misclick_warning = self.script_tag_config.get("order_misclick_warning")
        if confirm_title_text == order_misclick_warning:
            
            # 查找 class=bn-button__primary 的 button
            primary_btn = find_element_unique(
                dialog_div,
                By.XPATH,
                './/button[contains(@class, "bn-button__primary")]'
            )
            if primary_btn and primary_btn.is_displayed():
                try_click_element(dialog_div, primary_btn)
                logger.info(f"[binance_alpha] 已点击下单手滑弹窗的主按钮")
                return True
        return False

    # 点击确认购买提示框，true表示确认购买，false表示没有确认购买提示框
    def _check_confirm_buy_dialog(self):
        logger.info(f"[binance_alpha] 开始判断是否输入确认购买提示框")
        dialog_div = self._get_dialog_div()
        if not dialog_div:
            return False

        # 查找 class="value text-Buy" 的元素
        value_text_buy_elem = find_element_unique(
            dialog_div,
            By.XPATH,
            './/div[contains(@class, "value") and contains(@class, "text-Buy")]'
        )
        if not value_text_buy_elem:
            return False
        value_text_buy_text = value_text_buy_elem.text
        confirm_buy_dialog_title = self.script_tag_config.get("confirm_buy_dialog_title")
        if value_text_buy_text == confirm_buy_dialog_title:
            # INSERT_YOUR_CODE
            primary_btn = find_element_unique(
                dialog_div,
                By.XPATH,
                './/button[contains(@class, "bn-button__primary")]'
            )
            if primary_btn and primary_btn.is_displayed():
                try_click_element(dialog_div, primary_btn)
                logger.info(f"[binance_alpha] 已点击确认购买提示框的主按钮")
                return True
        return False

    # 检查是否有谷歌验证码，返回是否交易完成，true表示交易完成，false表示交易未完成
    def _check_google_authenticator_dialog(self):
        logger.info(f"[binance_alpha] 开始判断是否输入google authenticator 验证码")

        mfa_shadow_elem = self._get_mfa_shadow_host()
        if not mfa_shadow_elem:
            return TradeAction.NOT_TIP_DIALOG

        # ================判断是否在Google验证码提示输入框================
        bidscl_body2secondary = find_shadow_element_by_selector(
            self.driver,
            mfa_shadow_elem,
            'label[class="bn-formItem-label"]'
        )
        google_authenticator_dialog_title = self.script_tag_config.get("google_authenticator_dialog_title")
        if not bidscl_body2secondary or bidscl_body2secondary.text != google_authenticator_dialog_title:
            return TradeAction.YES_TIP_DIALOG


        # 查找输入验证码框
        mfa_input_elem = find_shadow_element_by_selector(
            self.driver,
            mfa_shadow_elem,
            'input[data-e2e="input-mfa"]'
        )
        if not mfa_input_elem:
            return TradeAction.YES_TIP_DIALOG

        if not self.authenticator or self.authenticator.strip() == "":
            logger.error(f"[binance_alpha] 帐号:{self.config_id}未配置Google Authenticator，交易失败")
            ScriptSignal.script_warning.emit(self.config_id, "未配置Authenticator")
            self.notify_event(NotifyType.NO_GOOGLE_AUTH)
            self.clear()
            return TradeAction.YES_TIP_DIALOG


        for i in range(1):
            try:
                # 输入验证码
                self.sleep(random.uniform(1, 2))
                totp_code = get_totp_code(self.authenticator)
                if not totp_code or totp_code.strip() == "":
                    ScriptSignal.script_warning.emit(self.config_id, "Authenticator配置错误")
                    return TradeAction.YES_TIP_DIALOG
                set_input_value_with_actions(self.driver, mfa_input_elem, totp_code)
                self.sleep(random.uniform(1, 2))

                # # 查找是否输出验证码错误提示
                # err_div = find_shadow_element_by_selector(
                #     self.driver,
                #     mfa_shadow_elem,
                #     'div[class="bn-formItem-errMsg"]'
                # )
                # if err_div:
                #     logger.error(f"[binance_alpha] 检测到验证码错误提示: " + err_div.text)
                #     self.sleep(random.uniform(1, 3))
                #     continue

                logger.info(f"[binance_alpha] 输入Google Authenticator验证码成功")
                return TradeAction.VERIFIED
            except Exception as e:
                logger.error(f"[binance_alpha] 输入Google Authenticator验证码失败: {e}")
                continue

        logger.error(f"[binance_alpha] 输入Google Authenticator验证码失败")
        ScriptSignal.script_warning.emit(self.config_id, "输入Google Authenticator验证码失败")
        return TradeAction.YES_TIP_DIALOG

    # 检查订单是否成功，并统计积分
    def _check_order_success_alert(self):
        self._check_pending_orders()
        is_sell = self._check_sell_orders()
        if is_sell:
            self._sell_alpha_coin()

        self._calculate_points()

    # 获得委托订单列表div
    def _get_curr_bn_web_table_body_div(self):
        # 查找【交易订单】面板元素
        pending_orders_div = find_element_unique(
            self.driver,
            By.XPATH,
            '//div[@data-layout-path="/r0/ts1/t0"]'
        )
        if not pending_orders_div:
            logger.error(f"[binance_alpha] 未找到 【交易订单】 的元素")
            return None

        # 点击【当前委托】订单标签
        order_tab_elem = find_element_unique(
            pending_orders_div,
            By.ID,
            "bn-tab-orderOrder"
        )
        if not order_tab_elem:
            logger.error(f"[binance_alpha] 未找到 【当前委托】 的元素")
            return None

        try_click_element(pending_orders_div, order_tab_elem)
        logger.info(f"已点击【当前委托】订单标签")


        # 点击【限价】标签
        limit_tab_elem = find_element_unique(
            pending_orders_div,
            By.ID,
            "bn-tab-limit"
        )
        if not limit_tab_elem:
            logger.error(f"[binance_alpha] 未找到 【限价】 的元素")
            return None

        # 查找ID为 bn-tab-pane-orderOrder 的元素
        bn_tab_pane_order_order_elem = find_element_unique(
            pending_orders_div,
            By.ID,
            "bn-tab-pane-orderOrder"
        )
        if not bn_tab_pane_order_order_elem:
            logger.error(f"[binance_alpha] 未找到 ID为 bn-tab-pane-orderOrder 的元素")
            return None

        # 获取 【订单列表】元素
        bn_web_table_body_div = find_element_unique(
            bn_tab_pane_order_order_elem,
            By.XPATH,
            './/div[contains(@class, "bn-web-table-body")]'
        )

        return bn_web_table_body_div

    # 判断是否有待处理的委托订单,如果有就取消
    def _check_pending_orders(self, loop_count = 6):
        # 获取 【订单列表】元素
        bn_web_table_body_div = self._get_curr_bn_web_table_body_div()
        if not bn_web_table_body_div:
            logger.error(f"[binance_alpha] 未找到 【订单列表】 的元素")
            return False

        
        # 一次性用一个xpath查询所有role="row"的tr，其下第4列td内容为"买入"
        buy_order_text = self.script_tag_config.get("buy_order_text")
        result_row = None
        for i in range(loop_count):
            # 先查找所有role="row"的tr
            # 可以写成一条xpath，直接定位到第4列内容为"买入"的所有tr
            result_row = find_element_unique(
                bn_web_table_body_div,
                By.XPATH,
                # normalize-space(text()) 只会匹配td的“纯文本”内容，如果td下有<span>等标签，则这些内容也会被合并到text()中并被normalize-space计算。也就是说，它会忽略HTML标签，只取所有子元素合并后的文本，所以如果buy_order_text正好和td“显示出来的所有文本”一致，则匹配成功。
                f'.//tr[@role="row"][./td[@aria-colindex="4" and normalize-space(.)="{buy_order_text}"]]'
            )
            if not result_row:
                break
            self.sleep(1)

        if not result_row:
            return True

        # 获取 aria-colindex=9 的 td 元素下的 svg
        td_elem = find_element_unique(
            result_row,
            By.XPATH,
            './/td[@aria-colindex="9"]'
        )
        svg_elems = None
        if td_elem is not None:
            svg_elems = find_elements_with_timeout(
                td_elem,
                By.TAG_NAME,
                'svg'
            )
        if svg_elems:
            svg_elem = svg_elems[-1]
            try_click_element(td_elem, svg_elem)
            logger.info(f"[binance_alpha] 已点击 【取消买入委托】按钮")
            self.sleep(random.uniform(0.5,1))
            self._check_pending_orders(loop_count = 1)

        return True

    # 检查卖出委托订单
    def _check_sell_orders(self):
        # 获得row
        def _get_order_rows():
            # 获取 【订单列表】元素
            bn_web_table_body_div = self._get_curr_bn_web_table_body_div()
            if not bn_web_table_body_div:
                logger.error(f"[binance_alpha] 未找到 【订单列表】 的元素")
                return False

            # 一次性用一个xpath查询所有role="row"的tr，其下第4列td内容为"买入"
            sell_order_text = self.script_tag_config.get("sell_order_text")
            result_rows = find_elements_with_timeout(
                bn_web_table_body_div,
                By.XPATH,
                # normalize-space(text()) 只会匹配td的“纯文本”内容，如果td下有<span>等标签，则这些内容也会被合并到text()中并被normalize-space计算。也就是说，它会忽略HTML标签，只取所有子元素合并后的文本，所以如果buy_order_text正好和td“显示出来的所有文本”一致，则匹配成功。
                f'.//tr[@role="row"][./td[@aria-colindex="4" and normalize-space(.)="{sell_order_text}"]]'
            )

            return result_rows

        def _check_sell_orders_func():
            result_rows = _get_order_rows()
            if not result_rows:
                return False

            # 获取 aria-colindex=9 的 td 元素下的 svg
            td_elem = find_element_unique(
                result_rows[-1],
                By.XPATH,
                './/td[@aria-colindex="9"]'
            )
            svg_elems = None
            if td_elem is not None:
                svg_elems = find_elements_with_timeout(
                    td_elem,
                    By.TAG_NAME,
                    'svg'
                )

            if svg_elems:
                svg_elem = svg_elems[-1]
                try_click_element(td_elem, svg_elem)
                logger.info(f"[binance_alpha] 已点击 【取消卖出委托】按钮")
                self.sleep(random.uniform(1,1.5))
                return True
            return False

        is_sell = False
        loop_num = 3
        rows = _get_order_rows()
        if rows and len(rows)>=loop_num:
            self.notify_event(NotifyType.ORDER_ACCUMULATED)
            for i in range(loop_num):
                is_sell_ = _check_sell_orders_func()
                if(is_sell_):
                    is_sell = True
        return is_sell

    # 计算积分
    def _calculate_points(self):
        # 查找【交易订单】面板元素
        pending_orders_div = find_element_unique(
            self.driver,
            By.XPATH,
            '//div[@data-layout-path="/r0/ts1/t0"]'
        )
        if not pending_orders_div:
            logger.error(f"[binance_alpha] 未找到 【交易订单】 的元素")
            return None

        
        # 点击【历史委托】按钮
        order_history_elem = find_element_unique(
            pending_orders_div,
            By.ID,
            "bn-tab-orderHistory"
        )
        if not order_history_elem:
            logger.error(f"[binance_alpha] 未找到 【订单历史】 的元素")
            return False
        try_click_element(pending_orders_div, order_history_elem)
        logger.info(f"[binance_alpha] 已点击 【历史委托】 的按钮")

        self.sleep(random.uniform(0.5, 1))
        

        trd_order_history_elem = find_element_unique(
            pending_orders_div,
            By.ID,
            "trd-order-history"
        )
        if not trd_order_history_elem:
            logger.error(f"[binance_alpha] 未找到 id=trd-order-history 的元素")
            return False

        # 点击【即时】按钮
        div_elem = find_element_unique(
            trd_order_history_elem,
            By.ID,
            "bn-tab-0"
        )
        if not div_elem:
            logger.error(f"[binance_alpha] 未找到【即时】按钮")
        try_click_element(trd_order_history_elem, div_elem)
        logger.info(f"[binance_alpha] 已点击 【即时】 的按钮")

        self.sleep(2)

        # --------------------------------------------------------
        # 查找 【标题头】thead元素
        thead_elem = find_element_unique(
            trd_order_history_elem,
            By.XPATH,
            ".//thead[contains(@class, 'bn-web-table-thead')]"
        )
        if not thead_elem:
            logger.error(f"[binance_alpha] 未找到 【标题头】thead 元素")
            return False
        
        # 查找【方向】筛选按钮
        dire_div = find_element_unique(
            thead_elem,
            By.XPATH,
            ".//th[@aria-colindex='4']/div"
        )
        if not dire_div:
            logger.error(f"[binance_alpha] 未找到 【方向】div")
            return False

        # 方向 按钮
        first_child_div = find_element_unique(dire_div, By.XPATH, "./div[1]")
        if not first_child_div:
            logger.error(f"[binance_alpha] 未找到 【方向】div 下的第一个 div")
            return False
        try_click_element(dire_div, first_child_div)
        logger.info(f"[binance_alpha] 已点击 【方向】按钮")

        # 方向弹出框
        second_child_div = find_element_unique(dire_div, By.XPATH, "./div[2]")
        if not second_child_div:
            logger.error(f"[binance_alpha] 未找到 【方向】div 下的第二个 div")
            return False

        # 点击【买】筛选按钮
        second_hover_bg_line_elem = find_element_unique(
            second_child_div,
            By.XPATH,
            "(.//div[contains(@class, 'hover:bg-Line')])[2]"
        )
        if not second_hover_bg_line_elem:
            logger.error(f"[binance_alpha] 未找到【买】筛选按钮")
            return False

        try_click_element(second_child_div, second_hover_bg_line_elem)
        logger.info(f"[binance_alpha] 已点击 【买】筛选按钮")


        # 查找【状态】筛选按钮
        status_div = find_element_unique(
            thead_elem,
            By.XPATH,
            ".//th[@aria-colindex='11']/div"
        )
        if not status_div:
            logger.error(f"[binance_alpha] 未找到 【状态】div")
            return False

        # 方向 按钮
        first_child_div = find_element_unique(status_div, By.XPATH, "./div[1]")
        if not first_child_div:
            logger.error(f"[binance_alpha] 未找到 【状态】div 下的第一个 div")
            return False
        try_click_element(status_div, first_child_div)
        logger.info(f"[binance_alpha] 已点击 【状态】按钮")

        # 状态弹出框
        second_child_div = find_element_unique(status_div, By.XPATH, "./div[2]")
        if not second_child_div:
            logger.error(f"[binance_alpha] 未找到 【状态】div 下的第二个 div")
            return False



        # 点击【已过期，已取消，已拒绝】筛选按钮
        second_hover_bg_line_elems = find_elements_with_timeout(
            second_child_div,
            By.XPATH,
            ".//div[@role='checkbox']"
        )
        if not second_hover_bg_line_elems:
            logger.error(f"[binance_alpha] 未找到【买】筛选按钮")
            return False

        try:
            for row in second_hover_bg_line_elems[3:]:
                aria_checked = row.get_attribute("aria-checked")
                if aria_checked == "true":
                    try_click_element(second_child_div, row)
        except Exception as e:
            logger.error(f"[binance_alpha] 点击【已过期，已取消，已拒绝】筛选按钮失败")
            return False
        # --------------------------------------------------------

        # 计算积分
        # 查找已成效的订单
        row_elems = find_elements_with_timeout(
            trd_order_history_elem,
            By.XPATH,
            ".//tbody[contains(@class, 'bn-web-table-tbody')]/tr[@role='row']"
        )
        if not row_elems:
            logger.error(f"[binance_alpha] 未找到【已成交】的订单")
            return False

        total_amount = 0
        total_score = 0
        last_order_id = 0
        trade_data = FileOper.get_trade_data_by_id(self.config_id)
        if trade_data:
            last_order_id = int(trade_data.get("last_order_id", 0))
        
        last_order_id_new = 0
        try:
            for row in row_elems:
                data_row_key = 0
                try:
                    data_row_key = int(row.get_attribute("data-row-key"))
                except Exception as e:
                    continue
                
                if last_order_id != 0 and last_order_id >= data_row_key:
                    break

                td_elem = find_element_unique(row, By.XPATH, './/td[@aria-colindex="9"]')
                if td_elem:

                    # 在td_elem下面查找 aria-colindex="1" 的单元格，并取到内容
                    col1_elem = find_element_unique(row, By.XPATH, './/td[@aria-colindex="1"]')
                    try:
                        col1_text = col1_elem.text
                        dt_obj = smart_parse_datetime(col1_text.strip(), self.timezone)
                        if dt_obj is None:
                            logger.error(f"[binance_alpha] 时间格式解析失败: {col1_text}")
                            break

                        # 判断14:00
                        if not self.is_in_same_14_to_14_period(dt_obj):
                            break

                    except Exception as e:
                        logger.error(f"获取【历史委托】订单的时间出错 {e}")
                        break

                    if last_order_id_new == 0:
                        last_order_id_new = data_row_key

                    _total_amount = safe_float(td_elem.text)
                    _total_score = _total_amount*self.points_multiplier
                    total_amount += _total_amount
                    total_score += _total_score

        except Exception as e:
            logger.error(f"[binance_alpha] 【已成交】订单列表发生变化")

        # 保存积分数据到文件
        is_ok = FileOper.update_trade_data_by_id(self.config_id, 
            total_score=trade_data.get("total_score", 0)+total_score, 
            total_amount=trade_data.get("total_amount", 0)+total_amount, 
            last_order_id=max(last_order_id_new, trade_data.get("last_order_id", 0)))
        if not is_ok:
            logger.error(f"[binance_alpha] 保存积分数据失败")

        total_score_new = total_score + trade_data.get("total_score", 0)
        ScriptSignal.score_changed.emit(self.config_id, total_score_new, self.total_points_stop)


        # 达到积分，关闭脚本
        if total_score_new > 0 and total_score_new >= self.total_points_stop:
            logger.info(f"[binance_alpha] 达到总积分")
            ScriptSignal.script_warning.emit(self.config_id, "达到总积分")
            wait_reload_page_ready(self.driver)
            self.sleep(15)
            self._cancel_all_orders()
            self._sell_alpha_coin()
            self.notify_event(NotifyType.TRADE_COMPLETED)
            self.clear();

        return True


    def is_in_same_14_to_14_period(self, dt_obj) -> bool:
        """
        判断给定的时间 dt_obj 是否和当前时间属于同一个"自今日14:00起至次日14:00止"的区间。
        也即，每天14:00-次日14:00为一天，非自然日。
        """
        from datetime import timedelta
        now = get_now()  # 使用 UTC+8 时区
        # 计算当前区间的开始和结束时间
        if now.hour >= 14:
            period_start = now.replace(hour=14, minute=0, second=0, microsecond=0)
            period_end = period_start.replace(day=now.day) + timedelta(days=1)
        else:
            period_end = now.replace(hour=14, minute=0, second=0, microsecond=0)
            period_start = period_end - timedelta(days=1)
        return period_start <= dt_obj < period_end


    # 取消所有订单
    def _cancel_all_orders(self):
        # 在ID为"__APP"的元素下，查找class为"flexlayout__tab"且data-layout-path="/r0/ts1/t0"的div
        flexlayout_tab_elem = find_element_unique(
            self.driver,
            By.XPATH,
            './/*[@id="__APP"]//div[contains(@class, "flexlayout__tab") and @data-layout-path="/r0/ts1/t0"]'
        )
        if not flexlayout_tab_elem:
            return False
        self.sleep(random.uniform(1, 2))
        # 使用一个xpath查找 flexlayout_tab_elem 下的 table/thead//div[@class="text-TextLink cursor-pointer"]

        for i in range(2):
            cancel_all_orders_btn = find_element_unique(
                flexlayout_tab_elem,
                By.XPATH,
                './/table/thead//div[@class="text-TextLink cursor-pointer"]'
            )
            if not cancel_all_orders_btn:
                logger.error(f"[binance_alpha] 未找到 【全部取消】订单功能按钮")
                return False

            self.sleep(random.uniform(1, 2))
            try_click_element(self.driver, cancel_all_orders_btn)
            logger.info(f"[binance_alpha] 已点击 【全部取消】订单功能按钮")

        # 点击确认取消
        dialog_div = self._get_dialog_div()
        if not dialog_div:
            logger.error(f"[binance_alpha] 未找到 确认取消订单对话框")
            return False
        primary_btn = find_element_unique(
            dialog_div,
            By.XPATH,
            './/button[contains(@class, "bn-button__primary")]'
        )
        if primary_btn:
            try_click_element(dialog_div, primary_btn)
            logger.info(f"[binance_alpha] 已点击 确认取消订单对话框的主按钮")
            self.sleep(random.uniform(1, 2))
            self._sell_alpha_coin()
        else:
            logger.error(f"[binance_alpha] 未找到 确认取消订单对话框的主按钮")
            return False

        return True

    # 出售Alpha币
    def _sell_alpha_coin(self):

        appid_elem = find_element_unique(self.driver, By.ID, "__APP")
        if not appid_elem:
            logger.error(f"[binance_alpha] 未找到 id=__APP 根元素 ")
            return False

        # 查找买卖面板元素
        flexlayout_tab_elem = find_element_unique(
            appid_elem,
            By.XPATH,
            './/div[contains(@class, "flexlayout__tab") and @data-layout-path="/r1/ts0/t0"]'
        )
        if not flexlayout_tab_elem:
            logger.error(f"[binance_alpha] 未找到买卖面板元素")
            return False

        # 查找【卖出】tab按钮
        bn_tab_sell_elem = find_element_unique(flexlayout_tab_elem, By.ID, "bn-tab-1")
        if not bn_tab_sell_elem:
            logger.error(f"[binance_alpha] 未找到 flexlayout_tab_elem 下的 id=bn-tab-1 的【卖出】元素")
            return False
        try_click_element(self.driver, bn_tab_sell_elem)
        logger.info(f"[binance_alpha] 已点击【卖出】元素")

        # 查找【限价】tab按钮
        bn_tab_instant_elem = find_element_unique(flexlayout_tab_elem, By.ID, "bn-tab-INSTANT")
        if not bn_tab_instant_elem:
            logger.error(f"[binance_alpha] 未找到 flexlayout_tab_elem 下的 id=bn-tab-LIMIT 的【限价】元素")
            return False
        try_click_element(self.driver, bn_tab_instant_elem)
        logger.info(f"[binance_alpha] 已点击【限价】元素")
        self.sleep(random.uniform(1, 2))
        # 查找 class="bn-slider-track" 的滑块轨道元素
        bn_slider_track_elem = find_element_unique(flexlayout_tab_elem, By.CLASS_NAME, "bn-slider-track")
        if not bn_slider_track_elem:
            logger.error(f"[binance_alpha] 未找到 flexlayout_tab_elem 下的 class=bn-slider-track 的滑块轨道元素")
            return False

        is_ok = simulate_horizontal_swipe(self.driver, bn_slider_track_elem)
        if not is_ok:
            logger.error(f"[binance_alpha] 滑动滑块轨道元素失败")
            return False
        logger.info(f"[binance_alpha] 已滑动滑块轨道元素")
        self.sleep(1)

        # 查找 class=bn-button__sell 的 button 元素
        bn_button_sell_elem = find_element_unique(flexlayout_tab_elem, By.CLASS_NAME, "bn-button__sell")
        if not bn_button_sell_elem:
            logger.error(f"[binance_alpha] 未找到【出售】按钮元素")
            return False
        
        is_ok = try_click_element(
            self.driver, 
            bn_button_sell_elem, 
            custom_wait_condition=lambda d, e: e.get_attribute("aria-disabled") is None
        )
        if not is_ok:
            logger.error(f"[binance_alpha] 点击 【出售】按钮失败")
            return False

        logger.info(f"[binance_alpha] 已点击 【出售】按钮")

        if not self._check_sell_checkbox_dialog():
            logger.info(f"[binance_alpha] 未找到 【出售】确认对话框,判断是否弹出google authenticator 验证码")
            if not self._check_mfa_shadow_host_dialog():
                pass
                # screenshot_path = self._capture_screenshot()
                # logger.error(f"[binance_alpha] 出售时弹出未知窗口截图: " + screenshot_path)
                # return False

        return True

    # 检查【出售】确认对话框
    def _check_sell_checkbox_dialog(self):
        dialog_div = self._get_dialog_div()
        if not dialog_div:
            return False
        self.sleep(random.uniform(3, 5))
        header_main_div = find_element_unique(
            dialog_div,
            By.CLASS_NAME,
            "bn-modal-header-main"
        )
        if not header_main_div:
            logger.error(f"[binance_alpha] 未找到 确认付款 提示框")
            return False

        confirm_sell_checkbox_dialog_title = self.script_tag_config.get("confirm_sell_checkbox_dialog_title")
        if header_main_div.text != confirm_sell_checkbox_dialog_title:
            logger.error(f"[binance_alpha] 未找到 确认付款 提示框")
            return False
        
        # INSERT_YOUR_CODE
        primary_btn = find_element_unique(
            dialog_div,
            By.CLASS_NAME,
            "bn-button__primary"
        )
        if not primary_btn:
            logger.error(f"[binance_alpha] 未找到 class=bn-button__primary 的元素")
            return False

        is_disabled = False
        try:
            disabled_attr = primary_btn.get_attribute("disabled")
            if disabled_attr is not None:
                is_disabled = True
        except Exception as e:
            logger.error(f"[binance_alpha] 检查primary_btn disabled属性时异常: {e}")
            is_disabled = True

        if is_disabled:
            # 查找是否有刷新按钮
            refresh_text = self.script_tag_config.get("refresh_text")    
            refresh_div = find_element_unique(
                dialog_div,
                By.XPATH,
                f".//div[normalize-space(text())='{refresh_text}' and count(*)=0]"
            )
            if not refresh_div:
                logger.error(f"[binance_alpha] 未找到只有“刷新”文本的div")
                return False
            try_click_element(self.driver, refresh_div)

        is_ok = try_click_element(
            self.driver,
            primary_btn,
            custom_wait_condition=lambda driver, elem: elem.get_attribute("disabled") is None
        )

        if not is_ok:
            logger.error(f"[binance_alpha] 点击 确认出售按钮失败")
            return False

        logger.info(f"[binance_alpha] 已点击 确认出售按钮")
        return True

    # 截图保存到 tmp/screenshots/{任务ID}/{年月日}/{时分秒}.png
    def _capture_screenshot(self):
        try:
            # 根据时间生成目录: tmp/screenshots/任务ID/年月日/
            config_id = getattr(self, "config_id", "unknown")
            now = get_now()  # 使用 UTC+8 时区
            date_str = now.strftime("%Y%m%d")
            time_str = now.strftime("%H%M%S")
            dir_path = os.path.join("tmp", "screenshots", config_id, date_str)
            if not os.path.exists(dir_path):
                os.makedirs(dir_path, exist_ok=True)
            file_path = os.path.join(dir_path, f"{time_str}.png")
            # 调用Selenium截图方法
            result = self.driver.save_screenshot(file_path)
            if result and os.path.exists(file_path):
                logger.info(f"[binance_alpha] 成功截取截图: {file_path}")
                return file_path
            else:
                logger.error(f"[binance_alpha] 截图失败")
                return None
        except Exception as e:
            logger.error(f"[binance_alpha] 截图异常: {e}")
            return None

    # 通知事件
    def notify_event(self, notify_type: NotifyType, info: str = ""):
        now = time.time()

        # 检查是否在时间间隔内
        last_time = self._last_notify_times.get(notify_type, 0)
        interval = NOTIFY_INTERVAL.get(notify_type, 20 * 60)  # 默认20分钟
        if now - last_time < interval:
            return

        # 更新时间戳
        self._last_notify_times[notify_type] = now

        # 根据不同类型发送不同的通知
        if notify_type == NotifyType.HUMAN_VERIFICATION:
            subject = "[TaskManagerPro] [币安Alpha] 需要人工验证"
            content = f"任务: {self.config_id} 名称: {self.config.name} 遇到安全验证/人工介入：{info}\n请及时处理！"
            send_email(subject, content)
            logger.info(f"[binance_alpha] 已发送人工验证邮件通知")
        elif notify_type == NotifyType.NETWORK:
            subject = "[TaskManagerPro] [币安Alpha] 网络异常通知"
            content = f"任务: {self.config_id} 名称: {self.config.name} 检测到网络异常（服务器无法连接），请检查网络。"
            send_email(subject, content)
            logger.info(f"[binance_alpha] 已发送网络异常邮件通知")
        elif notify_type == NotifyType.LOGIN:
            subject = "[TaskManagerPro] [币安Alpha] 登录状态丢失通知"
            content = f"任务: {self.config_id} 名称: {self.config.name} 检测到登录状态丢失（需要登录 Binance），请前往操作。"
            send_email(subject, content)
            logger.info(f"[binance_alpha] 已发送登录失效邮件通知")
        elif notify_type == NotifyType.NO_MONEY:
            subject = "[TaskManagerPro] [币安Alpha] 余额不足通知"
            content = f"任务: {self.config_id} 名称: {self.config.name} 检测到可用余额不足，无法完成交易，请及时充值或人工处理。"
            send_email(subject, content)
            logger.info(f"[binance_alpha] 已发送余额不足邮件通知")

        elif notify_type == NotifyType.TRADE_COMPLETED:
            subject = "[TaskManagerPro] [币安Alpha] 交易完成通知"
            content = f"任务: {self.config_id} 名称: {self.config.name} 交易完成。"
            send_email(subject, content)
            logger.info(f"[binance_alpha] 已发送交易完成邮件通知")
        elif notify_type == NotifyType.ABNORMAL_EXIT:
            subject = "[TaskManagerPro] [币安Alpha] 异常退出通知"
            content = f"任务: {self.config_id} 名称: {self.config.name} 异常退出。"
            send_email(subject, content)
            logger.info(f"[binance_alpha] 已发送异常退出邮件通知")
        elif notify_type == NotifyType.ORDER_ACCUMULATED:
            subject = "[TaskManagerPro] [币安Alpha] 订单累积通知"
            content = f"任务: {self.config_id} 名称: {self.config.name} 出售订单累积，请查代币是否价格波动太大或设置下浮出售价格太小"
            send_email(subject, content)
            logger.info(f"[binance_alpha] 已发送订单累积邮件通知")
        elif notify_type == NotifyType.NO_GOOGLE_AUTH:
            subject = "[TaskManagerPro] [币安Alpha] 没有设置谷歌认证，交易停止通知"
            content = f"任务: {self.config_id} 名称: {self.config.name} 没有谷歌认证。"
            send_email(subject, content)
            logger.info(f"[binance_alpha] 已发送没有谷歌认证邮件通知")

    # 循环事件
    def run(self, driver_session: DriverSession):
        try:
            # self._init_from_config(driver_session=driver_session)

            # 浏览器存活探测
            if not is_driver_alive(self.driver):
                self.clear();
                return False
            
            # 如果当前没有加载任何网页或不是Binance账户页，则跳转
            if is_blank_page(self.driver) or not url_contains(self.driver, BASE_URL):
                driver_get(self.driver, LOGIN_URL)
                return True

            # 网络连接检测
            if not check_network_connection(self.driver):
                ScriptSignal.script_warning.emit(self.config_id, "网络异常")
                logger.error(f"[binance_alpha] 网络连接异常，等待重试")
                self.notify_event(NotifyType.NETWORK)
                self.sleep(3)
                return True

            # 判断如果未登录就跳转登录UI
            is_login = get_cookie_value(self.driver, "p20t")
            if not is_login and not url_contains(self.driver, LOGIN_URL):
                driver_get(self.driver, LOGIN_URL)

            # 如果当前页面是Binance账户页，做登录逻辑
            if url_contains(self.driver, LOGIN_URL):
                self._login()
                return True

            if url_contains(self.driver, self.trade_url, ignore_scheme=True):
                # 5次订单成功刷一次UI，连接出错2次也刷一次UI，防止卡顿
                is_ok = self._trade()
                if is_ok:
                    self.buy_error_counter = 0
                    self.buy_success_counter += 1
                    self.sell_event_counter += 1
                    if self.buy_success_counter >= 10:
                        wait_reload_page_ready(self.driver)
                        self.buy_success_counter = 0
                        self.buy_error_counter = 0
                else:
                    self.buy_error_counter += 1
                    if self.buy_error_counter >= 2:
                        wait_reload_page_ready(self.driver)
                        self.buy_success_counter = 0
                        self.buy_error_counter = 0

                if self.sell_event_counter % 50 == 0:
                    self.buy_error_counter = 0
                    self.buy_success_counter = 0
                    wait_reload_page_ready(self.driver)
                    self.sleep(3)
                    self._sell_alpha_coin()

            else:
                driver_get(self.driver, self.trade_url)
        except Exception as e:
            logger.error(f"[binance_alpha] 循环事件出错: {e} traceback: {traceback.format_exc()}")
        return True

    # 睡眠
    def sleep(self, timeout: float) -> bool:
        try:
            self.driver_session.loop_thread_stop_event.wait(timeout)
        except Exception as e:
            logger.error(f"[binance_alpha] 睡眠出错: {e} traceback: {traceback.format_exc()}")
            return False
        return True

    # 清理脚本
    def clear(self):
        DriverManager.stop(self.config_id)
        return True

def return_script_instance(driver_session: DriverSession):
    return BinanceAlpha(driver_session=driver_session)

