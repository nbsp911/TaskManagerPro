

from PySide6.QtCore import QObject, Signal
from data_type import DriverSessionStatus
from data_type import ProxyConfig
from data_type import ConfigData
from data_type import ProxyStatus, ProxyTestStatus

from typing import Optional

class DriverManagerSignalBridge(QObject):
    # DriverSession 状态改变信号 (config_id, prev_status, new_status)
    status_changed = Signal(str, DriverSessionStatus, DriverSessionStatus)

class ProxyManagerSignalBridge(QObject):
    proxy_added = Signal(ProxyConfig)
    proxy_updated = Signal(ProxyConfig)
    proxy_deleted = Signal(ProxyConfig)
    proxy_status_changed = Signal(str, ProxyStatus)         # 代理状态改变信号 (proxy_id, status)
    proxy_latency_tested = Signal(str, float, object, object, str)     # 代理延迟测速信号 (proxy_id, latency, status, test_status, response_content)

class ConfigDataSignalBridge(QObject):
    config_added = Signal(ConfigData)
    config_updated = Signal(ConfigData)
    config_deleted = Signal(ConfigData)


class ScriptSignalBridge(QObject):
    script_warning = Signal(str, str)           # 警告信息：config_id, desc
    score_changed = Signal(str, int, int)       # 积分变化：config_id, score, total_points_stop


class LicenseSignalBridge(QObject):
    license_status_changed = Signal(str, int)     # 许可证状态改变：status, days_left

ConfigDataSignal = ConfigDataSignalBridge()
DriverManagerSignal = DriverManagerSignalBridge()
ProxyManagerSignal = ProxyManagerSignalBridge()
ScriptSignal = ScriptSignalBridge()
LicenseSignal = LicenseSignalBridge()