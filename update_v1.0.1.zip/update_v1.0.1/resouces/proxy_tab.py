

import threading
import time
from typing import Optional

from PySide6.QtCore import Qt, QObject, Signal, QTimer

# 表格列索引常量
COL_COUNT = 7     # 总列数
COL_NAME = 0      # 名称
COL_SERVER_INFO = 1  # 服务器信息(类型+服务器)
COL_REGION = 2    # 地区
COL_IP = 3        # IP地址
COL_TIMEZONE = 4  # 时区
COL_LATENCY = 5   # 延迟(ms)
COL_ACTIONS = 6   # 操作

# 延迟阈值常量
LATENCY_TIMEOUT_THRESHOLD = 10000  # 延迟超时阈值(毫秒)

# 测速参数常量
TEST_URL = "https://ipinfo.io/json"  # 测速URL
TEST_TIMEOUT = 8.0  # 测速超时时间(秒)
from PySide6.QtGui import QColor
from tools import qcolor_for_latency, format_latency_text
from PySide6.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QHBoxLayout,
    QHeaderView,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from data_type import ProxyConfig, ProxyStatus, ProxyTestStatus
from slot_events import ProxyManagerSignal
from chain_proxy.chain_proxy_manager import get_chain_proxy_manager
import logging
logger = logging.getLogger()

from file_oper import FileOper
import uuid



class AddProxyDialog(QDialog):
    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.setWindowTitle("手动添加代理")
        self.setModal(True)
        self.resize(380, 300)

        self.name_edit = QLineEdit()
        self.type_combo = QComboBox()
        self.type_combo.addItems(["http", "https", "socks5"])
        self.server_edit = QLineEdit()
        self.port_edit = QLineEdit()
        self.username_edit = QLineEdit()
        self.password_edit = QLineEdit()
        self.listen_port_edit = QLineEdit()
        self.listen_port_edit.setText("0")
        self.listen_port_edit.setPlaceholderText("0表示自动分配端口")
        self.port_forward_checkbox = QCheckBox()
        self.port_forward_checkbox.setChecked(True)  # 默认启用端口转发

        form_layout = QFormLayout()
        form_layout.addRow("名称", self.name_edit)
        form_layout.addRow("类型", self.type_combo)
        form_layout.addRow("服务器", self.server_edit)
        form_layout.addRow("端口", self.port_edit)
        form_layout.addRow("用户名", self.username_edit)
        form_layout.addRow("密码", self.password_edit)
        form_layout.addRow("监听端口", self.listen_port_edit)
        form_layout.addRow("端口转发", self.port_forward_checkbox)

        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)

        layout = QVBoxLayout(self)
        layout.addLayout(form_layout)
        layout.addWidget(button_box)

    def get_data(self) -> ProxyConfig:
        port_value = self.port_edit.text().strip()
        listen_port_value = self.listen_port_edit.text().strip()
        
        # 处理监听端口，0或空值表示自动分配
        listen_port = None
        if listen_port_value and listen_port_value != "0":
            try:
                listen_port = int(listen_port_value)
            except ValueError:
                listen_port = None
        
        return ProxyConfig(
            id=str(uuid.uuid4()),
            name=self.name_edit.text().strip() or f"节点-{int(time.time())}",
            type=self.type_combo.currentText(),
            server=self.server_edit.text().strip(),
            port=int(port_value) if port_value else 0,
            username=self.username_edit.text().strip() or None,
            password=self.password_edit.text().strip() or None,
            listen_port=listen_port,
            listen_host="127.0.0.1",
            timeout=30,
            max_connections=100,
            enabled=True,
            port_forward=self.port_forward_checkbox.isChecked(),  # 获取端口转发设置
            raw=None,
        )


class ProxyManagerTab(QWidget):
    def __init__(self, *, parent: QWidget | None = None):
        super().__init__(parent)
        self._latency_log_flags: dict[str, bool] = {}
        self._bulk_pending: set[str] = set()
        # 测速结果缓存
        self._speed_result_cache: dict[str, dict] = {}

        
        # 连接代理状态变化事件
        ProxyManagerSignal.proxy_status_changed.connect(self._on_proxy_status_changed)
        # 连接代理延迟测试事件
        ProxyManagerSignal.proxy_latency_tested.connect(self._on_proxy_latency_tested)

        self._setup_ui()
        self._refresh_proxy_table()
        
        # 设置自动测速定时器（10分钟 = 600000毫秒）
        self._auto_test_timer = QTimer()
        self._auto_test_timer.timeout.connect(self._auto_speed_test)
        self._auto_test_timer.start(600000)  # 10分钟

    def _setup_ui(self) -> None:
        layout = QVBoxLayout(self)

        button_row = QHBoxLayout()
        # 左侧：名称搜索
        self.search_edit = QLineEdit()
        try:
            self.search_edit.setPlaceholderText("按名称搜索...")
            self.search_edit.setFixedWidth(220)
        except Exception:
            pass
        button_row.addWidget(self.search_edit)
        # 右对齐操作按钮
        button_row.addStretch(1)
        self.proxy_add_button = QPushButton("添加代理")
        try:
            self.proxy_add_button.setFixedWidth(96)
        except Exception:
            pass
        self.proxy_test_button = QPushButton("全部测速")
        try:
            self.proxy_test_button.setFixedWidth(96)
        except Exception:
            pass
        button_row.addWidget(self.proxy_test_button)
        button_row.addWidget(self.proxy_add_button)
        layout.addLayout(button_row)

        self.proxy_table = QTableWidget(0, COL_COUNT)
        self.proxy_table.setHorizontalHeaderLabels([
            "名称",
            "服务器信息", 
            "地区",
            "IP地址",
            "时区",
            "延迟(ms)",
            "操作",
        ])
        self.proxy_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        try:
            # 设置操作列宽度
            self.proxy_table.horizontalHeader().setSectionResizeMode(COL_ACTIONS, QHeaderView.ResizeToContents)
            self.proxy_table.setColumnWidth(COL_ACTIONS, 330)
            
            # 设置延迟列宽度（较小）
            self.proxy_table.horizontalHeader().setSectionResizeMode(COL_LATENCY, QHeaderView.Interactive)
            self.proxy_table.setColumnWidth(COL_LATENCY, 80)
            
            # 设置服务器信息列宽度（较大）
            self.proxy_table.horizontalHeader().setSectionResizeMode(COL_SERVER_INFO, QHeaderView.Interactive)
            self.proxy_table.setColumnWidth(COL_SERVER_INFO, 200)
        except Exception:
            pass
        self.proxy_table.setSelectionBehavior(QTableWidget.SelectRows)
        self.proxy_table.setSelectionMode(QTableWidget.SingleSelection)
        self.proxy_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        layout.addWidget(self.proxy_table)

        self.proxy_add_button.clicked.connect(self._show_add_proxy_dialog)
        self.proxy_test_button.clicked.connect(self._test_all_proxies)
        self.search_edit.textChanged.connect(self._on_search_changed)

    # -------- 事件与功能 --------
    def _show_add_proxy_dialog(self) -> None:
        dialog = AddProxyDialog(parent=self)
        if dialog.exec() != QDialog.Accepted:
            return
        data = dialog.get_data()
        try:
            data.id = str(uuid.uuid4())
            is_success = FileOper.add_proxy_config(data)
            if is_success:
                logger.info(f" 已添加代理 {data.name}")
                
                # 将新代理添加到链式代理管理器
                chain_manager = get_chain_proxy_manager()
                if chain_manager:
                    add_success = chain_manager.add_proxy(data.id)
                    if add_success:
                        logger.info(f" 代理 {data.name} 已加入链式代理管理器")
                        # 只有当代理启用时才自动启动
                        if data.enabled:
                            start_success = chain_manager.start_proxy(data.id)
                            if start_success:
                                logger.info(f" 代理 {data.name} 已自动启动")
                            else:
                                logger.warning(f" 代理 {data.name} 启动失败")
                        else:
                            logger.info(f" 代理 {data.name} 已添加但未启动（已禁用）")
                        
                        # 只测速新添加的代理（只有在成功添加到链式代理管理器后才测速）
                        self._refresh_proxy_table(test_proxies=[data.id])
                    else:
                        logger.warning(f" 代理 {data.name} 加入链式代理管理器失败")
                        # 添加失败时不测速任何代理
                        self._refresh_proxy_table(test_proxies=[])
                else:
                    logger.warning(f" 链式代理管理器未初始化")
                    # 链式代理管理器未初始化时不测速任何代理
                    self._refresh_proxy_table(test_proxies=[])
            else:
                logger.warning(f" 添加代理失败 {data.name}")
                # 添加失败时不测速任何代理
                self._refresh_proxy_table(test_proxies=[])
        except Exception as exc:
            QMessageBox.critical(self, "添加失败", f"无法添加代理：{exc}")
            # 异常时也不测速任何代理
            self._refresh_proxy_table(test_proxies=[])

    def _delete_selected_proxy(self) -> None:
        proxy_id = self._get_selected_proxy_id()
        if not proxy_id:
            QMessageBox.warning(self, "提示", "请选择一个代理节点")
            return
        if FileOper.delete_proxy_config(proxy_id):
            logger.info(" 已删除代理节点")
            # 删除代理不需要测速
            self._refresh_proxy_table(test_proxies=[])

    def _test_all_proxies(self) -> None:
        # 异步触发全部节点测速，避免阻塞 UI
        chain_manager = get_chain_proxy_manager()
        if not chain_manager:
            logger.warning(" 链式代理管理器未初始化")
            return
            
        proxies = chain_manager.get_all_proxies()
        if not proxies:
            logger.warning(" 未找到可测速的节点")
            return
        try:
            self.proxy_test_button.setEnabled(False)
        except Exception:
            pass
        self._bulk_pending = {proxy_info.get('proxy_id', '') for proxy_info in proxies}
        # 先将 UI 置为"测试中"（红色）
        for proxy_info in proxies:
            proxy_id = proxy_info.get('proxy_id', '')
            row = self._find_row_by_proxy(proxy_id)
            if row is not None:
                # 更新延迟列
                latency_item = QTableWidgetItem("测试中")
                latency_item.setTextAlignment(Qt.AlignCenter)
                try:
                    latency_item.setForeground(QColor("#dc3545"))
                except Exception:
                    pass
                self.proxy_table.setItem(row, COL_LATENCY, latency_item)
                
                # 更新地区列
                region_item = QTableWidgetItem("测试中")
                region_item.setTextAlignment(Qt.AlignCenter)
                try:
                    region_item.setForeground(QColor("#dc3545"))
                except Exception:
                    pass
                self.proxy_table.setItem(row, COL_REGION, region_item)
                
                # 更新IP列
                ip_item = QTableWidgetItem("测试中")
                ip_item.setTextAlignment(Qt.AlignCenter)
                try:
                    ip_item.setForeground(QColor("#dc3545"))
                except Exception:
                    pass
                self.proxy_table.setItem(row, COL_IP, ip_item)
                
                # 更新时区列
                timezone_item = QTableWidgetItem("测试中")
                timezone_item.setTextAlignment(Qt.AlignCenter)
                try:
                    timezone_item.setForeground(QColor("#dc3545"))
                except Exception:
                    pass
                self.proxy_table.setItem(row, COL_TIMEZONE, timezone_item)
        # 并行发起异步测速
        for proxy_info in proxies:
            proxy_id = proxy_info.get('proxy_id', '')
            self._async_test_latency(proxy_id, log_result=False)

    def _auto_speed_test(self) -> None:
        """自动测速方法，由定时器调用"""
        logger.info(" 开始自动测速（每10分钟）")
        self._test_all_proxies()

    # -------- 表格与辅助 --------
    def _refresh_proxy_table(self, *, test_proxies: list[str] | None = None) -> None:
        # 使用链式代理管理器获取数据
        chain_manager = get_chain_proxy_manager()
        if not chain_manager:
            logger.warning(" 链式代理管理器未初始化")
            return
            
        proxies = chain_manager.get_all_proxies()
        
        # 记录测速策略
        if test_proxies is None:
            logger.info(" 刷新代理表格 - 将测速所有代理")
        elif len(test_proxies) == 0:
            logger.info(" 刷新代理表格 - 不测速任何代理")
        else:
            logger.info(f" 刷新代理表格 - 只测速指定代理: {test_proxies}")
        self.proxy_table.setRowCount(0)
        for proxy_info in proxies:
            row = self.proxy_table.rowCount()
            self.proxy_table.insertRow(row)
            
            # 获取代理配置信息
            config = proxy_info.get('config', {})
            proxy_id = proxy_info.get('proxy_id', '')
            
            # 名称列
            name_item = QTableWidgetItem(config.get('name', proxy_id))
            name_item.setData(Qt.UserRole, proxy_id)
            name_item.setTextAlignment(Qt.AlignVCenter | Qt.AlignLeft)
            self.proxy_table.setItem(row, COL_NAME, name_item)
            
            # 服务器信息列（类型+服务器）
            server_type = config.get('type', 'unknown')
            server_addr = config.get('server', '')
            server_port = config.get('port', '')
            server_info = f"{server_type}://{server_addr}:{server_port}"
            server_item = QTableWidgetItem(server_info)
            server_item.setTextAlignment(Qt.AlignCenter)
            self.proxy_table.setItem(row, COL_SERVER_INFO, server_item)
            
            # 根据是否需要测速决定初始显示内容
            will_test = test_proxies is None or proxy_id in test_proxies
            
            if will_test:
                # 需要测速的代理显示"测速中.."
                region_text = "测速中.."
                ip_text = "测速中.."
                timezone_text = "测速中.."
                latency_text = "测速中.."
                latency_color = QColor("#dc3545")  # 红色
                info_color = QColor("#dc3545")  # 红色
            else:
                # 不需要测速的代理从缓存获取之前的结果
                cached_result = self._speed_result_cache.get(proxy_id)
                if cached_result:
                    region_text = cached_result.get('region', '未测速')
                    ip_text = cached_result.get('ip', '未测速') 
                    timezone_text = cached_result.get('timezone', '未测速')
                    latency_text = cached_result.get('latency', '未测速')
                    latency_color = cached_result.get('latency_color', QColor("#6c757d"))
                    info_color = cached_result.get('info_color', QColor("#6c757d"))
                else:
                    # 没有缓存结果时显示"未测速"
                    region_text = "未测速"
                    ip_text = "未测速"
                    timezone_text = "未测速"
                    latency_text = "未测速"
                    latency_color = QColor("#6c757d")  # 灰色
                    info_color = QColor("#6c757d")  # 灰色
            
            # 地区列
            region_item = QTableWidgetItem(region_text)
            region_item.setTextAlignment(Qt.AlignCenter)
            try:
                region_item.setForeground(info_color)
            except Exception:
                pass
            self.proxy_table.setItem(row, COL_REGION, region_item)
            
            # IP地址列
            ip_item = QTableWidgetItem(ip_text)
            ip_item.setTextAlignment(Qt.AlignCenter)
            try:
                ip_item.setForeground(info_color)
            except Exception:
                pass
            self.proxy_table.setItem(row, COL_IP, ip_item)
            
            # 时区列
            timezone_item = QTableWidgetItem(timezone_text)
            timezone_item.setTextAlignment(Qt.AlignCenter)
            try:
                timezone_item.setForeground(info_color)
            except Exception:
                pass
            self.proxy_table.setItem(row, COL_TIMEZONE, timezone_item)
            
            # 延迟列
            latency_item = QTableWidgetItem(latency_text)
            latency_item.setTextAlignment(Qt.AlignCenter)
            try:
                latency_item.setForeground(latency_color)
            except Exception:
                pass
            self.proxy_table.setItem(row, COL_LATENCY, latency_item)
            # 行内操作：删除、修改、测速
            ops_widget = QWidget()
            ops_layout = QHBoxLayout(ops_widget)
            ops_layout.setContentsMargins(0, 0, 0, 0)
            ops_layout.setSpacing(8)
            ops_layout.setAlignment(Qt.AlignCenter)

            btn_delete = QPushButton("删除")
            try:
                btn_delete.setFixedSize(64, 26)
            except Exception:
                pass
            try:
                btn_delete.setCursor(Qt.PointingHandCursor)
            except Exception:
                pass
            self._style_button(btn_delete, "#6c757d", "#5a6268")
            btn_delete.clicked.connect(lambda _, pid=proxy_id: self._delete_proxy_with_confirm(pid))

            btn_edit = QPushButton("修改")
            try:
                btn_edit.setFixedSize(64, 26)
            except Exception:
                pass
            try:
                btn_edit.setCursor(Qt.PointingHandCursor)
            except Exception:
                pass
            self._style_button(btn_edit, "#007bff", "#0069d9")
            btn_edit.clicked.connect(lambda _, pid=proxy_id: self._edit_proxy(pid))

            btn_test = QPushButton("测速")
            try:
                btn_test.setFixedSize(64, 26)
            except Exception:
                pass
            try:
                btn_test.setCursor(Qt.PointingHandCursor)
            except Exception:
                pass
            self._style_button(btn_test, "#17a2b8", "#138496")
            btn_test.clicked.connect(lambda _, pid=proxy_id: self._test_one_proxy(pid))

            # 检查是否启用端口转发，只有启用端口转发才显示启动/停止按钮
            port_forward = config.get('port_forward', True)
            if port_forward:
                # 启动/停止按钮
                is_running = self._is_proxy_running(proxy_id)
                btn_text = "停止" if is_running else "启动"
                btn_color = "#dc3545" if is_running else "#28a745"  # 红色表示停止，绿色表示启动
                btn_hover_color = "#c82333" if is_running else "#218838"
                
                btn_start_stop = QPushButton(btn_text)
                try:
                    btn_start_stop.setFixedSize(64, 26)
                except Exception:
                    pass
                try:
                    btn_start_stop.setCursor(Qt.PointingHandCursor)
                except Exception:
                    pass
                self._style_button(btn_start_stop, btn_color, btn_hover_color)
                btn_start_stop.clicked.connect(lambda _, pid=proxy_id: self._toggle_proxy_status(pid))

                # 顺序：删除、修改、测速、启动/停止
                ops_layout.addWidget(btn_delete)
                ops_layout.addWidget(btn_edit)
                ops_layout.addWidget(btn_test)
                ops_layout.addWidget(btn_start_stop)
            else:
                # 不启用端口转发时，只显示：删除、修改、测速
                ops_layout.addWidget(btn_delete)
                ops_layout.addWidget(btn_edit)
                ops_layout.addWidget(btn_test)
            self.proxy_table.setCellWidget(row, COL_ACTIONS, ops_widget)
            # 根据参数决定是否测速
            if test_proxies is None or proxy_id in test_proxies:
                # 异步测速，避免阻塞 UI
                logger.debug(f" 触发测速: {proxy_id} (test_proxies={test_proxies})")
                self._async_test_latency(proxy_id, log_result=False)
            else:
                logger.debug(f" 跳过测速: {proxy_id} (test_proxies={test_proxies})")
        # 应用当前搜索过滤
        self._apply_table_filter()

    # ---- 样式工具 ----
    def _style_button(self, button: QPushButton, base_color: str, hover_color: str) -> None:
        style = f"""
            QPushButton {{
            background-color: {base_color};
            color: white;
            border-radius: 4px;
            border: 1px solid rgba(0,0,0,0.1);
            }}
            QPushButton:hover:!disabled {{
            background-color: {hover_color};
            }}
            QPushButton:disabled {{
            background-color: #9aa0a6;
            color: #f1f3f4;
            border: 1px solid rgba(0,0,0,0.05);
            }}
        """
        button.setStyleSheet(style)

    # ---- 行内操作 ----
    def _find_row_by_proxy(self, proxy_id: str) -> int | None:
        for row in range(self.proxy_table.rowCount()):
            item = self.proxy_table.item(row, COL_NAME)
            if item and item.data(Qt.UserRole) == proxy_id:
                return row
        return None

    def _test_one_proxy(self, proxy_id: str) -> None:
        row = self._find_row_by_proxy(proxy_id)
        if row is not None:
            # 更新延迟列
            latency_item = QTableWidgetItem("测速中..")
            latency_item.setTextAlignment(Qt.AlignCenter)
            try:
                latency_item.setForeground(QColor("#dc3545"))
            except Exception:
                pass
            self.proxy_table.setItem(row, COL_LATENCY, latency_item)
            
            # 更新地区列
            region_item = QTableWidgetItem("测速中..")
            region_item.setTextAlignment(Qt.AlignCenter)
            try:
                region_item.setForeground(QColor("#dc3545"))
            except Exception:
                pass
            self.proxy_table.setItem(row, COL_REGION, region_item)
            
            # 更新IP列
            ip_item = QTableWidgetItem("测速中..")
            ip_item.setTextAlignment(Qt.AlignCenter)
            try:
                ip_item.setForeground(QColor("#dc3545"))
            except Exception:
                pass
            self.proxy_table.setItem(row, COL_IP, ip_item)
            
            # 更新时区列
            timezone_item = QTableWidgetItem("测速中..")
            timezone_item.setTextAlignment(Qt.AlignCenter)
            try:
                timezone_item.setForeground(QColor("#dc3545"))
            except Exception:
                pass
            self.proxy_table.setItem(row, COL_TIMEZONE, timezone_item)
        self._async_test_latency(proxy_id, log_result=True)

    def _edit_proxy(self, proxy_id: str) -> None:
        proxy = FileOper.get_proxy_config_by_id(proxy_id)
        if not proxy:
            QMessageBox.warning(self, "提示", "未找到该代理")
            return
        dialog = AddProxyDialog(parent=self)
        dialog.setWindowTitle("修改代理")
        try:
            dialog.name_edit.setText(proxy.name or "")
            dialog.type_combo.setCurrentText(proxy.type or "http")
            dialog.server_edit.setText(proxy.server or "")
            dialog.port_edit.setText(str(proxy.port or ""))
            dialog.username_edit.setText(proxy.username or "")
            dialog.password_edit.setText(proxy.password or "")
            dialog.listen_port_edit.setText(str(proxy.listen_port or ""))
            # 设置端口转发复选框，如果字段不存在则默认为True
            port_forward = getattr(proxy, 'port_forward', True)
            dialog.port_forward_checkbox.setChecked(port_forward)
        except Exception:
            pass
        if dialog.exec() != QDialog.Accepted:
            return
        data = dialog.get_data()
        data.id = proxy_id
        # 保持原有的 enabled 状态
        data.enabled = proxy.enabled
        
        try:
            is_success = FileOper.update_proxy_config(data)
            if is_success:
                logger.info(" 已更新代理")
                
                # 更新链式代理管理器中的代理配置
                chain_manager = get_chain_proxy_manager()
                if chain_manager:
                    # 记录原来是否在运行
                    was_running = chain_manager.get_proxy_status(proxy_id) == "running"
                    
                    # 如果代理正在运行，先停止
                    if was_running:
                        chain_manager.stop_proxy(proxy_id)
                        logger.info(f" 已停止代理 {data.name} 以更新配置")
                    
                    # 移除旧实例
                    chain_manager.remove_proxy(proxy_id)
                    
                    # 重新添加代理实例
                    add_success = chain_manager.add_proxy(proxy_id)
                    if add_success:
                        logger.info(f" 代理 {data.name} 配置已更新")
                        # 只有在原来运行且启用的情况下才重新启动代理
                        if was_running and data.enabled:
                            start_success = chain_manager.start_proxy(proxy_id)
                            if start_success:
                                logger.info(f" 代理 {data.name} 已重新启动")
                            else:
                                logger.warning(f" 代理 {data.name} 重新启动失败")
                        elif not data.enabled:
                            logger.info(f" 代理 {data.name} 配置已更新但保持停止状态（已禁用）")
                    else:
                        logger.warning(f" 代理 {data.name} 配置更新失败")
                else:
                    logger.warning(f" 链式代理管理器未初始化")
            else:
                logger.warning(" 更新代理失败")
            # 修改代理不需要测速
            self._refresh_proxy_table(test_proxies=[])
        except Exception as exc:
            QMessageBox.critical(self, "修改失败", f"无法修改代理：{exc}")

    def _delete_proxy_with_confirm(self, proxy_id: str) -> None:
        proxy = FileOper.get_proxy_config_by_id(proxy_id)
        name = proxy.name if proxy else proxy_id
        reply = QMessageBox.question(
            self,
            "确认删除",
            f"确定删除代理 \"{name}\" 吗？",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if reply != QMessageBox.Yes:
            return
        
        # 先从链式代理管理器中移除代理
        chain_manager = get_chain_proxy_manager()
        if chain_manager:
            # 停止代理
            chain_manager.stop_proxy(proxy_id)
            # 移除代理实例
            chain_manager.remove_proxy(proxy_id)
            # 直接删除端口分配记录
            chain_manager.remove_proxy_port_allocation(proxy_id)
            logger.info(f" 已从链式代理管理器移除代理 {name}")
        
        # 从文件配置中删除
        if FileOper.delete_proxy_config(proxy_id):
            logger.info(" 已删除代理节点")
            # 清理所有已释放的端口记录
            if chain_manager:
                chain_manager.cleanup_ports()
            # 删除代理不需要测速
            self._refresh_proxy_table(test_proxies=[])

    def _toggle_proxy_status(self, proxy_id: str) -> None:
        """切换代理启动/停止状态"""
        chain_manager = get_chain_proxy_manager()
        if not chain_manager:
            logger.warning(" 链式代理管理器未初始化")
            return
        
        # 获取代理配置
        proxy_config = FileOper.get_proxy_config_by_id(proxy_id)
        if not proxy_config:
            logger.warning(f" 未找到代理配置 {proxy_id}")
            return
        
        # 检查代理是否正在运行
        is_running = self._is_proxy_running(proxy_id)
        
        if is_running:
            # 如果正在运行，则停止
            success = chain_manager.stop_proxy(proxy_id)
            if success:
                # 更新 enabled 状态为 False
                proxy_config.enabled = False
                FileOper.update_proxy_config(proxy_config)
                logger.info(f" 已停止代理 {proxy_config.name}")
            else:
                logger.warning(f" 停止代理失败 {proxy_config.name}")
        else:
            # 如果未运行，则启动
            success = chain_manager.start_proxy(proxy_id)
            if success:
                # 更新 enabled 状态为 True
                proxy_config.enabled = True
                FileOper.update_proxy_config(proxy_config)
                logger.info(f" 已启动代理 {proxy_config.name}")
            else:
                logger.warning(f" 启动代理失败 {proxy_config.name}")
        
        # 刷新表格以更新按钮状态，只测速当前代理
        self._refresh_proxy_table(test_proxies=[proxy_id])

    def _is_proxy_running(self, proxy_id: str) -> bool:
        """检查代理是否正在运行"""
        chain_manager = get_chain_proxy_manager()
        if not chain_manager:
            return False
        
        # 检查代理实例是否在运行线程中
        if proxy_id in chain_manager.instance_threads:
            thread = chain_manager.instance_threads[proxy_id]
            if thread.is_alive():
                # 进一步检查实例的运行状态
                instance = chain_manager.proxy_instances.get(proxy_id)
                if instance:
                    return instance.is_running()
        return False

    # ---- 搜索过滤 ----
    def _on_search_changed(self, _text: str) -> None:
        self._apply_table_filter()

    def _apply_table_filter(self) -> None:
        query = (self.search_edit.text() or "").strip().lower()
        for row in range(self.proxy_table.rowCount()):
            name_item = self.proxy_table.item(row, COL_NAME)
            name_text = (name_item.text() if name_item else "").lower()
            match_name = (not query) or (query in name_text)
            self.proxy_table.setRowHidden(row, not match_name)

    def _get_selected_proxy_id(self) -> Optional[str]:
        selected = self.proxy_table.selectionModel().selectedRows()
        if not selected:
            return None
        item = self.proxy_table.item(selected[0].row(), COL_NAME)
        if item:
            return item.data(Qt.UserRole)
        return None

    # -------- 异步测速 --------
    def _async_test_latency(self, proxy_id: str, *, log_result: bool) -> None:
        self._latency_log_flags[proxy_id] = log_result

        def _worker():
            # 直接使用链式代理管理器测速，它会自动发送事件
            chain_manager = get_chain_proxy_manager()
            if chain_manager:
                try:
                    
                    # 检查代理实例是否存在
                    if proxy_id not in chain_manager.proxy_instances:
                        logger.warning(f" 代理实例不存在，尝试添加: {proxy_id}")
                        # 尝试添加代理实例
                        if chain_manager.add_proxy(proxy_id):
                            logger.info(f" 已添加代理实例: {proxy_id}")
                        else:
                            logger.error(f" 无法添加代理实例: {proxy_id}")
                            return
                    
                    # 调用链式代理管理器的测速方法，它会自动发送 proxy_latency_tested 事件
                    result = chain_manager.test_speed(proxy_id, TEST_URL)
                except Exception as e:
                    logger.error(f" 测速异常: {proxy_id} - {e}")
                    if log_result:
                        logger.error(f" 测速异常: {e}")
            else:
                logger.error(f" 链式代理管理器未初始化，无法测速: {proxy_id}")

        thread = threading.Thread(target=_worker, daemon=True)
        thread.start()

    def _on_proxy_latency_tested(self, proxy_id: str, latency: float, status: ProxyStatus, test_status: ProxyTestStatus, response_content: str) -> None:
        try:
            # 将-1.0转换为None，表示失败
            latency_value = None if latency == -1.0 else latency
            
            # 根据测试状态设置显示文本
            if test_status == ProxyTestStatus.TESTING:
                # 测速中状态
                latency_text = "测速中.."
                region_text = "测速中.."
                ip_text = "测速中.."
                timezone_text = "测速中.."
            elif test_status == ProxyTestStatus.TIMEOUT:
                # 超时状态
                latency_text = "超时"
                region_text = "超时"
                ip_text = "超时"
                timezone_text = "超时"
            elif test_status == ProxyTestStatus.FAILED:
                # 失败状态
                latency_text = "测速失败"
                region_text = "测速失败"
                ip_text = "测速失败"
                timezone_text = "测速失败"
            elif test_status == ProxyTestStatus.TESTED and latency_value is not None:
                # 成功状态，解析响应内容获取地区、IP和时区信息
                latency_text = format_latency_text(latency_value)
                region_text = "未知"
                ip_text = "未知"
                timezone_text = "未知"
                
                if response_content:
                    try:
                        import json
                        data = json.loads(response_content)
                        
                        # 提取地区信息 (region/city/country)
                        region_parts = []
                        if data.get('region'):
                            region_parts.append(data['region'])
                        if data.get('city'):
                            region_parts.append(data['city'])
                        if data.get('country'):
                            region_parts.append(data['country'])
                        region_text = ", ".join(region_parts) if region_parts else "未知"
                        
                        # 提取IP地址
                        ip_text = data.get('ip', '未知')
                        
                        # 提取时区
                        timezone_text = data.get('timezone', '未知')
                        
                    except (json.JSONDecodeError, KeyError, TypeError):
                        region_text = "解析失败"
                        ip_text = "解析失败"
                        timezone_text = "解析失败"
            else:
                # 默认失败状态
                latency_text = "测速失败"
                region_text = "测速失败"
                ip_text = "测速失败"
                timezone_text = "测速失败"
            
            # 确定显示颜色
            if test_status == ProxyTestStatus.TESTING:
                # 测速中显示橙色
                latency_color = QColor("#fd7e14")
                info_color = QColor("#fd7e14")
            elif test_status == ProxyTestStatus.TIMEOUT:
                # 超时显示红色
                latency_color = QColor("#dc3545")
                info_color = QColor("#dc3545")
            elif test_status == ProxyTestStatus.TESTED and latency_value is not None:
                # 成功状态：延迟显示对应颜色，其他信息显示绿色
                latency_color = qcolor_for_latency(latency_value)
                info_color = QColor("#28a745")  # 绿色表示成功获取信息
            else:
                # 失败显示红色
                latency_color = QColor("#dc3545")
                info_color = QColor("#dc3545")
            
            # 更新缓存 - 只在非测速中状态时更新缓存
            if test_status != ProxyTestStatus.TESTING:
                self._speed_result_cache[proxy_id] = {
                    'region': region_text,
                    'ip': ip_text,
                    'timezone': timezone_text,
                    'latency': latency_text,
                    'latency_color': latency_color,
                    'info_color': info_color
                }
            
            # 更新表格
            for row in range(self.proxy_table.rowCount()):
                item = self.proxy_table.item(row, COL_NAME)
                if item and item.data(Qt.UserRole) == proxy_id:
                    # 更新延迟列
                    latency_item = QTableWidgetItem(latency_text)
                    try:
                        latency_item.setForeground(latency_color)
                    except Exception:
                        pass
                    latency_item.setTextAlignment(Qt.AlignCenter)
                    self.proxy_table.setItem(row, COL_LATENCY, latency_item)
                    
                    # 更新地区列
                    region_item = QTableWidgetItem(region_text)
                    region_item.setTextAlignment(Qt.AlignCenter)
                    try:
                        region_item.setForeground(info_color)
                    except Exception:
                        pass
                    self.proxy_table.setItem(row, COL_REGION, region_item)
                    
                    # 更新IP列
                    ip_item = QTableWidgetItem(ip_text)
                    ip_item.setTextAlignment(Qt.AlignCenter)
                    try:
                        ip_item.setForeground(info_color)
                    except Exception:
                        pass
                    self.proxy_table.setItem(row, COL_IP, ip_item)
                    
                    # 更新时区列
                    timezone_item = QTableWidgetItem(timezone_text)
                    timezone_item.setTextAlignment(Qt.AlignCenter)
                    try:
                        timezone_item.setForeground(info_color)
                    except Exception:
                        pass
                    self.proxy_table.setItem(row, COL_TIMEZONE, timezone_item)
                    
                    break

            # 选择性输出日志
            log_result = self._latency_log_flags.pop(proxy_id, False)
            if not log_result:
                # 若处于批量测速，统计是否全部完成
                if proxy_id in self._bulk_pending:
                    try:
                        self._bulk_pending.discard(proxy_id)
                        if not self._bulk_pending:
                            try:
                                self.proxy_test_button.setEnabled(True)
                            except Exception:
                                pass
                    except Exception:
                        pass
                return
            
            # 从链式代理管理器获取代理信息
            chain_manager = get_chain_proxy_manager()
            name = proxy_id
            if chain_manager:
                proxy_info = chain_manager.get_proxy_by_id(proxy_id)
                if proxy_info and 'config' in proxy_info:
                    config = proxy_info['config']
                    name = config.get('name', proxy_id)
            
            # 根据测试状态输出相应的日志
            if test_status == ProxyTestStatus.TESTING:
                # 测速中状态不输出日志，避免日志过多
                pass
            elif test_status == ProxyTestStatus.FAILED:
                logger.warning(f" 节点 {name} 测速失败")
            elif test_status == ProxyTestStatus.TIMEOUT:
                logger.warning(f" 节点 {name} 连接超时")
            elif test_status == ProxyTestStatus.TESTED and latency_value is not None:
                if latency_value >= LATENCY_TIMEOUT_THRESHOLD:
                    logger.warning(f" 节点 {name} 连接超时")
                else:
                    logger.info(f" 节点 {name} 延迟 {latency_value:.0f} ms")
            else:
                logger.warning(f" 节点 {name} 测速失败或连接超时")
        except Exception as e:
            logger.error(f" 处理代理延迟测速事件失败: {e}")

    def _on_proxy_status_changed(self, proxy_id: str, status: ProxyStatus) -> None:
        """处理代理状态变化事件"""
        try:
            # 更新表格中的启动/停止按钮状态
            row = self._find_row_by_proxy(proxy_id)
            if row is not None:
                # 重新创建操作按钮以反映新状态
                self._update_proxy_row_buttons(row, proxy_id)
                
            # 记录状态变化日志
            status_text = "运行中" if status == ProxyStatus.RUNNING else "已停止"
            logger.info(f" 代理 {proxy_id} 状态变更为: {status_text}")
            
        except Exception as e:
            logger.error(f" 处理代理状态变化事件失败: {e}")

    def _update_proxy_row_buttons(self, row: int, proxy_id: str) -> None:
        """更新代理行的操作按钮"""
        try:
            # 获取代理配置以检查端口转发设置
            proxy_config = FileOper.get_proxy_config_by_id(proxy_id)
            if not proxy_config:
                logger.warning(f"未找到代理配置: {proxy_id}")
                return
            
            port_forward = getattr(proxy_config, 'port_forward', True)
            
            # 获取当前的操作按钮组件
            ops_widget = self.proxy_table.cellWidget(row, COL_ACTIONS)
            if ops_widget:
                # 清除现有按钮
                ops_widget.deleteLater()
            
            # 创建新的操作按钮组件
            ops_widget = QWidget()
            ops_layout = QHBoxLayout(ops_widget)
            ops_layout.setContentsMargins(0, 0, 0, 0)
            ops_layout.setSpacing(8)
            ops_layout.setAlignment(Qt.AlignCenter)

            # 删除按钮
            btn_delete = QPushButton("删除")
            try:
                btn_delete.setFixedSize(64, 26)
                btn_delete.setCursor(Qt.PointingHandCursor)
            except Exception:
                pass
            self._style_button(btn_delete, "#6c757d", "#5a6268")
            btn_delete.clicked.connect(lambda _, pid=proxy_id: self._delete_proxy_with_confirm(pid))

            # 修改按钮
            btn_edit = QPushButton("修改")
            try:
                btn_edit.setFixedSize(64, 26)
                btn_edit.setCursor(Qt.PointingHandCursor)
            except Exception:
                pass
            self._style_button(btn_edit, "#007bff", "#0069d9")
            btn_edit.clicked.connect(lambda _, pid=proxy_id: self._edit_proxy(pid))

            # 测速按钮
            btn_test = QPushButton("测速")
            try:
                btn_test.setFixedSize(64, 26)
                btn_test.setCursor(Qt.PointingHandCursor)
            except Exception:
                pass
            self._style_button(btn_test, "#17a2b8", "#138496")
            btn_test.clicked.connect(lambda _, pid=proxy_id: self._test_one_proxy(pid))

            # 检查是否启用端口转发，只有启用端口转发才显示启动/停止按钮
            if port_forward:
                # 启动/停止按钮 - 根据当前状态设置
                is_running = self._is_proxy_running(proxy_id)
                btn_text = "停止" if is_running else "启动"
                btn_color = "#dc3545" if is_running else "#28a745"
                btn_hover_color = "#c82333" if is_running else "#218838"
                
                btn_start_stop = QPushButton(btn_text)
                try:
                    btn_start_stop.setFixedSize(64, 26)
                    btn_start_stop.setCursor(Qt.PointingHandCursor)
                except Exception:
                    pass
                self._style_button(btn_start_stop, btn_color, btn_hover_color)
                btn_start_stop.clicked.connect(lambda _, pid=proxy_id: self._toggle_proxy_status(pid))

                # 添加按钮到布局（包含启动/停止按钮）
                ops_layout.addWidget(btn_delete)
                ops_layout.addWidget(btn_edit)
                ops_layout.addWidget(btn_test)
                ops_layout.addWidget(btn_start_stop)
            else:
                # 不启用端口转发时，只显示：删除、修改、测速
                ops_layout.addWidget(btn_delete)
                ops_layout.addWidget(btn_edit)
                ops_layout.addWidget(btn_test)
            
            # 设置到表格单元格
            self.proxy_table.setCellWidget(row, COL_ACTIONS, ops_widget)
            
        except Exception as e:
            logger.error(f" 更新代理行按钮失败: {e}")



