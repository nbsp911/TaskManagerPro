

from typing import Optional

from PySide6.QtWidgets import (
    QDialog,
    QVBoxLayout,
    QHBoxLayout,
    QLineEdit,
    QPushButton,
    QLabel,
    QWidget,
    QMessageBox,
    QFileDialog,
    QInputDialog,
)
from PySide6.QtCore import Qt
from tools import parse_google_authenticator_secret
import cv2
import base64
from urllib.parse import urlparse, parse_qs


class QrCodeDialog(QDialog):
    """输入/粘贴 Authenticator 内容，或从剪贴板获取，然后解析出 TOTP 密钥。

    说明：
    - 顶部为单行输入框与“确认”按钮；
    - 下方提供一个大按钮“扫描二维码”（当前实现：从剪贴板文本获取；若你需要图片二维码识别，可后续扩展在此处解析剪贴板/文件中的图片并识别二维码）。
    """

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.setWindowTitle("Google Authenticator 输入/扫描")
        try:
            self.resize(720, 300)
        except Exception:
            pass

        self._parsed_secret: Optional[str] = None

        self.input_edit = QLineEdit()
        try:
            self.input_edit.setPlaceholderText("输入Authenticator 内容解析")
            # 高度提高约2倍
            self.input_edit.setMinimumHeight(48)
            # 边框与圆角样式
            self.input_edit.setStyleSheet(
                """
                QLineEdit {
                    border: 1px solid #5f6368;
                    border-radius: 6px;
                    padding: 8px 10px;
                    background-color: #202124;
                    color: #E8EAED;
                }
                QLineEdit:focus {
                    border: 1px solid #8ab4f8;
                }
                """
            )
        except Exception:
            pass

        self.confirm_btn = QPushButton("确认")
        try:
            self.confirm_btn.setCursor(Qt.PointingHandCursor)
            self.confirm_btn.setStyleSheet(
                """
                QPushButton {
                    background-color: #28a745;
                    color: white;
                    border-radius: 6px;
                    border: 1px solid #5f6368;
                    font-size: 16px;
                    font-weight: 600;
                }
                QPushButton:hover:!disabled {
                    background-color: #218838;
                    border-color: #8ab4f8;
                }
                QPushButton:disabled {
                    background-color: #9aa0a6;
                    color: #f1f3f4;
                    border: 1px solid #5f6368;
                }
                """
            )
            # 高度与输入框一致，宽度为之前的 70%（相对之前 200px）
            self.confirm_btn.setFixedHeight(48)
            self.confirm_btn.setFixedWidth(140)
        except Exception:
            pass
        self.confirm_btn.clicked.connect(self._on_confirm)

        top_row = QHBoxLayout()
        top_row.addWidget(self.input_edit, 1)
        top_row.addWidget(self.confirm_btn, 0)

        self.scan_btn = QPushButton("上传二维码")
        try:
            # 增大高度
            self.scan_btn.setMinimumHeight(220)
            self.scan_btn.setCursor(Qt.PointingHandCursor)
            # 使用虚线边框（恢复之前风格）
            self.scan_btn.setStyleSheet(
                """
                QPushButton {
                    border: 2px dashed #5f6368;
                    border-radius: 6px;
                    background-color: #1e1f21;
                    color: #E8EAED;
                    font-size: 16px;
                    font-weight: 600;
                }
                QPushButton:hover:!disabled {
                    border-color: #8ab4f8;
                    background-color: #2a2c2f;
                }
                QPushButton:disabled {
                    border-color: #9aa0a6;
                    color: #9aa0a6;
                }
                """
            )
        except Exception:
            pass
        self.scan_btn.clicked.connect(self._on_scan_click)

        layout = QVBoxLayout(self)
        try:
            # 上下与左右一致
            layout.setContentsMargins(16, 16, 16, 16)
            layout.setSpacing(12)
        except Exception:
            pass
        # 顶部行边距与间距
        try:
            top_row.setSpacing(10)
            top_row.setContentsMargins(0, 0, 0, 0)
        except Exception:
            pass
        layout.addLayout(top_row)
        layout.addWidget(self.scan_btn, 1)

    # # TODO: 摄像头显示在UI上，发现二维码后自动解析，多个验证码要选择
    # def _on_scan_click(self):
    #     # 自动遍历摄像头索引与后端（DShow -> MSMF -> ANY），识别到即返回
    #     def try_scan_with(cap, timeout_seconds: float = 12.0) -> Optional[str]:
    #         try:
    #             if cap is None or not cap.isOpened():
    #                 return None
    #             detector = cv2.QRCodeDetector()
    #             start_ts = time.time()
    #             while time.time() - start_ts < timeout_seconds:
    #                 ok, frame = cap.read()
    #                 if not ok:
    #                     QApplication.processEvents()
    #                     continue
    #                 try:
    #                     data, points, _ = detector.detectAndDecode(frame)
    #                     if data:
    #                         return data.strip()
    #                 except Exception:
    #                     pass
    #                 QApplication.processEvents()
    #             return None
    #         finally:
    #             try:
    #                 cap.release()
    #             except Exception:
    #                 pass

    #     backends = [cv2.CAP_DSHOW, cv2.CAP_MSMF, cv2.CAP_ANY]
    #     decoded: Optional[str] = None
    #     for backend in backends:
    #         for idx in range(0, 6):
    #             try:
    #                 cap = cv2.VideoCapture(idx, backend)
    #             except Exception:
    #                 cap = None
    #             if cap is None or not cap.isOpened():
    #                 try:
    #                     if cap is not None:
    #                         cap.release()
    #                 except Exception:
    #                     pass
    #                 continue
    #             decoded = try_scan_with(cap, timeout_seconds=12.0)
    #             if decoded:
    #                 break
    #         if decoded:
    #             break

    #     if decoded:
    #         try:
    #             self.input_edit.setText(decoded)
    #         except Exception:
    #             pass
    #         return
    #     # 未识别到时给出提示
    #     QMessageBox.information(self, "提示", "未找到可用摄像头或未检测到二维码。")
    
    def _on_scan_click(self):
        # 进入“上传模式”后复用 _on_confirm 的处理逻辑
        try:
            self._scan_mode = True
        except Exception:
            pass
        try:
            self._on_confirm()
        finally:
            try:
                self._scan_mode = False
            except Exception:
                pass

    def _on_confirm(self):
        # 若为“上传模式”，弹出文件对话框并解析二维码
        if getattr(self, "_scan_mode", False):
            try:
                file_path, _ = QFileDialog.getOpenFileName(
                    self,
                    "选择二维码图片",
                    "",
                    "Images (*.png *.jpg *.jpeg *.bmp *.webp)"
                )
            except Exception:
                file_path = ""
            if not file_path:
                return
            # 扩展名校验
            try:
                lower = file_path.lower()
                allowed = (".png", ".jpg", ".jpeg", ".bmp", ".webp")
                if not any(lower.endswith(ext) for ext in allowed):
                    QMessageBox.warning(self, "提示", "仅支持图片格式：PNG/JPG/JPEG/BMP/WEBP。")
                    return
            except Exception:
                pass

            # 读取并识别二维码（支持多码）
            try:
                img = cv2.imread(file_path)
            except Exception:
                img = None
            if img is None:
                QMessageBox.warning(self, "提示", "无法读取图片，请重试或更换文件。")
                return

            texts: list[str] = []
            try:
                detector = cv2.QRCodeDetector()
                # 优先多码识别，兼容不同 OpenCV 版本的返回签名
                try:
                    decode_ok, decoded_infos, _points, _ = detector.detectAndDecodeMulti(img)
                    if decode_ok and decoded_infos:
                        texts.extend([t for t in decoded_infos if t])
                except Exception:
                    try:
                        decoded_infos, _points, _ = detector.detectAndDecodeMulti(img)
                        if decoded_infos:
                            texts.extend([t for t in decoded_infos if t])
                    except Exception:
                        pass
                # 回退到单码识别
                try:
                    data, _pts, _ = detector.detectAndDecode(img)
                    if data:
                        texts.append(data)
                except Exception:
                    pass
            except Exception:
                texts = []

            # 去重并过滤非空
            uniq_texts: list[str] = []
            try:
                seen = set()
                for t in texts:
                    tt = (t or "").strip()
                    if not tt:
                        continue
                    if tt in seen:
                        continue
                    seen.add(tt)
                    uniq_texts.append(tt)
            except Exception:
                uniq_texts = [t for t in texts if t]

            # 解析 GA Secret（支持 otpauth-migration 多账号）
            def _extract_secrets_from_migration(uri: str) -> list[str]:
                try:
                    parsed = urlparse(uri)
                    qs = parse_qs(parsed.query)
                    data_param = (qs.get("data", [""])[0] or "").strip()
                    if not data_param:
                        return []
                    padding = '=' * (-len(data_param) % 4)
                    payload = base64.urlsafe_b64decode(data_param + padding)

                    def read_varint(buf, i):
                        shift = 0
                        result = 0
                        while True:
                            b = buf[i]
                            i += 1
                            result |= (b & 0x7F) << shift
                            if (b & 0x80) == 0:
                                break
                            shift += 7
                        return result, i

                    def read_len_delimited(buf, i):
                        ln, i = read_varint(buf, i)
                        j = i + ln
                        return buf[i:j], j

                    def parse_otp_parameters_collect_secrets(msg_bytes):
                        i = 0
                        n = len(msg_bytes)
                        secrets: list[bytes] = []
                        while i < n:
                            tag, i = read_varint(msg_bytes, i)
                            field_no = tag >> 3
                            wire = tag & 0x7
                            if wire == 2:
                                val, i = read_len_delimited(msg_bytes, i)
                                if field_no == 1:
                                    secrets.append(val)
                            elif wire == 0:
                                _, i = read_varint(msg_bytes, i)
                            elif wire == 5:
                                i += 4
                            elif wire == 1:
                                i += 8
                            else:
                                break
                        return secrets

                    i = 0
                    n = len(payload)
                    all_secrets: list[str] = []
                    while i < n:
                        tag, i = read_varint(payload, i)
                        field_no = tag >> 3
                        wire = tag & 0x7
                        if field_no == 1 and wire == 2:  # otp_parameters
                            submsg, i = read_len_delimited(payload, i)
                            secs = parse_otp_parameters_collect_secrets(submsg)
                            for s in secs:
                                try:
                                    b32 = base64.b32encode(s).decode('ascii').replace('=', '').upper()
                                    if b32:
                                        all_secrets.append(b32)
                                except Exception:
                                    continue
                        elif wire == 2:
                            _, i = read_len_delimited(payload, i)
                        elif wire == 0:
                            _, i = read_varint(payload, i)
                        elif wire == 5:
                            i += 4
                        elif wire == 1:
                            i += 8
                        else:
                            break
                    # 去重
                    uniq = []
                    seen = set()
                    for s in all_secrets:
                        if s and s not in seen:
                            seen.add(s)
                            uniq.append(s)
                    return uniq
                except Exception:
                    return []

            ga_items: list[tuple[str, str]] = []  # (source_text, secret)
            for t in uniq_texts:
                tl = (t or "").strip().lower()
                if tl.startswith("otpauth-migration://"):
                    secrets = _extract_secrets_from_migration(t)
                    for s in secrets:
                        ga_items.append((t, s))
                    if secrets:
                        continue
                try:
                    sec = parse_google_authenticator_secret(t)
                except Exception:
                    sec = ""
                if sec:
                    ga_items.append((t, sec))

            if not ga_items:
                QMessageBox.information(self, "提示", "未在图片中解析到 Google Authenticator 内容。")
                return

            if len(ga_items) == 1:
                # 单条：直接写入输入框（写入 Base32 密钥）并继续解析
                try:
                    self.input_edit.setText(ga_items[0][1])
                except Exception:
                    pass
                raw = ga_items[0][1]
            else:
                # 多条：让用户选择
                try:
                    options = []
                    for idx, (src_text, sec) in enumerate(ga_items):
                        src_preview = (src_text[:40] + '…') if len(src_text) > 40 else src_text
                        options.append(f"{idx+1}. {sec})")
                except Exception:
                    options = [f"{idx+1}. {sec}" for idx, (_src, sec) in enumerate(ga_items)]
                try:
                    chosen, ok = QInputDialog.getItem(
                        self,
                        "选择条目",
                        "检测到多个验证码内容，请选择：",
                        options,
                        0,
                        False,
                    )
                except Exception:
                    chosen, ok = ("", False)
                if not ok:
                    return
                try:
                    sel_index = options.index(chosen)
                except Exception:
                    sel_index = 0
                raw = ga_items[sel_index][1]
                try:
                    self.input_edit.setText(raw)
                except Exception:
                    pass
        else:
            raw = (self.input_edit.text() or "").strip()
            if not raw:
                QMessageBox.warning(self, "提示", "请输入或扫描 Authenticator 内容。")
                return

        # 统一执行解析与校验
        parsed = parse_google_authenticator_secret(raw)
        if not parsed:
            QMessageBox.warning(self, "提示", "未能解析出有效的 TOTP 密钥，请检查内容。")
            return
        self._parsed_secret = parsed
        self.accept()

    def get_secret(self) -> Optional[str]:
        return self._parsed_secret


