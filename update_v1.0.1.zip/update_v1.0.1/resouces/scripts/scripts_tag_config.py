ScriptTagConfig = {
    "binance_alpha": {
        "zh-CN":{
            "order_misclick_warning": "下单手滑提醒",
            "confirm_buy_dialog_title": "限价 / 买入",
            "refresh_text": "刷新",
            "confirm_sell_checkbox_dialog_title": "确认付款",
            "google_authenticator_dialog_title": "身份验证器App",
            "buy_order_text": "买入",
            "sell_order_text": "卖出",
        }
    },
    
}