"""
邮件发送模块
支持多个邮箱轮询发送邮件
"""

import os, time, logging, smtplib, urllib3, sys
from typing import List, Dict, Optional, Tuple
from exchangelib import Credentials, Account, Message, Mailbox, DELEGATE, Configuration
from exchangelib.protocol import BaseProtocol, NoVerifyHTTPAdapter
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email import encoders
from email.mime.base import MIMEBase
# 禁用SSL验证警告
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# 设置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger()

# 导入项目模块
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from file_oper import FileOper
from data_type import EmailJsonConfig


class EmailSender:
    """邮件发送器"""
    
    def __init__(self):
        self.current_account_index = 0
        
        # 设置Exchange协议（默认禁用SSL验证）
        BaseProtocol.HTTP_ADAPTER_CLS = NoVerifyHTTPAdapter
    
    def _get_next_account(self) -> Optional[EmailJsonConfig]:
        """获取下一个可用的账户（轮询）"""
        enabled_accounts = FileOper.get_enabled_accounts()
        if not enabled_accounts:
            return None
        
        # 轮询选择账户
        account = enabled_accounts[self.current_account_index % len(enabled_accounts)]
        self.current_account_index += 1
        
        return account
    
    def _is_exchange_server(self, server: str) -> bool:
        """判断是否为Exchange服务器"""
        exchange_servers = [
            'outlook.office365.com',
            'mail.office365.com',
            'outlook.com',
            'exchange.microsoft.com'
        ]
        return any(exchange_server in server.lower() for exchange_server in exchange_servers)
    
    def _send_email_smtp(self, account_config: EmailJsonConfig, to_emails: List[str], 
                        subject: str, body: str, is_html: bool = False, 
                        cc_emails: List[str] = None, bcc_emails: List[str] = None, 
                        attachments: List[str] = None) -> Tuple[bool, str]:
        """使用SMTP发送邮件"""
        try:
            # 创建邮件
            msg = MIMEMultipart()
            msg['From'] = account_config.email
            msg['To'] = ', '.join(to_emails)
            msg['Subject'] = subject
            
            if cc_emails:
                msg['Cc'] = ', '.join(cc_emails)
            
            # 添加邮件内容
            if is_html:
                msg.attach(MIMEText(body, 'html', 'utf-8'))
            else:
                msg.attach(MIMEText(body, 'plain', 'utf-8'))
            
            # 添加附件
            if attachments:
                for attachment_path in attachments:
                    if os.path.exists(attachment_path):
                        with open(attachment_path, 'rb') as f:
                            part = MIMEBase('application', 'octet-stream')
                            part.set_payload(f.read())
                            encoders.encode_base64(part)
                            part.add_header(
                                'Content-Disposition',
                                f'attachment; filename= {os.path.basename(attachment_path)}'
                            )
                            msg.attach(part)
            
            # 连接SMTP服务器
            if account_config.use_ssl:
                server = smtplib.SMTP_SSL(account_config.server, account_config.port)
            else:
                server = smtplib.SMTP(account_config.server, account_config.port)
                if account_config.use_ssl:
                    server.starttls()
            
            # 登录
            server.login(account_config.email, account_config.password)
            
            # 发送邮件
            all_recipients = to_emails + (cc_emails or []) + (bcc_emails or [])
            server.send_message(msg, to_addrs=all_recipients)
            server.quit()
            
            return True, f"SMTP邮件发送成功，使用账户: {account_config.email}"
            
        except Exception as e:
            logger.error(f"SMTP发送邮件失败 {account_config.email}: {e}")
            return False, str(e)
    
    def _create_account_connection(self, account_config: EmailJsonConfig) -> Optional[Account]:
        """创建Exchange账户连接"""
        try:
            credentials = Credentials(
                username=account_config.email,
                password=account_config.password
            )
            
            # 创建Configuration对象
            config = Configuration(
                server=account_config.server,
                credentials=credentials,
                auth_type='basic'
            )
            
            account = Account(
                primary_smtp_address=account_config.email,
                config=config,
                autodiscover=False,
                access_type=DELEGATE
            )
            
            # 测试连接
            account.root
            return account
            
        except Exception as e:
            logger.error(f"创建账户连接失败 {account_config.email}: {e}")
            return None
    
    def send_email(self, to_emails: List[str], subject: str, body: str, 
                  is_html: bool = False, cc_emails: List[str] = None, 
                  bcc_emails: List[str] = None, attachments: List[str] = None) -> Tuple[bool, str]:
        """
        发送邮件
        
        Args:
            to_emails: 收件人邮箱列表
            subject: 邮件主题
            body: 邮件内容
            is_html: 是否为HTML格式
            cc_emails: 抄送邮箱列表
            bcc_emails: 密送邮箱列表
            attachments: 附件文件路径列表
            
        Returns:
            (成功标志, 消息)
        """
        max_retry = 3  # 默认最大重试次数
        
        for attempt in range(max_retry):
            account_config = self._get_next_account()
            if not account_config:
                return False, "没有可用的邮箱账户"
            
            try:
                # 判断使用SMTP还是Exchange
                if self._is_exchange_server(account_config.server):
                    # 使用Exchange发送
                    account = self._create_account_connection(account_config)
                    if not account:
                        continue
                    
                    # 创建邮件
                    message = Message(
                        account=account,
                        subject=subject,
                        body=body,
                        to_recipients=[Mailbox(email_address=email) for email in to_emails]
                    )
                    
                    # 添加抄送
                    if cc_emails:
                        message.cc_recipients = [Mailbox(email_address=email) for email in cc_emails]
                    
                    # 添加密送
                    if bcc_emails:
                        message.bcc_recipients = [Mailbox(email_address=email) for email in bcc_emails]
                    
                    # 设置邮件格式
                    if is_html:
                        message.body_type = 'HTML'
                    
                    # 添加附件
                    if attachments:
                        for attachment_path in attachments:
                            if os.path.exists(attachment_path):
                                with open(attachment_path, 'rb') as f:
                                    message.attachments.append(f.read())
                    
                    # 发送邮件
                    message.send()
                    success_msg = f"Exchange邮件发送成功，使用账户: {account_config.email}"
                else:
                    # 使用SMTP发送
                    success, msg = self._send_email_smtp(
                        account_config, to_emails, subject, body, is_html, cc_emails, bcc_emails, attachments
                    )
                    if not success:
                        raise Exception(msg)
                    success_msg = msg
                
                # 更新统计信息
                FileOper.update_account_stats(account_config.email, success=True)
                
                logger.info(f"邮件发送成功: {account_config.email} -> {to_emails}")
                return True, success_msg
                
            except Exception as e:
                logger.error(f"发送邮件失败 {account_config.email} (尝试 {attempt + 1}/{max_retry}): {e}")
                
                # 更新错误统计
                FileOper.update_account_stats(account_config.email, success=False)
                
                if attempt < max_retry - 1:
                    # 等待后重试
                    time.sleep(5)  # 默认5秒间隔
        
        return False, f"所有账户发送失败，已重试 {max_retry} 次"
    
    def send_batch_emails(self, email_list: List[Dict], delay: float = None) -> Dict[str, Tuple[bool, str]]:
        """
        批量发送邮件
        
        Args:
            email_list: 邮件列表，每个元素包含 to_emails, subject, body 等字段
            delay: 发送间隔（秒），None则使用配置中的间隔
            
        Returns:
            发送结果字典 {邮件索引: (成功标志, 消息)}
        """
        results = {}
        send_interval = delay or 5  # 默认5秒间隔
        
        for i, email_data in enumerate(email_list):
            try:
                success, message = self.send_email(**email_data)
                results[str(i)] = (success, message)
                
                # 发送间隔
                if i < len(email_list) - 1:
                    time.sleep(send_interval)
                    
            except Exception as e:
                logger.error(f"批量发送邮件失败 {i}: {e}")
                results[str(i)] = (False, str(e))
        
        return results
    
    def test_connection(self, email: str = None) -> Dict[str, bool]:
        """
        测试邮箱连接
        
        Args:
            email: 指定测试的邮箱，None则测试所有邮箱
            
        Returns:
            连接测试结果 {邮箱: 连接状态}
        """
        results = {}
        accounts_to_test = []
        
        if email:
            # 测试指定邮箱
            all_accounts = FileOper.get_email_config()
            for account in all_accounts:
                if account.email == email:
                    accounts_to_test.append(account)
                    break
        else:
            # 测试所有邮箱
            accounts_to_test = FileOper.get_email_config()
        
        for account_config in accounts_to_test:
            try:
                if self._is_exchange_server(account_config.server):
                    # 测试Exchange连接
                    account = self._create_account_connection(account_config)
                    results[account_config.email] = account is not None
                else:
                    # 测试SMTP连接
                    try:
                        if account_config.use_ssl:
                            server = smtplib.SMTP_SSL(account_config.server, account_config.port)
                        else:
                            server = smtplib.SMTP(account_config.server, account_config.port)
                            if account_config.use_ssl:
                                server.starttls()
                        server.login(account_config.email, account_config.password)
                        server.quit()
                        results[account_config.email] = True
                    except Exception as smtp_e:
                        logger.error(f"SMTP测试连接失败 {account_config.email}: {smtp_e}")
                        results[account_config.email] = False
            except Exception as e:
                logger.error(f"测试连接失败 {account_config.email}: {e}")
                results[account_config.email] = False
        
        return results
    
    def get_account_stats(self) -> List[EmailJsonConfig]:
        """获取账户统计信息"""
        return FileOper.get_email_config()
