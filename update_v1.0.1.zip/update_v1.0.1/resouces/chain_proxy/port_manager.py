"""
PortManager - 端口管理系统
支持自动分配和固定端口分配
"""

import socket
import threading
import logging
from typing import Dict, Set, Optional, List, Tuple
from dataclasses import dataclass
import json
import os
from pathlib import Path

logger = logging.getLogger()


@dataclass
class PortAllocation:
    """端口分配记录"""
    proxy_id: str
    port: int
    host: str
    allocated_time: float
    status: str  # allocated, released, reserved
    
    def to_dict(self) -> dict:
        return {
            "proxy_id": self.proxy_id,
            "port": self.port,
            "host": self.host,
            "allocated_time": self.allocated_time,
            "status": self.status
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> "PortAllocation":
        return cls(
            proxy_id=data["proxy_id"],
            port=data["port"],
            host=data["host"],
            allocated_time=data["allocated_time"],
            status=data["status"]
        )


class PortManager:
    """端口管理器"""
    
    def __init__(self, 
                 start_port: int = 17717, 
                 end_port: int = 18717,
                 reserved_ports: Set[int] = None,
                 persistence_file: str = "tmp/port_allocations.json"):
        self.start_port = start_port
        self.end_port = end_port
        self.reserved_ports = reserved_ports or set()
        self.persistence_file = persistence_file
        
        # 端口分配记录
        self.allocations: Dict[str, PortAllocation] = {}  # proxy_id -> PortAllocation
        self.used_ports: Set[int] = set()  # 已使用的端口
        self._lock = threading.RLock()
        
        # 加载持久化数据
        self._load_allocations()
    
    def _load_allocations(self):
        """加载端口分配记录"""
        try:
            if os.path.exists(self.persistence_file):
                with open(self.persistence_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                
                for proxy_id, allocation_data in data.items():
                    allocation = PortAllocation.from_dict(allocation_data)
                    self.allocations[proxy_id] = allocation
                    if allocation.status == "allocated":
                        self.used_ports.add(allocation.port)
                
                logger.info(f"已加载 {len(self.allocations)} 个端口分配记录")
        except Exception as e:
            logger.error(f"加载端口分配记录失败: {e}")
    
    def _save_allocations(self):
        """保存端口分配记录"""
        try:
            # 确保目录存在
            os.makedirs(os.path.dirname(self.persistence_file), exist_ok=True)
            
            with self._lock:
                data = {
                    proxy_id: allocation.to_dict()
                    for proxy_id, allocation in self.allocations.items()
                }
            
            with open(self.persistence_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
                
        except Exception as e:
            logger.error(f"保存端口分配记录失败: {e}")
    
    def _is_port_available(self, port: int, host: str = "127.0.0.1") -> bool:
        """检查端口是否可用"""
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(1)
                result = s.connect_ex((host, port))
                return result != 0  # 连接失败表示端口可用
        except Exception:
            return False
    
    def _find_available_port(self, preferred_port: Optional[int] = None) -> Optional[int]:
        """查找可用端口"""
        with self._lock:
            # 如果指定了首选端口，先检查它
            if preferred_port and preferred_port not in self.used_ports:
                if self._is_port_available(preferred_port):
                    return preferred_port
            
            # 在范围内查找可用端口
            for port in range(self.start_port, self.end_port + 1):
                if port not in self.used_ports and port not in self.reserved_ports:
                    if self._is_port_available(port):
                        return port
            
            return None
    
    def allocate_port(self, proxy_id: str, 
                     preferred_port: Optional[int] = None,
                     host: str = "127.0.0.1") -> Optional[int]:
        """分配端口"""
        with self._lock:
            # 检查是否已有分配
            if proxy_id in self.allocations:
                existing = self.allocations[proxy_id]
                if existing.status == "allocated":
                    logger.info(f"代理 {proxy_id} 已有端口分配: {existing.port}")
                    return existing.port
            
            # 查找可用端口
            port = self._find_available_port(preferred_port)
            if port is None:
                logger.error(f"无法为代理 {proxy_id} 分配端口")
                return None
            
            # 创建分配记录
            import time
            allocation = PortAllocation(
                proxy_id=proxy_id,
                port=port,
                host=host,
                allocated_time=time.time(),
                status="allocated"
            )
            
            # 更新记录
            self.allocations[proxy_id] = allocation
            self.used_ports.add(port)
            
            # 保存到文件
            self._save_allocations()
            
            logger.info(f"为代理 {proxy_id} 分配端口: {port}")
            return port
    
    def release_port(self, proxy_id: str) -> bool:
        """释放端口"""
        with self._lock:
            if proxy_id not in self.allocations:
                logger.warning(f"代理 {proxy_id} 没有端口分配")
                return False
            
            allocation = self.allocations[proxy_id]
            if allocation.status == "released":
                logger.warning(f"代理 {proxy_id} 的端口已释放")
                return True
            
            # 更新状态
            allocation.status = "released"
            self.used_ports.discard(allocation.port)
            
            # 保存到文件
            self._save_allocations()
            
            logger.info(f"释放代理 {proxy_id} 的端口: {allocation.port}")
            return True
    
    def reserve_port(self, proxy_id: str, port: int, host: str = "127.0.0.1") -> bool:
        """预留端口"""
        with self._lock:
            if port in self.used_ports:
                logger.error(f"端口 {port} 已被使用")
                return False
            
            if not self._is_port_available(port, host):
                logger.error(f"端口 {port} 不可用")
                return False
            
            # 创建预留记录
            import time
            allocation = PortAllocation(
                proxy_id=proxy_id,
                port=port,
                host=host,
                allocated_time=time.time(),
                status="reserved"
            )
            
            # 更新记录
            self.allocations[proxy_id] = allocation
            self.used_ports.add(port)
            
            # 保存到文件
            self._save_allocations()
            
            logger.info(f"为代理 {proxy_id} 预留端口: {port}")
            return True
    
    def get_port(self, proxy_id: str) -> Optional[int]:
        """获取代理的端口"""
        with self._lock:
            if proxy_id in self.allocations:
                allocation = self.allocations[proxy_id]
                if allocation.status == "allocated":
                    return allocation.port
            return None
    
    def get_allocation(self, proxy_id: str) -> Optional[PortAllocation]:
        """获取端口分配记录"""
        with self._lock:
            return self.allocations.get(proxy_id)
    
    def get_all_allocations(self) -> Dict[str, PortAllocation]:
        """获取所有端口分配"""
        with self._lock:
            return self.allocations.copy()
    
    def get_available_ports(self, count: int = 10) -> List[int]:
        """获取可用端口列表"""
        with self._lock:
            available_ports = []
            for port in range(self.start_port, self.end_port + 1):
                if (port not in self.used_ports and 
                    port not in self.reserved_ports and
                    self._is_port_available(port)):
                    available_ports.append(port)
                    if len(available_ports) >= count:
                        break
            return available_ports
    
    def get_port_stats(self) -> Dict[str, any]:
        """获取端口统计信息"""
        with self._lock:
            allocated_count = sum(1 for a in self.allocations.values() if a.status == "allocated")
            reserved_count = sum(1 for a in self.allocations.values() if a.status == "reserved")
            released_count = sum(1 for a in self.allocations.values() if a.status == "released")
            
            return {
                "total_allocations": len(self.allocations),
                "allocated_ports": allocated_count,
                "reserved_ports": reserved_count,
                "released_ports": released_count,
                "used_ports": len(self.used_ports),
                "available_ports": len(self.get_available_ports(100)),
                "port_range": f"{self.start_port}-{self.end_port}"
            }
    
    def cleanup_released_ports(self):
        """清理已释放的端口记录"""
        with self._lock:
            to_remove = []
            for proxy_id, allocation in self.allocations.items():
                if allocation.status == "released":
                    to_remove.append(proxy_id)
            
            for proxy_id in to_remove:
                del self.allocations[proxy_id]
            
            if to_remove:
                self._save_allocations()
                logger.info(f"清理了 {len(to_remove)} 个已释放的端口记录")
    
    def remove_proxy_allocation(self, proxy_id: str) -> bool:
        """直接删除特定代理的端口分配记录"""
        with self._lock:
            if proxy_id in self.allocations:
                allocation = self.allocations[proxy_id]
                # 从已使用端口中移除
                self.used_ports.discard(allocation.port)
                # 删除分配记录
                del self.allocations[proxy_id]
                # 保存到文件
                self._save_allocations()
                logger.info(f"已删除代理 {proxy_id} 的端口分配记录")
                return True
            else:
                logger.warning(f"代理 {proxy_id} 没有端口分配记录")
                return False
    
    def reset_all_allocations(self):
        """重置所有端口分配"""
        with self._lock:
            self.allocations.clear()
            self.used_ports.clear()
            self._save_allocations()
            logger.info("已重置所有端口分配")
    
    def export_allocations(self, filename: str):
        """导出端口分配记录"""
        with self._lock:
            data = {
                proxy_id: allocation.to_dict()
                for proxy_id, allocation in self.allocations.items()
            }
            
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
    
    def import_allocations(self, filename: str) -> bool:
        """导入端口分配记录"""
        try:
            with open(filename, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            with self._lock:
                self.allocations.clear()
                self.used_ports.clear()
                
                for proxy_id, allocation_data in data.items():
                    allocation = PortAllocation.from_dict(allocation_data)
                    self.allocations[proxy_id] = allocation
                    if allocation.status in ["allocated", "reserved"]:
                        self.used_ports.add(allocation.port)
                
                self._save_allocations()
                logger.info(f"已导入 {len(self.allocations)} 个端口分配记录")
                return True
                
        except Exception as e:
            logger.error(f"导入端口分配记录失败: {e}")
            return False
    
    def __str__(self) -> str:
        stats = self.get_port_stats()
        return f"PortManager(allocated={stats['allocated_ports']}, available={stats['available_ports']})"
    
    def __repr__(self) -> str:
        return self.__str__()
