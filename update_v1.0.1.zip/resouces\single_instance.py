"""
单实例运行检查器

使用文件锁机制确保程序只能运行一个实例。
当检测到已有实例运行时，会显示提示信息并退出。
"""

import os, time, atexit, logging, sys
from pathlib import Path
from typing import Optional
logger = logging.getLogger(__name__)

class SingleInstanceChecker:
    """单实例检查器"""
    
    def __init__(self, app_name: str = "TaskManagerPro", lock_dir: Optional[Path] = None):
        """
        初始化单实例检查器
        
        Args:
            app_name: 应用程序名称，用于生成锁文件名
            lock_dir: 锁文件目录，默认为项目根目录下的tmp目录
        """
        self.app_name = app_name
        self.lock_file: Optional[Path] = None
        self.lock_handle = None
        
        # 确定锁文件路径
        if lock_dir is None:
            # 获取项目根目录
            current_file = Path(__file__).resolve()
            project_root = current_file.parent.parent  # 从resouces目录回到项目根目录
            lock_dir = project_root / "tmp"
        
        # 确保锁目录存在
        lock_dir.mkdir(exist_ok=True)
        
        # 生成锁文件路径
        self.lock_file = lock_dir / f"{app_name}.lock"
        
        # 注册退出时清理函数
        atexit.register(self.cleanup)
    
    def is_running(self) -> bool:
        """
        检查是否已有实例在运行
        
        Returns:
            True: 已有实例运行
            False: 没有实例运行
        """
        if not self.lock_file:
            return False
        
        # 首先检查锁文件是否存在，如果存在，检查PID是否有效
        if self.lock_file.exists():
            try:
                with open(self.lock_file, 'r', encoding='utf-8') as f:
                    content = f.read().strip()
                    if content:
                        lines = content.split('\n')
                        pid_line = None
                        for line in lines:
                            if line.startswith('PID:'):
                                pid_line = line
                                break
                        
                        if pid_line:
                            try:
                                pid = int(pid_line.split(':', 1)[1].strip())
                                # 检查进程是否真的在运行
                                import psutil
                                if psutil.pid_exists(pid):
                                    # 进程存在，说明确实有实例在运行
                                    return True
                                else:
                                    # 进程不存在，删除过期的锁文件
                                    self.lock_file.unlink()
                            except (ValueError, IndexError):
                                # PID解析失败，删除无效的锁文件
                                self.lock_file.unlink()
                        else:
                            # 没有PID信息，删除无效的锁文件
                            self.lock_file.unlink()
                    else:
                        # 文件为空，删除无效的锁文件
                        self.lock_file.unlink()
            except Exception:
                # 读取失败，删除可能损坏的锁文件
                try:
                    self.lock_file.unlink()
                except:
                    pass
        
        # 尝试创建锁文件
        try:
            # 尝试以独占模式打开锁文件
            self.lock_handle = open(self.lock_file, 'w')
            
            # 尝试获取文件锁（Windows和Unix都支持）
            try:
                import fcntl
                # Unix系统使用fcntl
                fcntl.flock(self.lock_handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            except ImportError:
                # Windows系统使用msvcrt
                import msvcrt
                msvcrt.locking(self.lock_handle.fileno(), msvcrt.LK_NBLCK, 1)
            
            # 写入当前进程信息
            self.lock_handle.write(f"PID: {os.getpid()}\n")
            self.lock_handle.write(f"Time: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
            self.lock_handle.write(f"Executable: {sys.executable}\n")
            self.lock_handle.flush()
            
            return False  # 成功获取锁，没有其他实例运行
            
        except (OSError, IOError):
            # 无法获取锁，说明已有实例运行
            if self.lock_handle:
                try:
                    self.lock_handle.close()
                except:
                    pass
                self.lock_handle = None
            return True
    
    def cleanup(self):
        """清理锁文件"""
        if self.lock_handle:
            try:
                self.lock_handle.close()
            except:
                pass
            self.lock_handle = None
        
        if self.lock_file and self.lock_file.exists():
            try:
                self.lock_file.unlink()
            except:
                pass
    
    def get_running_instance_info(self) -> Optional[str]:
        """
        获取正在运行的实例信息
        
        Returns:
            实例信息字符串，如果没有运行实例则返回None
        """
        if not self.lock_file or not self.lock_file.exists():
            return None
        
        try:
            with open(self.lock_file, 'r', encoding='utf-8') as f:
                content = f.read().strip()
                return content
        except:
            return None


def check_process_running(app_name: str = "TaskManagerPro") -> bool:
    """
    通过进程检测是否有相同程序在运行
    
    Args:
        app_name: 应用程序名称
        
    Returns:
        True: 有相同程序在运行
        False: 没有相同程序在运行
    """
    try:
        import psutil
        
        # 获取当前进程信息
        current_process = psutil.Process()
        current_cmdline = ' '.join(current_process.cmdline())
        
        # 检查所有Python进程
        for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
            try:
                # 跳过当前进程
                if proc.pid == current_process.pid:
                    continue
                
                # 检查是否是Python进程
                if 'python' in proc.info['name'].lower() and proc.info['cmdline']:
                    cmdline = ' '.join(proc.info['cmdline'])
                    
                    # 检查是否包含我们的程序特征
                    if any(keyword in cmdline.lower() for keyword in [
                        'ui_main.py', 
                        'taskmanagerpro', 
                        app_name.lower(),
                        'py_selenium'
                    ]):
                        logger.info(f" 发现运行中的程序实例:")
                        logger.info(f"  PID: {proc.pid}")
                        logger.info(f"  命令行: {cmdline}")
                        return True
                        
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue
                
    except ImportError:
        logger.warning(" 无法导入 psutil，跳过进程检测")
    except Exception as e:
        logger.warning(f" 进程检测失败: {e}")
    
    return False


# 全局变量存储锁文件信息，用于退出时清理
_lock_file_info = {"lock_file": None, "lock_handle": None}

def _cleanup_lock_file():
    """清理锁文件的内部函数"""
    global _lock_file_info
    if _lock_file_info.get("lock_handle"):
        try:
            # 先尝试解锁（Windows）
            if sys.platform == 'win32':
                try:
                    import msvcrt
                    msvcrt.locking(_lock_file_info["lock_handle"].fileno(), msvcrt.LK_UNLCK, 1)
                except:
                    pass
            else:
                # Unix系统解锁
                try:
                    import fcntl
                    fcntl.flock(_lock_file_info["lock_handle"].fileno(), fcntl.LOCK_UN)
                except:
                    pass
            
            _lock_file_info["lock_handle"].close()
        except:
            pass
        _lock_file_info["lock_handle"] = None
    
    if _lock_file_info.get("lock_file") and _lock_file_info["lock_file"].exists():
        try:
            _lock_file_info["lock_file"].unlink()
        except:
            pass
        _lock_file_info["lock_file"] = None

def _is_file_locked(lock_file: Path) -> bool:
    """
    检测文件是否被占用（被其他进程锁定）
    
    Args:
        lock_file: 锁文件路径
        
    Returns:
        True: 文件被占用
        False: 文件未被占用
    """
    if not lock_file.exists():
        return False
    
    try:
        # 尝试以独占模式打开文件
        # Windows系统
        if sys.platform == 'win32':
            try:
                import msvcrt
                # 尝试以读写模式打开文件
                # 如果文件被其他进程以写入模式打开，这里可能会失败
                try:
                    handle = open(lock_file, 'r+b')
                except (IOError, PermissionError, OSError):
                    # 如果打开失败，说明文件可能被占用
                    return True
                
                try:
                    # 尝试锁定文件的第一个字节（非阻塞模式）
                    msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
                    # 如果能锁定，说明文件未被占用，立即解锁
                    msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
                    handle.close()
                    return False
                except IOError:
                    # 无法锁定，说明文件被占用
                    handle.close()
                    return True
            except Exception:
                # 发生其他异常，保守地认为文件可能被占用
                return True
        else:
            # Unix/Linux系统
            try:
                import fcntl
                handle = open(lock_file, 'r+b')
                try:
                    # 尝试获取独占锁
                    fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                    # 如果能获取锁，说明文件未被占用，立即释放
                    fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
                    handle.close()
                    return False
                except (IOError, OSError):
                    # 无法获取锁，说明文件被占用
                    handle.close()
                    return True
            except Exception:
                # 如果打开失败，可能是文件被占用
                return True
    except Exception:
        # 发生异常，保守地认为文件可能被占用
        return True

def _create_lock_file(lock_file: Path) -> bool:
    """
    创建锁文件并写入当前进程信息
    
    Args:
        lock_file: 锁文件路径
        
    Returns:
        True: 创建成功
        False: 创建失败
    """
    global _lock_file_info
    try:
        # 先尝试获取文件锁
        lock_handle = open(lock_file, 'w', encoding='utf-8')
        
        # 尝试获取文件锁
        try:
            if sys.platform == 'win32':
                import msvcrt
                # Windows系统使用msvcrt
                msvcrt.locking(lock_handle.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                # Unix系统使用fcntl
                fcntl.flock(lock_handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except ImportError:
            # 如果无法导入锁定模块，仍然继续（某些环境可能不支持）
            pass
        
        _lock_file_info["lock_handle"] = lock_handle
        
        # 写入当前进程信息
        lock_handle.write(f"PID: {os.getpid()}\n")
        lock_handle.write(f"Time: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
        lock_handle.write(f"Executable: {sys.executable}\n")
        lock_handle.flush()
        
        # 注册退出时清理函数（只注册一次）
        if not hasattr(check_single_instance, '_atexit_registered'):
            atexit.register(_cleanup_lock_file)
            check_single_instance._atexit_registered = True
        
        return True
    except (IOError, OSError) as e:
        # 文件被占用或无法创建
        logger.warning(f" 创建锁文件失败（可能被占用）: {e}")
        _lock_file_info["lock_handle"] = None
        return False
    except Exception as e:
        logger.warning(f" 创建锁文件失败: {e}")
        _lock_file_info["lock_handle"] = None
        return False

def check_single_instance(app_name: str = "TaskManagerPro") -> bool:
    """
    检查单实例运行的便捷函数

    说明：
    由于release版本与源码版路径不一致，这里锁文件建议写在唯一的、与运行方式无关的路径下（比如临时目录）。
    否则release和源码版会分别运行，不共享锁，导致检测失效。

    Args:
        app_name: 应用程序名称

    Returns:
        True: 可以运行（没有其他实例）
        False: 不能运行（已有实例在运行）
    """
    import tempfile
    import os
    global _lock_file_info

    # 跨目录/跨打包场景下确保锁文件唯一（用系统临时目录+app_name）
    lock_dir = Path(tempfile.gettempdir()) / "taskmanagerpro_locks"
    lock_dir.mkdir(parents=True, exist_ok=True)
    lock_file = lock_dir / f"{app_name}.lock"
    
    # 保存锁文件路径到全局变量
    _lock_file_info["lock_file"] = lock_file

    # 如果锁文件不存在，说明没有其他实例运行
    if not lock_file.exists():
        # 创建锁文件并写入当前进程信息
        _create_lock_file(lock_file)
        return True  # 即使创建失败也允许运行，避免阻塞

    # 先检查文件是否被占用
    if _is_file_locked(lock_file):
        # 文件被占用，说明有其他实例正在运行
        try:
            with open(lock_file, 'r', encoding='utf-8') as f:
                content = f.read().strip()
                logger.error(f" {app_name} 已在运行中！")
                logger.info(f" 运行实例详情：")
                logger.info(content if content else "（无法读取详细信息）")
                logger.info(f"[提示] 请关闭现有实例后再启动新实例。")
                try:
                    import tkinter as tk
                    from tkinter import messagebox

                    root = tk.Tk()
                    root.withdraw()
                    message = f"{app_name} 已在运行中！\n\n请关闭现有实例后再启动新实例。"
                    if content:
                        message += f"\n\n运行实例详情：\n{content}"
                    messagebox.showwarning("程序已在运行", message)
                    root.destroy()
                except ImportError:
                    pass
        except Exception:
            logger.error(f" {app_name} 已在运行中！（锁文件被占用）")
            try:
                import tkinter as tk
                from tkinter import messagebox

                root = tk.Tk()
                root.withdraw()
                message = f"{app_name} 已在运行中！\n\n请关闭现有实例后再启动新实例。"
                #messagebox.showwarning("程序已在运行", message)
                root.destroy()
            except ImportError:
                pass
        return False

    # 如果锁文件存在但未被占用，检查是否真的在运行
    try:
        with open(lock_file, 'r', encoding='utf-8') as f:
            content = f.read().strip()
            if content:
                # 尝试解析PID
                lines = content.split('\n')
                pid_line = None
                for line in lines:
                    if line.startswith('PID:'):
                        pid_line = line
                        break

                if pid_line:
                    try:
                        pid = int(pid_line.split(':', 1)[1].strip())
                        import psutil
                        exists = False

                        # 检查是否同名进程且命令行上存在app_name对应特征，并且不是当前进程
                        try:
                            for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
                                if proc.pid == os.getpid():
                                    continue
                                if proc.pid == pid:
                                    # 进一步严谨比对进程信息，避免release和源码都能运行的情况
                                    cmdline = ' '.join(proc.info.get('cmdline', [])).lower()
                                    if app_name.lower() in cmdline or "ui_main.py" in cmdline or "taskmanagerpro" in cmdline or "py_selenium" in cmdline:
                                        exists = True
                                        break
                        except Exception:
                            # 回退简单判断pid存在
                            exists = psutil.pid_exists(pid)

                        if exists:
                            logger.error(f" {app_name} 已在运行中！")
                            logger.info(f" 运行实例详情：")
                            logger.info(content)
                            logger.info(f"[提示] 请关闭现有实例后再启动新实例。")
                            try:
                                import tkinter as tk
                                from tkinter import messagebox

                                root = tk.Tk()
                                root.withdraw()
                                message = f"{app_name} 已在运行中！\n\n请关闭现有实例后再启动新实例。"
                                message += f"\n\n运行实例详情：\n{content}"
                                messagebox.showwarning("程序已在运行", message)
                                root.destroy()
                            except ImportError:
                                pass
                            return False
                        else:
                            # 进程不存在/进程与特征不符，删除过期锁文件
                            lock_file.unlink()
                            # 创建新的锁文件
                            _create_lock_file(lock_file)
                            return True
                    except (ValueError, IndexError):
                        lock_file.unlink()
                        # 创建新的锁文件
                        _create_lock_file(lock_file)
                        return True
                else:
                    lock_file.unlink()
                    # 创建新的锁文件
                    _create_lock_file(lock_file)
                    return True
            else:
                lock_file.unlink()
                # 创建新的锁文件
                _create_lock_file(lock_file)
                return True
    except Exception:
        try:
            lock_file.unlink()
        except:
            pass
        # 创建新的锁文件
        _create_lock_file(lock_file)
        return True

if __name__ == "__main__":
    # 测试单实例检查
    if check_single_instance():
        logger.info("可以运行新实例")
        input("按回车键退出...")
    else:
        logger.info("已有实例在运行")
