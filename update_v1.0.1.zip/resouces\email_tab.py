
import logging
from typing import Optional

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (
    QAbstractItemView,  
    QHBoxLayout,
    QHeaderView,
    QLineEdit,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
    QLabel,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QCheckBox,
    QSpinBox,
    QMessageBox,
)

from data_type import EmailJsonConfig
from file_oper import FileOper

logger = logging.getLogger()


class AddEditEmailDialog(QDialog):
    """添加/修改邮件服务器对话框"""
    def __init__(self, parent: QWidget | None = None, email_config: EmailJsonConfig | None = None):
        super().__init__(parent)
        self.email_config = email_config
        self.is_edit_mode = email_config is not None
        
        self.setWindowTitle("修改邮件服务器" if self.is_edit_mode else "添加邮件服务器")
        self.setModal(True)
        self.resize(400, 300)
        
        self._setup_ui()
        
        if self.is_edit_mode:
            self._load_data()
    
    def _setup_ui(self) -> None:
        layout = QVBoxLayout(self)
        
        # 表单布局
        form_layout = QFormLayout()
        
        # 邮箱帐号
        self.email_edit = QLineEdit()
        self.email_edit.setPlaceholderText("例如: user@example.com")
        form_layout.addRow("邮箱帐号:", self.email_edit)
        
        # 专用密码
        self.password_edit = QLineEdit()
        self.password_edit.setEchoMode(QLineEdit.Password)
        self.password_edit.setPlaceholderText("邮箱专用密码或应用密码")
        form_layout.addRow("专用密码:", self.password_edit)
        
        # 服务器地址
        self.server_edit = QLineEdit()
        self.server_edit.setPlaceholderText("例如: smtp.qq.com")
        form_layout.addRow("服务器地址:", self.server_edit)
        
        # 端口
        self.port_spinbox = QSpinBox()
        self.port_spinbox.setRange(1, 65535)
        self.port_spinbox.setValue(465)
        form_layout.addRow("端口:", self.port_spinbox)
        
        # 启用状态
        self.enabled_checkbox = QCheckBox("启用此邮件服务器")
        self.enabled_checkbox.setChecked(True)
        form_layout.addRow("", self.enabled_checkbox)
        
        layout.addLayout(form_layout)
        
        # 按钮
        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)
    
    def _load_data(self) -> None:
        """加载现有邮件配置数据"""
        if not self.email_config:
            return
            
        self.email_edit.setText(self.email_config.email)
        self.password_edit.setText(self.email_config.password)
        self.server_edit.setText(self.email_config.server)
        self.port_spinbox.setValue(self.email_config.port)
        self.enabled_checkbox.setChecked(self.email_config.enabled)
    
    def get_data(self) -> EmailJsonConfig:
        """获取表单数据"""
        if self.is_edit_mode:
            # 修改模式：基于现有配置创建新对象
            config = EmailJsonConfig(
                email=self.email_edit.text().strip(),
                password=self.password_edit.text(),
                server=self.server_edit.text().strip(),
                port=self.port_spinbox.value(),
                use_ssl=True,  # 默认使用SSL
                enabled=self.enabled_checkbox.isChecked(),
                last_used=self.email_config.last_used,
                send_count=self.email_config.send_count,
                error_count=self.email_config.error_count
            )
        else:
            # 添加模式：创建新配置
            config = EmailJsonConfig(
                email=self.email_edit.text().strip(),
                password=self.password_edit.text(),
                server=self.server_edit.text().strip(),
                port=self.port_spinbox.value(),
                use_ssl=True,  # 默认使用SSL
                enabled=self.enabled_checkbox.isChecked(),
                last_used=None,
                send_count=0,
                error_count=0
            )
        return config
    
    def is_valid(self) -> bool:
        """验证表单数据"""
        if not self.email_edit.text().strip():
            QMessageBox.warning(self, "警告", "请输入邮箱帐号")
            return False
        if not self.password_edit.text():
            QMessageBox.warning(self, "警告", "请输入专用密码")
            return False
        if not self.server_edit.text().strip():
            QMessageBox.warning(self, "警告", "请输入服务器地址")
            return False
        return True


# 表格列索引常量
COL_COUNT = 6     # 总列数
COL_SERVER = 0    # 服务器地址  
COL_EMAIL = 1     # 邮箱
COL_PASSWORD = 2  # 专用密码
COL_PORT = 3      # 端口
COL_STATUS = 4    # 状态
COL_ACTIONS = 5   # 操作


class EmailManagerTab(QWidget):
    def __init__(self, *, parent: QWidget | None = None):
        super().__init__(parent)
        self._setup_ui()
        self._refresh_email_table()
        
    def _setup_ui(self) -> None:
        layout = QVBoxLayout(self)
        
        # 顶部信息行
        info_row = QHBoxLayout()
        
        # 通知邮箱显示
        notify_label = QLabel("通知邮箱:")
        info_row.addWidget(notify_label)
        
        # 通知邮箱输入框
        self.notify_email_input = QLineEdit()
        notify_email = self._get_notify_email()
        if notify_email:
            self.notify_email_input.setText(notify_email)
        try:
            self.notify_email_input.setFixedWidth(250)
            self.notify_email_input.setPlaceholderText("请输入邮箱帐号...")
        except Exception:
            pass
        info_row.addWidget(self.notify_email_input)
        
        # 右对齐添加邮件服务器按钮
        info_row.addStretch(1)
        self.add_email_button = QPushButton("添加邮件服务器")
        try:
            self.add_email_button.setFixedWidth(120)
        except Exception:
            pass
        info_row.addWidget(self.add_email_button)
        
        layout.addLayout(info_row)
        
        # 邮件服务器表格
        self.email_table = QTableWidget(0, COL_COUNT)
        self.email_table.setHorizontalHeaderLabels([
            "服务器地址",
            "邮箱帐号",
            "专用密码", 
            "端口",
            "状态",
            "操作"
        ])
        
        # 设置表格属性
        try:
            self.email_table.setSelectionBehavior(QAbstractItemView.SelectRows)
            self.email_table.setSelectionMode(QAbstractItemView.SingleSelection)
            self.email_table.setEditTriggers(QAbstractItemView.NoEditTriggers)  # 禁用编辑，确保只能行选择
            
            # 设置列宽
            header = self.email_table.horizontalHeader()
            header.setSectionResizeMode(COL_SERVER, QHeaderView.Stretch)
            header.setSectionResizeMode(COL_EMAIL, QHeaderView.Stretch)
            # 专用密码、端口、状态设置固定合适宽度
            self.email_table.setColumnWidth(COL_PASSWORD, 150)
            self.email_table.setColumnWidth(COL_PORT, 100)
            self.email_table.setColumnWidth(COL_STATUS, 100)
            # 操作列设置更宽的固定宽度
            self.email_table.setColumnWidth(COL_ACTIONS, 300)
            
        except Exception:
            pass
            
        layout.addWidget(self.email_table)
        
        # 绑定按钮事件
        self.add_email_button.clicked.connect(self._on_add_email_clicked)
        
        # 绑定通知邮箱输入框事件（离开焦点时保存）
        self.notify_email_input.editingFinished.connect(self._on_notify_email_changed)
        
    def _get_notify_email(self) -> Optional[str]:
        """获取通知邮箱"""
        try:
            sys_config = FileOper.get_sys_config()
            return sys_config.get("notify_email", "")
        except Exception as e:
            logger.error(f"获取通知邮箱失败: {e}")
            return None
            
    def _refresh_email_table(self) -> None:
        """刷新邮件服务器表格"""
        try:
            email_configs = FileOper.get_email_config()
            
            # 清空表格
            self.email_table.setRowCount(0)
            
            # 填充数据
            for email_config in email_configs:
                self._add_email_row(email_config)
                
        except Exception as e:
            logger.error(f"刷新邮件服务器表格失败: {e}")
            
    def _add_email_row(self, email_config: EmailJsonConfig) -> None:
        """添加邮件服务器行到表格"""
        try:
            row = self.email_table.rowCount()
            self.email_table.insertRow(row)
            
            # 服务器地址列
            server_item = QTableWidgetItem(email_config.server)
            server_item.setTextAlignment(Qt.AlignCenter)
            server_item.setFlags(server_item.flags() & ~Qt.ItemIsEditable)  # 设置为不可编辑
            self.email_table.setItem(row, COL_SERVER, server_item)
            
            # 邮箱列
            email_item = QTableWidgetItem(email_config.email)
            email_item.setTextAlignment(Qt.AlignCenter)
            email_item.setFlags(email_item.flags() & ~Qt.ItemIsEditable)  # 设置为不可编辑
            self.email_table.setItem(row, COL_EMAIL, email_item)
            
            # 专用密码列（显示星号）
            password_item = QTableWidgetItem("*" * 7)
            password_item.setTextAlignment(Qt.AlignCenter)
            password_item.setFlags(password_item.flags() & ~Qt.ItemIsEditable)  # 设置为不可编辑
            self.email_table.setItem(row, COL_PASSWORD, password_item)
            
            # 端口列
            port_item = QTableWidgetItem(str(email_config.port))
            port_item.setTextAlignment(Qt.AlignCenter)
            port_item.setFlags(port_item.flags() & ~Qt.ItemIsEditable)  # 设置为不可编辑
            self.email_table.setItem(row, COL_PORT, port_item)
            
            # 状态列
            status_text = "开启" if email_config.enabled else "关闭"
            status_item = QTableWidgetItem(status_text)
            status_item.setTextAlignment(Qt.AlignCenter)
            status_item.setFlags(status_item.flags() & ~Qt.ItemIsEditable)  # 设置为不可编辑
            
            # 根据状态设置颜色
            if email_config.enabled:
                try:
                    status_item.setForeground(QColor("#28a745"))  # 绿色
                except Exception:
                    pass
            else:
                try:
                    status_item.setForeground(QColor("#dc3545"))  # 红色
                except Exception:
                    pass
                
            self.email_table.setItem(row, COL_STATUS, status_item)
            
            # 操作列 - 创建操作按钮容器
            actions_widget = QWidget()
            actions_layout = QHBoxLayout(actions_widget)
            actions_layout.setContentsMargins(6, 4, 6, 4)
            actions_layout.setSpacing(6)
            
            # 删除按钮
            delete_btn = QPushButton("删除")
            try:
                delete_btn.setFixedSize(52, 26)
                delete_btn.setStyleSheet("""
                    QPushButton { 
                        font-size: 12px; 
                        background-color: #dc3545;
                        color: white;
                        border-radius: 4px;
                        border: 1px solid rgba(0,0,0,0.1);
                    }
                    QPushButton:hover {
                        background-color: #c82333;
                    }
                """)
            except Exception:
                pass
            delete_btn.clicked.connect(lambda checked, email=email_config.email: self._on_delete_email_clicked(email))
            actions_layout.addWidget(delete_btn)
            
            # 修改按钮
            edit_btn = QPushButton("修改")
            try:
                edit_btn.setFixedSize(52, 26)
                edit_btn.setStyleSheet("""
                    QPushButton { 
                        font-size: 12px; 
                        background-color: #007bff;
                        color: white;
                        border-radius: 4px;
                        border: 1px solid rgba(0,0,0,0.1);
                    }
                    QPushButton:hover {
                        background-color: #0056b3;
                    }
                """)
            except Exception:
                pass
            edit_btn.clicked.connect(lambda checked, email=email_config.email: self._on_edit_email_clicked(email))
            actions_layout.addWidget(edit_btn)
            
            # 测试按钮
            test_btn = QPushButton("测试")
            try:
                test_btn.setFixedSize(52, 26)
                test_btn.setStyleSheet("""
                    QPushButton { 
                        font-size: 12px; 
                        background-color: #28a745;
                        color: white;
                        border-radius: 4px;
                        border: 1px solid rgba(0,0,0,0.1);
                    }
                    QPushButton:hover {
                        background-color: #1e7e34;
                    }
                """)
            except Exception:
                pass
            test_btn.clicked.connect(lambda checked, email=email_config.email: self._on_test_email_clicked(email))
            actions_layout.addWidget(test_btn)
            
            self.email_table.setCellWidget(row, COL_ACTIONS, actions_widget)
            
        except Exception as e:
            logger.error(f"添加邮件服务器行失败: {e}")
            
    # ========== 事件处理方法 ==========
    
    def _on_add_email_clicked(self) -> None:
        """添加邮件服务器按钮点击事件"""
        dialog = AddEditEmailDialog(parent=self)
        if dialog.exec() == QDialog.Accepted:
            if not dialog.is_valid():
                return
                
            email_config = dialog.get_data()
            
            # 检查邮箱是否已存在
            existing_configs = FileOper.get_email_config()
            if any(config.email == email_config.email for config in existing_configs):
                QMessageBox.warning(self, "警告", f"邮箱 {email_config.email} 已存在！")
                return
            
            # 添加邮件配置
            try:
                if FileOper.add_email_config(email_config):
                    logger.info(f"已添加邮件服务器: {email_config.email}")
                    QMessageBox.information(self, "成功", f"邮件服务器 {email_config.email} 添加成功！")
                    self._refresh_email_table()
                else:
                    QMessageBox.critical(self, "错误", "添加邮件服务器失败！")
            except Exception as e:
                logger.error(f"添加邮件服务器异常: {e}")
                QMessageBox.critical(self, "错误", f"添加邮件服务器异常：{e}")
        
    def _on_delete_email_clicked(self, email: str) -> None:
        """删除邮件服务器按钮点击事件"""
        reply = QMessageBox.question(
            self, 
            "确认删除", 
            f"确定要删除邮件服务器 {email} 吗？",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            try:
                if FileOper.delete_email_config(email):
                    logger.info(f"已删除邮件服务器: {email}")
                    QMessageBox.information(self, "成功", f"邮件服务器 {email} 删除成功！")
                    self._refresh_email_table()
                else:
                    QMessageBox.critical(self, "错误", "删除邮件服务器失败！")
            except Exception as e:
                logger.error(f"删除邮件服务器异常: {e}")
                QMessageBox.critical(self, "错误", f"删除邮件服务器异常：{e}")
        
    def _on_edit_email_clicked(self, email: str) -> None:
        """修改邮件服务器按钮点击事件"""
        # 查找当前邮件配置
        email_configs = FileOper.get_email_config()
        current_config = None
        for config in email_configs:
            if config.email == email:
                current_config = config
                break
        
        if not current_config:
            QMessageBox.warning(self, "警告", f"未找到邮件服务器 {email}！")
            return
            
        dialog = AddEditEmailDialog(parent=self, email_config=current_config)
        if dialog.exec() == QDialog.Accepted:
            if not dialog.is_valid():
                return
                
            new_config = dialog.get_data()
            
            # 如果邮箱帐号改变了，检查新邮箱是否已存在
            if new_config.email != email:
                existing_configs = FileOper.get_email_config()
                if any(config.email == new_config.email for config in existing_configs):
                    QMessageBox.warning(self, "警告", f"邮箱 {new_config.email} 已存在！")
                    return
            
            try:
                # 处理邮箱帐号变更的情况
                if new_config.email != email:
                    # 邮箱帐号改变了：先删除旧配置，再添加新配置
                    if FileOper.delete_email_config(email) and FileOper.add_email_config(new_config):
                        logger.info(f"已修改邮件服务器: {email} -> {new_config.email}")
                        QMessageBox.information(self, "成功", f"邮件服务器修改成功！")
                        self._refresh_email_table()
                    else:
                        QMessageBox.critical(self, "错误", "修改邮件服务器失败！")
                else:
                    # 邮箱帐号未改变：直接更新
                    if FileOper.update_email_config(new_config):
                        logger.info(f"已修改邮件服务器: {email}")
                        QMessageBox.information(self, "成功", f"邮件服务器修改成功！")
                        self._refresh_email_table()
                    else:
                        QMessageBox.critical(self, "错误", "修改邮件服务器失败！")
            except Exception as e:
                logger.error(f"修改邮件服务器异常: {e}")
                QMessageBox.critical(self, "错误", f"修改邮件服务器异常：{e}")
        
    def _on_test_email_clicked(self, email: str) -> None:
        """测试邮件服务器按钮点击事件"""
        try:
            from email_sender import EmailSender
            
            # 创建邮件发送器并测试连接
            sender = EmailSender()
            test_results = sender.test_connection(email=email)
            
            if email in test_results:
                if test_results[email]:
                    QMessageBox.information(self, "测试成功", f"邮件服务器 {email} 连接成功！")
                    logger.info(f"邮件服务器测试成功: {email}")
                else:
                    QMessageBox.warning(self, "测试失败", f"邮件服务器 {email} 连接失败！\n请检查配置信息。")
                    logger.warning(f"邮件服务器测试失败: {email}")
            else:
                QMessageBox.critical(self, "测试错误", f"未找到邮件服务器 {email}！")
                
        except ImportError:
            QMessageBox.critical(self, "模块错误", "邮件发送模块未找到！")
            logger.error(f"邮件发送模块导入失败")
        except Exception as e:
            logger.error(f"测试邮件服务器异常: {e}")
            QMessageBox.critical(self, "测试异常", f"测试邮件服务器时发生异常：{e}")
        
    def _on_notify_email_changed(self) -> None:
        """通知邮箱输入框文本变化事件"""
        try:
            new_notify_email = self.notify_email_input.text().strip()
            # 更新系统配置中的通知邮箱
            if FileOper.write_sys_config({"notify_email": new_notify_email}):
                logger.info(f"通知邮箱已更新为: {new_notify_email}")
            else:
                logger.error("更新通知邮箱失败")
        except Exception as e:
            logger.error(f"更新通知邮箱时发生异常: {e}")

